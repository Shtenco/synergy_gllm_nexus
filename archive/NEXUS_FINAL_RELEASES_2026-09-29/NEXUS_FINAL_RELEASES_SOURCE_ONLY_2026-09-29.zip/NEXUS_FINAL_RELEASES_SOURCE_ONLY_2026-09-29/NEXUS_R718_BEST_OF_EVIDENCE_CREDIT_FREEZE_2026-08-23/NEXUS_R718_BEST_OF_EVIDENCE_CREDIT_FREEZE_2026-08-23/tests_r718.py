from __future__ import annotations
import json,math,sys,pathlib,pandas as pd
ROOT=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'source'))
import runtime_r718 as r

def teacher_rows_from_csv(x):
    out={}
    for t in r.T:
        lp={a:float(math.log(max(float(x[f'{t}_p{a}']),1e-30))) for a in r.L}
        out[t]={'pred':x[t+'_pred'] if isinstance(x[t+'_pred'],str) else None,'option_logprobs':lp}
    return out

def main():
    old=pd.read_csv(ROOT/'dev'/'R718_TRAIN_824.csv'); old=old[old.block!='B30']
    oc=0; stages={};calls=0
    for _,x in old.iterrows():
        it={'id':x.id,'q':x.q,'domain':x.domain_true,'options':json.loads(x.options_json)}
        o=r.decide(it,teacher_rows_from_csv(x));oc+=o.get('answer')==x.gold;calls+=o.get('calls',0);stages[o['stage']]=stages.get(o['stage'],0)+1
    b=json.load(open(ROOT/'dev'/'BLIND30_FROZEN_DISCLOSED.json'))
    ev=json.load(open(ROOT/'dev'/'B30_EVIDENCE_MERGED.json'))
    bc=0;bs={};bcalls=0
    for it in b['items']:
        o=r.decide(it,ev[it['id']]);bc+=o['answer']==it['answer'];bcalls+=o['calls'];bs[o['stage']]=bs.get(o['stage'],0)+1
    # direct operator smoke tests, independent of benchmark ids.
    smoke=[
      ({'q':'Стек получил элементы A, B, C по порядку. Что извлекается первым?','options':{'A':'A','B':'B','C':'C','D':'случайно'}},'C'),
      ({'q':'Найдите наименьшее положительное число, кратное и 18, и 24.','options':{'A':'6','B':'72','C':'42','D':'432'}},'B'),
      ({'q':'Каков НОД чисел 36 и 24?','options':{'A':'6','B':'8','C':'12','D':'864'}},'C'),
      ({'q':'Сколькими способами можно выбрать 3 объекта из 8, если порядок не важен?','options':{'A':'24','B':'56','C':'512','D':'336'}},'B'),
      ({'q':'Что напечатает код?\n```\nx=[1,2]\ny=x\ny.append(3)\nprint(len(x),x[-1])\n```','options':{'A':'2 2','B':'2 3','C':'3 2','D':'3 3'}},'D'),
    ]
    sm=[]
    for it,gold in smoke:
        o=r.decide(it,{});sm.append({'answer':o['answer'],'gold':gold,'ok':o['answer']==gold,'stage':o['stage']})
    out={'old_disclosed_replay':{'n':len(old),'correct':oc,'accuracy':oc/len(old),'mean_calls':calls/len(old),'stages':stages},
         'blind30_disclosed_replay':{'n':len(b['items']),'correct':bc,'accuracy':bc/len(b['items']),'mean_calls':bcalls/len(b['items']),'stages':bs,'scientific_status':'DEVELOPMENT/REGRESSION ONLY'},
         'operator_smoke':sm,'blind31_status':'DOES NOT EXIST'}
    (ROOT/'dev'/'R718_SELFTEST.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
    print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
