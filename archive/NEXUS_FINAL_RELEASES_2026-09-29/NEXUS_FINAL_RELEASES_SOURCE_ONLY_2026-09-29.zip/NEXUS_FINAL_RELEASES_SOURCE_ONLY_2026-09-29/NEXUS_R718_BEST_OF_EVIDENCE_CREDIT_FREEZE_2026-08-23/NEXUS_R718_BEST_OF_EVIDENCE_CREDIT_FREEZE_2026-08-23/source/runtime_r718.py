from __future__ import annotations
from pathlib import Path
import sys,math,hashlib,numpy as np
from catboost import CatBoostClassifier
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'base_r717';R716=BASE/'base_r716';R715=R716/'base_r715';R714=R715/'base_r714';R713=R714/'base_r713'
sys.path[:0]=[str(BASE/'source'),str(R716/'source'),str(R715/'source'),str(R714/'source'),str(R713/'source'),str(ROOT/'source')]
import runtime_r717 as r717
import sequential_fusion_core as sf
import graphboost_training as g
import morpholex_engine as morph
import bip39_cyber_layer as bip
import bip39_query_controller as qc
import evidence_credit_core as ec
import native_structural_core as native
import multilingual_structural as multi
import proof_integrity as pi

CAND=CatBoostClassifier();CAND.load_model(str(ROOT/'models'/'candidate_credit.cbm'))
TQ=CatBoostClassifier();TQ.load_model(str(ROOT/'models'/'next_teacher_credit.cbm'))
T=ec.TEACHERS;L=ec.LABELS
POLICY={
 'name':'NEXUS R7.18 Best-of-NEXUS Evidence Credit Assignment Core',
 'best_components':['R7.2 natural structural binding','R7.10 proof-first verifier','R7.13 H<->T cyberloop','R7.16 BIP39 adaptive query scheduling','R7.17 recurrent/SEAL/quantum advisory','R7.18 candidate evidence credit + next-teacher credit'],
 'authority_order':['R7.10 formal VERIFIED','R7.18 native structural VERIFIED','R7.14 multilingual structural VERIFIED','R7.18 evidence credit'],
 'bip39_role':'deterministic exploration/tie-break only; never truth evidence',
 'recurrent_role':'advisory tie-break for next organ only',
 'max_teacher_calls':5,
 'blind31_status':'DOES NOT EXIST AT FREEZE'
}

def _formal(item):return pi.repair(item,g.formal_pass(item))

def _softmax_score(s):
    z=np.asarray(s,float);z=z-z.max();e=np.exp(np.clip(z,-30,30));return e/(e.sum()+1e-12)

def _credit(item,teacher_rows,mask,formal):
    s=ec.candidate_scores(CAND,item['q'],teacher_rows,mask,formal.get('status','UNKNOWN'),formal.get('answer'))
    p=_softmax_score(np.log(np.clip(s,1e-6,1)))
    order=np.argsort(-p);return int(order[0]),p,float(p[order[0]]-p[order[1]]),s

def _choose_teacher(item,teacher_rows,mask,formal,current,cycle):
    avail=[j for j in range(5) if mask[j]<=0]
    if not avail:return None,{}
    pred={}
    for j in avail:
        x=ec.teacher_query_features(item['q'],teacher_rows,mask,T[j],formal.get('status','UNKNOWN'),formal.get('answer'))[None,:]
        pred[j]=float(TQ.predict_proba(x)[0,1])
    # R7.17 recurrent advice is a weak tie-break only; it cannot override a clearly better credit forecast.
    rec=None
    try:
        used=[T[j] for j in range(5) if mask[j]>0]
        st=r717.recurrent_state(item,teacher_rows,used,formal);name=st.get('suggested_teacher_one_step')
        if name in T and T.index(name) in avail:rec=T.index(name)
    except Exception: st=None
    # BIP39 deterministic route provides another tiny tie-break among near-equal candidates.
    pack=bip.route_pack(item['q'],cycle,L[current],'EVIDENCE_CREDIT',0.0);route=int(pack['route_id'])
    best=max(avail,key=lambda j:(pred[j] + (0.012 if j==rec else 0.0) + (0.003 if j==avail[route%len(avail)] else 0.0),-j))
    return best,{'teacher_credit':{T[j]:pred[j] for j in avail},'r717_recurrent_suggestion':T[rec] if rec is not None else None,'bip39_route_id':route,'chosen':T[best]}

def decide(item,teacher_rows=None):
    teacher_rows=teacher_rows or {}
    formal=_formal(item)
    if formal.get('status')=='VERIFIED' and formal.get('answer') in L:
        return {'answer':formal['answer'],'stage':'R710_FORMAL_VERIFIED','calls':0,'used':[],'formal':formal,'policy':POLICY,'trace':[]}
    nr=native.solve(item)
    if nr.status=='VERIFIED':
        return {'answer':nr.value,'stage':'R72_R710_NATIVE_VERIFIED','calls':0,'used':[],'formal':formal,'native':nr.__dict__,'policy':POLICY,'trace':[]}
    ma=multi.solve(item,morph)
    if ma in L:
        return {'answer':ma,'stage':'R714_MULTILINGUAL_VERIFIED','calls':0,'used':[],'formal':formal,'native':{'kind':'MORPHOLEX_IMPLICATION'},'policy':POLICY,'trace':[]}
    mask,top2,comp,route=sf.initial_route(item['q']); initial=[T[i] for i in top2]
    missing=[t for t in initial if t not in teacher_rows]
    if missing:return {'answer':None,'stage':'NEED_INITIAL_TEACHERS','required':initial,'missing':missing,'calls_needed':len(missing),'formal':formal,'policy':POLICY,'trace':[]}
    calls=2;used=initial.copy();current=None;stable=0;trace=[]
    for cycle in range(4):
        cur,p,margin,raw=_credit(item,teacher_rows,mask,formal)
        if current==cur:stable+=1
        elif current is not None:stable=0
        current=cur
        trace.append({'cycle':cycle,'called':[T[j] for j in range(5) if mask[j]>0],'candidate':L[cur],'posterior':p.tolist(),'margin':margin,'stable':stable})
        # Stepwise verifier: high credit or stability after an independent new organ permits stop.
        if (p[cur]>=.78 and margin>=.25) or (calls>=3 and stable>=1 and p[cur]>=.64 and margin>=.10) or calls>=5:
            return {'answer':L[cur],'stage':'R718_CREDIT_FIXED_POINT','calls':calls,'used':used,'formal':formal,'policy':POLICY,'trace':trace}
        j,advice=_choose_teacher(item,teacher_rows,mask,formal,cur,cycle+1)
        trace[-1]['next_teacher_advice']=advice
        if j is None:return {'answer':L[cur],'stage':'R718_NO_MORE_ORGANS','calls':calls,'used':used,'formal':formal,'policy':POLICY,'trace':trace}
        t=T[j]
        if t not in teacher_rows:
            return {'answer':None,'stage':'NEED_R718_CREDIT_TEACHER','next_teacher':t,'calls_so_far':calls,'used':used,'formal':formal,'policy':POLICY,'trace':trace,'query_packet':{'teacher':t,'role':'independent evidence for candidate credit assignment','bip39_is_not_evidence':True}}
        mask[j]=1;used.append(t);calls+=1
    return {'answer':L[current],'stage':'R718_MAX_CYCLES','calls':calls,'used':used,'formal':formal,'policy':POLICY,'trace':trace}
