from __future__ import annotations
import re
NEG_EXTRA=['cannot',"can't",'nothing','nada','nenhuma','aucune','rien','کوئی نہیں','کچھ نتیجہ نہیں','نہیں','لا ','ليس','কিছুই','নয়','না','不','没有','ничего','не может','não']
def solve(item,morph):
    q=item['q'];opts=item['options'];alltxt=' '+q+' '+' '.join(opts.values())+' '
    lang,_=morph.detect_language(alltxt)
    qir=morph.analyze(q,lang)
    # Only apply when the question expresses universal membership/implication-like structure.
    if qir.operators.get('QUANT_ALL',0)<=0 and not any(x in q.casefold() for x in ['every ','toda ','toute ','हर ','ہر ','সব ','所有','кажд']):return None
    cand=[]
    for a,t in opts.items():
        ir=morph.analyze(t,lang); low=t.casefold();neg=ir.operators.get('NEG',0)>0 or any(x in low for x in NEG_EXTRA)
        if ('k' in low) and not neg:cand.append(a)
    return cand[0] if len(cand)==1 else None
