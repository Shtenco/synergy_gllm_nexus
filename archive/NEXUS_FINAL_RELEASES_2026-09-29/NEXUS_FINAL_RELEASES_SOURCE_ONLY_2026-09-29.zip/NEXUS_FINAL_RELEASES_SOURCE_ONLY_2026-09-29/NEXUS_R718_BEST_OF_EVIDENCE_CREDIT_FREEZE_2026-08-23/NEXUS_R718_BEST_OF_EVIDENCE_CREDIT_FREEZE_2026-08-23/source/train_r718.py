from __future__ import annotations
import json, math, pathlib, random, sys
import numpy as np,pandas as pd
from catboost import CatBoostClassifier
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'source'))
import evidence_credit_core as ec

def row_to_teacher_rows(r):
    out={}
    for t in ec.TEACHERS:
        lp={a:float(math.log(max(float(r[f'{t}_p{a}']),1e-30))) for a in ec.LABELS}
        pred=r[t+'_pred'] if isinstance(r[t+'_pred'],str) else None
        out[t]={'pred':pred,'option_logprobs':lp}
    return out

def masks_for_row(seed):
    rng=random.Random(seed);masks=[np.ones(5,np.float32)]
    for k in (2,3,4):
        ids=rng.sample(range(5),k);m=np.zeros(5,np.float32);m[ids]=1;masks.append(m)
    return masks

def train(df):
    X=[];y=[];XT=[];yT=[]
    for ii,r in df.iterrows():
        tr=row_to_teacher_rows(r);fs=r.get('formal_status','UNKNOWN');fa=r.get('formal_answer',None);gold=r['gold']
        for mi,m in enumerate(masks_for_row(718000+ii)):
            for a in ec.LABELS:
                X.append(ec.candidate_features(r.q,tr,m,a,fs,fa));y.append(int(a==gold))
            # for each not-yet-called teacher, learn whether its future evidence will be correct
            for j,t in enumerate(ec.TEACHERS):
                if m[j]<=0:
                    XT.append(ec.teacher_query_features(r.q,tr,m,t,fs,fa));yT.append(int(r[t+'_pred']==gold))
    X=np.asarray(X,np.float32);y=np.asarray(y);XT=np.asarray(XT,np.float32);yT=np.asarray(yT)
    cand=CatBoostClassifier(iterations=240,depth=6,learning_rate=.07,loss_function='Logloss',verbose=False,random_seed=718,l2_leaf_reg=6,random_strength=.65,thread_count=8)
    cand.fit(X,y); cand.save_model(str(ROOT/'models'/'candidate_credit.cbm'))
    tq=CatBoostClassifier(iterations=200,depth=6,learning_rate=.07,loss_function='Logloss',verbose=False,random_seed=719,l2_leaf_reg=7,random_strength=.7,thread_count=8)
    tq.fit(XT,yT);tq.save_model(str(ROOT/'models'/'next_teacher_credit.cbm'))
    meta={'n_questions':len(df),'candidate_rows':len(y),'teacher_query_rows':len(yT),'candidate_positive_rate':float(y.mean()),'teacher_query_positive_rate':float(yT.mean()),'teacher_order':ec.TEACHERS,'labels':ec.LABELS,'augmentation':'all5 + deterministic masks sizes 2,3,4 per item','seed':718}
    (ROOT/'models'/'training_meta.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
    print(json.dumps(meta,ensure_ascii=False,indent=2))
if __name__=='__main__':
    train(pd.read_csv(sys.argv[1]))
