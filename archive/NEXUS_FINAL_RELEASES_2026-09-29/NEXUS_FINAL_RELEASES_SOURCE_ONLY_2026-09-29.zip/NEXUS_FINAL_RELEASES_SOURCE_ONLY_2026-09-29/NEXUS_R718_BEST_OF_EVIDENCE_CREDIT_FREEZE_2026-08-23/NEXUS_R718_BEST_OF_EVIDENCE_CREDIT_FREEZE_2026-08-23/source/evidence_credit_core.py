from __future__ import annotations
import math, numpy as np
from sklearn.feature_extraction.text import HashingVectorizer
LABELS=list('ABCD'); L2I={a:i for i,a in enumerate(LABELS)}
TEACHERS=['ministral3_3b','phi4mini_3_8b','granite33_2b','qwen3_1_7b','gemma3_1b']
HV=HashingVectorizer(analyzer='char_wb',ngram_range=(2,5),n_features=512,alternate_sign=False,norm='l2',lowercase=True)

def probs_from_row(row):
    if row is None:return np.ones(4,dtype=np.float32)/4
    lp=row.get('option_logprobs') or {}
    z=np.array([lp.get(a,-30.0) if lp.get(a) is not None else -30.0 for a in LABELS],float)
    z=np.nan_to_num(z,nan=-30,posinf=0,neginf=-30);z-=z.max();e=np.exp(np.clip(z,-50,50));s=e.sum();return (e/s if s else np.ones(4)/4).astype(np.float32)

def matrix_from_rows(teacher_rows,mask=None):
    if mask is None:mask=np.array([1. if t in teacher_rows else 0. for t in TEACHERS],np.float32)
    probs=np.stack([probs_from_row(teacher_rows.get(t)) for t in TEACHERS])
    preds=np.array([int(np.argmax(p)) if mask[i] else -1 for i,p in enumerate(probs)])
    return probs,np.asarray(mask,np.float32),preds

def base_features(question,teacher_rows,mask,formal_status='UNKNOWN',formal_answer=None):
    h=HV.transform([question]).toarray().astype(np.float32)
    probs,mask,pred=matrix_from_rows(teacher_rows,mask); p=probs.copy(); p[mask<=0]=0
    conf=probs.max(1)*mask; srt=np.sort(probs,axis=1); margin=(srt[:,-1]-srt[:,-2])*mask
    ent=-(probs*np.log(np.clip(probs,1e-12,1))).sum(1)/math.log(4); ent*=mask
    vote=np.zeros(4,np.float32)
    for c in range(4):vote[c]=float(((pred==c)&(mask>0)).sum())/max(1,float(mask.sum()))
    den=max(1.0,float(mask.sum())); avg=p.sum(0)/den
    masked=np.where(mask[:,None]>0,probs,np.nan)
    maxp=np.nanmax(masked,axis=0) if mask.sum() else np.ones(4)/4
    minp=np.nanmin(masked,axis=0) if mask.sum() else np.ones(4)/4
    stdp=np.nanstd(masked,axis=0) if mask.sum() else np.zeros(4)
    formal=np.zeros(5,np.float32);formal[0]=formal_status=='VERIFIED'
    if formal_answer in L2I:formal[1+L2I[formal_answer]]=1
    simple=np.array([len(question)/400,sum(ch.isdigit() for ch in question)/30,question.casefold().count('если')/5,question.casefold().count('if ')/5,question.count('→')/5],np.float32)
    return np.concatenate([h.ravel(),p.ravel(),mask,conf,margin,ent,vote,avg,maxp,minp,stdp,formal,simple]).astype(np.float32),probs,pred

def candidate_features(question,teacher_rows,mask,candidate,formal_status='UNKNOWN',formal_answer=None):
    xb,probs,pred=base_features(question,teacher_rows,mask,formal_status,formal_answer);mask=np.asarray(mask,np.float32);c=L2I[candidate]
    cand=np.zeros(4,np.float32);cand[c]=1
    pc=probs[:,c]*mask;predc=((pred==c)&(mask>0)).astype(np.float32);den=max(1.0,float(mask.sum()))
    support=np.array([pc.sum()/den],np.float32);vote=np.array([predc.sum()/den],np.float32)
    avg=(probs*mask[:,None]).sum(0)/den; gap=np.array([support[0]-avg.max()],np.float32)
    disagree=np.array([predc.sum()*(mask.sum()-predc.sum())/max(1,mask.sum()**2)],np.float32)
    loo=[]
    full=pc.sum()/den
    for ti in range(5):
        if mask[ti] and mask.sum()>1:loo.append(full-(pc.sum()-pc[ti])/(mask.sum()-1))
        else:loo.append(0.)
    return np.concatenate([xb,cand,pc,predc,support,vote,gap,disagree,np.array(loo,np.float32)]).astype(np.float32)

def candidate_scores(model,question,teacher_rows,mask,formal_status='UNKNOWN',formal_answer=None):
    X=np.stack([candidate_features(question,teacher_rows,mask,a,formal_status,formal_answer) for a in LABELS])
    return model.predict_proba(X)[:,1]

def teacher_query_features(question,teacher_rows,mask,target,formal_status='UNKNOWN',formal_answer=None):
    xb,probs,pred=base_features(question,teacher_rows,mask,formal_status,formal_answer);j=TEACHERS.index(target)
    tid=np.zeros(5,np.float32);tid[j]=1
    # state summary available before querying target
    called=[i for i in range(5) if mask[i]>0]
    consensus=np.zeros(4,np.float32)
    if called:
        for c in range(4):consensus[c]=sum(pred[i]==c for i in called)/len(called)
    return np.concatenate([xb,tid,consensus,np.array([len(called)/5],np.float32)]).astype(np.float32)
