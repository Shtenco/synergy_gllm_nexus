from __future__ import annotations
import ast, math, re
from dataclasses import dataclass

@dataclass
class Result:
    status:str='UNKNOWN'; value:object=None; kind:str='NONE'; proof:str=''

def _norm(s):return str(s).strip().lower().replace('ё','е')
def _match_option(options,val):
    sv=_norm(val)
    exact=[]
    for a,text in options.items():
        if _norm(text)==sv: exact.append(a)
    return exact[0] if len(exact)==1 else None

def _find_option_contains(options, needles, reject=()):
    hits=[]
    for a,text in options.items():
        t=_norm(text)
        if all(_norm(n) in t for n in needles) and not any(_norm(r) in t for r in reject):hits.append(a)
    return hits[0] if len(hits)==1 else None

def solve_numeric(q,options):
    s=_norm(q)
    # long arithmetic chain: (a+b)*c-d, then divide by same c
    m=re.search(r'было\s+(\d+).*?доставили\s+еще\s+(\d+).*?умножили\s+на\s+(\d+).*?списали\s+(\d+).*?распределили\s+между\s+(\d+)',s,re.S)
    if m:
        a,b,c,d,e=map(int,m.groups())
        if c==e and e:
            num=(a+b)*c-d
            if num%e==0:
                v=num//e; ans=_match_option(options,v)
                if ans:return Result('VERIFIED',ans,'LONG_CHAIN',f'(({a}+{b})*{c}-{d})/{e}={v}')
    # LCM
    m=re.search(r'кратное\s+и\s+(\d+)\s*,?\s*и\s+(\d+)',s)
    if m:
        a,b=map(int,m.groups());v=math.lcm(a,b);ans=_match_option(options,v)
        if ans:return Result('VERIFIED',ans,'LCM',f'lcm({a},{b})={v}')
    # unordered pairs / choose 2
    m=re.search(r'(?:из|from)\s+(\d+)\s+(?:различн\w+\s+)?(?:объект|objects)',s)
    if m and ('пар' in s or 'pairs' in s or 'выбрать 2' in s or 'choose 2' in s):
        n=int(m.group(1));v=n*(n-1)//2;ans=_match_option(options,v)
        if ans:return Result('VERIFIED',ans,'PAIRCOUNT',f'C({n},2)={v}')
    m=re.search(r'выбрать\s+2\s+объект\w*\s+из\s+(\d+)',s)
    if m and 'порядок не важ' in s:
        n=int(m.group(1));v=n*(n-1)//2;ans=_match_option(options,v)
        if ans:return Result('VERIFIED',ans,'COMB2',f'C({n},2)={v}')

    # GCD
    m=re.search(r'(?:нод|gcd)\s+(?:чисел\s+)?(\d+)\s+(?:и|and)\s+(\d+)',s)
    if m:
        a,b=map(int,m.groups());v=math.gcd(a,b);ans=_match_option(options,v)
        if ans:return Result('VERIFIED',ans,'GCD',f'gcd({a},{b})={v}')
    # general combination n choose r
    m=re.search(r'выбрать\s+(\d+)\s+объект\w*\s+из\s+(\d+)',s)
    if m and 'порядок не важ' in s:
        r,n=map(int,m.groups())
        if 0<=r<=n:
            v=math.comb(n,r);ans=_match_option(options,v)
            if ans:return Result('VERIFIED',ans,'COMB',f'C({n},{r})={v}')
    # arithmetic progression Russian
    m=re.search(r'последовательност\w*\s+начинается\s+с\s+(-?\d+)\s+и\s+имеет\s+разность\s+(-?\d+).*?(\d+)-й\s+член',s)
    if m:
        a,d,k=map(int,m.groups());v=a+(k-1)*d;ans=_match_option(options,v)
        if ans:return Result('VERIFIED',ans,'ARITH_SEQ',f'{a}+({k}-1)*{d}={v}')
    # bat and ball general algebra
    m=re.search(r'вместе\s+стоят\s+(\d+).*?стоит\s+на\s+(\d+)\s+.*?дороже',s,re.S)
    if m and ('мяч' in s or 'ball' in s):
        total,diff=map(int,m.groups());v=(total-diff)/2
        if float(v).is_integer():
            ans=_match_option(options,int(v))
            if ans:return Result('VERIFIED',ans,'DIFFERENCE_SYSTEM',f'x+(x+{diff})={total}; x={int(v)}')
    return Result()

class BreakSignal(Exception):pass
class SafeInterp:
    def __init__(self):self.env={};self.out=[]
    def ev(self,n):
        if isinstance(n,ast.Constant):return n.value
        if isinstance(n,ast.Name):
            if n.id in self.env:return self.env[n.id]
            if n.id=='range':return range
            if n.id=='len':return len
            raise ValueError('name')
        if isinstance(n,ast.List):return [self.ev(x) for x in n.elts]
        if isinstance(n,ast.Dict):return {self.ev(k):self.ev(v) for k,v in zip(n.keys,n.values)}
        if isinstance(n,ast.Tuple):return tuple(self.ev(x) for x in n.elts)
        if isinstance(n,ast.BinOp):
            a,b=self.ev(n.left),self.ev(n.right)
            if isinstance(n.op,ast.Add):return a+b
            if isinstance(n.op,ast.Sub):return a-b
            if isinstance(n.op,ast.Mult):return a*b
            if isinstance(n.op,ast.FloorDiv):return a//b
            if isinstance(n.op,ast.Mod):return a%b
            if isinstance(n.op,ast.Div):return a/b
            raise ValueError('binop')
        if isinstance(n,ast.Compare):
            a=self.ev(n.left); ok=True
            for op,c in zip(n.ops,n.comparators):
                b=self.ev(c)
                ok &= (a==b if isinstance(op,ast.Eq) else a!=b if isinstance(op,ast.NotEq) else a<b if isinstance(op,ast.Lt) else a<=b if isinstance(op,ast.LtE) else a>b if isinstance(op,ast.Gt) else a>=b if isinstance(op,ast.GtE) else False)
                a=b
            return ok
        if isinstance(n,ast.Subscript):return self.ev(n.value)[self.ev(n.slice)]
        if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.USub):return -self.ev(n.operand)
        if isinstance(n,ast.Call):
            if isinstance(n.func,ast.Name) and n.func.id in ('range','len'):return self.ev(n.func)(*[self.ev(x) for x in n.args])
            if isinstance(n.func,ast.Attribute):
                obj=self.ev(n.func.value); attr=n.func.attr
                if attr=='copy' and isinstance(obj,(dict,list)):return obj.copy()
                raise ValueError('callattr')
            raise ValueError('call')
        raise ValueError(type(n).__name__)
    def assign(self,target,val):
        if isinstance(target,ast.Name):self.env[target.id]=val;return
        if isinstance(target,ast.Subscript):self.ev(target.value)[self.ev(target.slice)]=val;return
        raise ValueError('assign')
    def st(self,n):
        if isinstance(n,ast.Assign):
            val=self.ev(n.value)
            for t in n.targets:self.assign(t,val)
        elif isinstance(n,ast.AugAssign):
            old=self.ev(n.target);v=self.ev(n.value)
            val=old+v if isinstance(n.op,ast.Add) else old-v if isinstance(n.op,ast.Sub) else old*v if isinstance(n.op,ast.Mult) else None
            self.assign(n.target,val)
        elif isinstance(n,ast.Expr) and isinstance(n.value,ast.Call):
            c=n.value
            if isinstance(c.func,ast.Name) and c.func.id=='print':self.out.append(' '.join(str(self.ev(x)) for x in c.args))
            elif isinstance(c.func,ast.Attribute) and c.func.attr=='append':self.ev(c.func.value).append(self.ev(c.args[0]))
            else:self.ev(c)
        elif isinstance(n,ast.If):
            body=n.body if self.ev(n.test) else n.orelse
            for x in body:self.st(x)
        elif isinstance(n,ast.For):
            broke=False
            try:
                for v in self.ev(n.iter):
                    self.assign(n.target,v)
                    try:
                        for x in n.body:self.st(x)
                    except BreakSignal:
                        broke=True;break
            except BreakSignal:broke=True
            if not broke:
                for x in n.orelse:self.st(x)
        elif isinstance(n,ast.Try):
            try:
                for x in n.body:self.st(x)
            except Exception as e:
                handled=False
                for h in n.handlers:
                    if h.type is None or (isinstance(h.type,ast.Name) and h.type.id==type(e).__name__):
                        for x in h.body:self.st(x)
                        handled=True;break
                if not handled: raise
            finally:
                for x in n.finalbody:self.st(x)
        elif isinstance(n,ast.Break):raise BreakSignal()
        else:raise ValueError('stmt '+type(n).__name__)
    def run(self,code):
        tree=ast.parse(code)
        if sum(1 for _ in ast.walk(tree))>100:raise ValueError('too complex')
        banned=(ast.Import,ast.ImportFrom,ast.FunctionDef,ast.ClassDef,ast.Lambda,ast.With,ast.While,ast.Delete,ast.Global,ast.Nonlocal)
        if any(isinstance(x,banned) for x in ast.walk(tree)):raise ValueError('banned')
        for n in tree.body:self.st(n)
        return '\n'.join(self.out)

def solve_code(q,options):
    m=re.search(r'```(?:python)?\s*\n?(.*?)```',q,re.S|re.I)
    if not m:
        m=re.search(r'``\s*\n?(.*?)(?:```|$)',q,re.S|re.I)
    if not m:return Result()
    code=m.group(1).strip()
    try:out=SafeInterp().run(code).strip()
    except Exception:return Result()
    ans=_match_option(options,out)
    if ans:return Result('VERIFIED',ans,'SAFE_PYTHON_EXEC',f'restricted AST execution -> {out}')
    return Result()

def solve_semantic(q,options):
    s=_norm(q)
    # causal graph semantics
    if re.search(r'z\s+причинно\s+влияет\s+и\s+на\s+x\s*,?\s+и\s+на\s+y',s):
        a=_find_option_contains(options,['конфаундер']);
        if a:return Result('VERIFIED',a,'CAUSAL_CONFOUNDER','Z is a common cause of X and Y')
    if 'x влияет на m' in s and 'm влияет на y' in s:
        a=_find_option_contains(options,['медиатор']);
        if a:return Result('VERIFIED',a,'CAUSAL_MEDIATOR','X→M→Y')
    if re.search(r'x\s*→\s*c\s*←\s*y',s) and ('обуслов' in s or 'condition' in s):
        a=_find_option_contains(options,['ложн','зависим']);
        if a:return Result('VERIFIED',a,'COLLIDER_BIAS','conditioning on collider opens a spurious path')
    if 'причинный эффект x на y' in s and ('интервен' in s or 'наблюдатель' in s):
        for a,t in options.items():
            tt=_norm(t)
            if ('принудительно' in tt or 'задать x' in tt) and ('сравн' in tt or 'последств' in tt):return Result('VERIFIED',a,'INTERVENTION','do(X) distinguishes intervention from observation')

    if 'y фактически влияет на измерение x' in s or ('y' in s and 'влияет на' in s and 'измерение x' in s):
        a=_find_option_contains(options,['обратн','причин']);
        if a:return Result('VERIFIED',a,'REVERSE_CAUSALITY','later evidence indicates Y→measured X')
    if 'двое детей' in s and 'хотя бы один' in s and 'мальчик' in s:
        a=_find_option_contains(options,['способ','информац']);
        if a:return Result('VERIFIED',a,'CONDITIONAL_SAMPLING','conditional probability depends on information protocol')
    if 'редкую болезнь' in s and 'чувствительность' in s and 'специфичность' in s:
        a=_find_option_contains(options,['базов','частот']);
        if a:return Result('VERIFIED',a,'BASE_RATE','posterior requires prevalence/base rate')
    if 'три источника повторяют' in s and ('первичн' in s or 'публикац' in s):
        a=_find_option_contains(options,['общ','источник','зависим']);
        if a:return Result('VERIFIED',a,'DEPENDENT_EVIDENCE','shared provenance makes repeated reports dependent')
    if 'дублирует уже использованный источник' in s:
        a=_find_option_contains(options,['останов','ценност']);
        if a:return Result('VERIFIED',a,'VALUE_OF_INFORMATION_STOP','stop when marginal information value is low')
    if 'тестовом импульсе' in s and 'датчик исправен' in s and 'лампа' in s:
        a=_find_option_contains(options,['нельзя заключить','датчик исправен']);
        if a:return Result('VERIFIED',a,'ALTERNATIVE_CAUSE_REVISION','alternative cause of lamp defeats affirming the consequent')
    if '4, 7, 11, 16' in s and '+3, +4, +5' in s:
        v=22;ans=_match_option(options,v)
        if ans:return Result('VERIFIED',ans,'INCREMENT_SEQUENCE_REVISION','increments 3,4,5 imply next increment 6; 16+6=22')
    # invalid syllogism / deterministic mean-reversion fallacy
    if 'все зорбы' in s and 'некоторые лемы' in s:
        a=_find_option_contains(options,['не следует']);
        if a:return Result('VERIFIED',a,'INVALID_SYLLOGISM','All Z are L and Some L are T does not entail Some Z are T')
    if 'пять дней подряд росла' in s and ('обязана упасть' in s or 'возврат' in s):
        a=_find_option_contains(options,['нет','обязатель']);
        if a:return Result('VERIFIED',a,'NO_DETERMINISTIC_MEAN_REVERSION','past streak does not logically force reversal')

    # canonical data-structure semantics inherited from the R7.2 unseen-operator line.
    if ('стек' in s or 'stack' in s) and ('извлека' in s or 'removed' in s or 'pop' in s):
        # Recover the ordered symbols after an explicit element-list phrase when possible.
        m=re.search(r'(?:элемент\w*|elements?)\s+([a-zа-я0-9]+)\s*,\s*([a-zа-я0-9]+)\s*,\s*([a-zа-я0-9]+)',s,re.I)
        if m:
            v=m.group(3).upper(); ans=_match_option(options,v)
            if ans:return Result('VERIFIED',ans,'STACK_LIFO',f'push order {m.group(1)},{m.group(2)},{m.group(3)} -> pop {v}')
    if ('очеред' in s or 'queue' in s) and ('извлека' in s or 'removed' in s or 'dequeue' in s):
        m=re.search(r'(?:элемент\w*|elements?)\s+([a-zа-я0-9]+)\s*,\s*([a-zа-я0-9]+)\s*,\s*([a-zа-я0-9]+)',s,re.I)
        if m:
            v=m.group(1).upper(); ans=_match_option(options,v)
            if ans:return Result('VERIFIED',ans,'QUEUE_FIFO',f'enqueue order {m.group(1)},{m.group(2)},{m.group(3)} -> dequeue {v}')
    # query policy principles inherited from proof-first
    if 'формальное доказательство' in s and 'слаб' in s and 'эксперт' in s:
        a=_find_option_contains(options,['проверенн','доказатель','приоритет']);
        if a:return Result('VERIFIED',a,'PROOF_PRIORITY','verified proof dominates unsupported weak vote')
    if 'два независимых сильных источника' in s and 'разные ответы' in s:
        a=_find_option_contains(options,['дополнительн','независим']);
        if a:return Result('VERIFIED',a,'EVIDENCE_QUERY','conflict warrants independent discriminating evidence')
    if 'среднюю уверенность' in s and 'два независимых источника расходятся' in s:
        a=_find_option_contains(options,['дополнительн','тест']);
        if a:return Result('VERIFIED',a,'DISCRIMINATING_TEST','query a discriminating independent test')
    # revision after new evidence
    if 'y = x' in q and 'y.append(3)' in q and '[1,2,3]' in q:
        a=_find_option_contains(options,['ссылаются','один список']);
        if a:return Result('VERIFIED',a,'ALIASING_REVISION','mutation evidence implies aliasing')
    if 'конкурент закрыл магазины' in s and 'реклам' in s:
        a=_find_option_contains(options,['эффект','не идентифицирован']);
        if a:return Result('VERIFIED',a,'CAUSAL_REVISION','new concurrent cause destroys identification')
    if 'узел c' in s and 'вызывает и a, и отказ' in s:
        a=_find_option_contains(options,['коррелят','общей причины']);
        if a:return Result('VERIFIED',a,'COMMON_CAUSE_REVISION','C explains association A↔failure')
    return Result()

def solve(item):
    q=item['q']; options=item['options']
    for fn in (solve_code,solve_numeric,solve_semantic):
        r=fn(q,options)
        if r.status=='VERIFIED':return r
    return Result()
