from __future__ import annotations
import re

def _exact_option(options,val):
    sval=str(val).strip()
    hits=[a for a,t in options.items() if str(t).strip()==sval]
    return hits[0] if len(hits)==1 else None

def repair(item,formal):
    if formal.get('status')!='VERIFIED':return formal
    f=dict(formal);ir=f.get('ir') or {};args=ir.get('args') or {};op=args.get('op');opts=item.get('options') or {}
    # Stress is encoded by uppercase vowel position; casefolding destroys the proof signal.
    if op=='stress_lexicon':
        acc=args.get('accent') or ((f.get('proof') or {}).get('conclusion'))
        a=_exact_option(opts,acc)
        if a:
            f['answer']=a;f['integrity']={'status':'REPAIRED_VERIFIED','rule':'exact_stress_surface_match'};return f
        f['status']='UNKNOWN';f['integrity']={'status':'REJECTED','reason':'proof conclusion not uniquely represented by an option'};return f
    if op=='government':
        case=args.get('case')
        if case=='dative':
            hits=[]
            primary=[]; secondary=[]
            for a,t in opts.items():
                x=str(t).strip().casefold(); last=x.split()[-1]
                # High-precision dative surfaces seen across Russian declensions:
                # plural -ам/-ям; 1st decl. sg -е; 3rd decl. sg -и; adjective+noun keeps noun dative.
                if re.search(r'(?:ам|ям|е|и)$',last): primary.append(a)
                # Masculine/neuter dative endings are kept only as fallback because -у/-ю can
                # collide with feminine accusative surfaces in option sets.
                elif re.search(r'(?:ому|ему|у|ю)$',last): secondary.append(a)
            hits=primary if len(primary)==1 else (secondary if len(primary)==0 and len(secondary)==1 else [])
            if len(hits)==1:
                f['answer']=hits[0];f['integrity']={'status':'REPAIRED_VERIFIED','rule':'unique_dative_surface'};return f
            f['status']='UNKNOWN';f['integrity']={'status':'REJECTED','reason':'dative conclusion lacks unique surface realization'};return f
    # Scalar proof conclusions may be remapped by exact surface without weakening verification.
    concl=(f.get('proof') or {}).get('conclusion')
    if isinstance(concl,(str,int,float)):
        a=_exact_option(opts,concl)
        if a and f.get('answer')!=a:
            f['answer']=a;f['integrity']={'status':'REPAIRED_VERIFIED','rule':'exact_scalar_surface_match'}
    return f
