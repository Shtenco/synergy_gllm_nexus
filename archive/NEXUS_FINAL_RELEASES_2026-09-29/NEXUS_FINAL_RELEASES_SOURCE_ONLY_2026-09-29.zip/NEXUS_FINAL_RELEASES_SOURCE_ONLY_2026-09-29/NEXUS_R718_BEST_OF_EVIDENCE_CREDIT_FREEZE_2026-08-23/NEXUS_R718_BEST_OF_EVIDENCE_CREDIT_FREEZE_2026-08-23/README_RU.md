# NEXUS R7.18 — BEST-OF-NEXUS EVIDENCE CREDIT ASSIGNMENT CORE

R7.18 объединяет только те механизмы прежней линии, которые либо имели сильный fresh-blind результат, либо закрывают конкретный bottleneck, обнаруженный Blind-30.

## Активная архитектура

1. **R7.2-style Natural Structural Binder** — переводит распознаваемые natural-language задачи в исполнимые операторы (LIFO/FIFO, GCD/LCM, комбинации, арифметические цепочки, restricted Python AST, causal operators).
2. **R7.10 Proof-First + Proof Integrity Adapter** — verified proof остаётся высшим authority, но proof→option binding теперь независимо проверяется и может быть repaired/rejected.
3. **R7.14 MorphoLex** — multilingual implication binding для 10-язычного слоя.
4. **R7.13 H↔T / R7.16 BIP39 query cybernetics** — сохранены в base R7.17; BIP39 используется только как exploration/tie-break, никогда как evidence истины.
5. **R7.17 recurrent/SEAL/quantum advisory** — сохранён byte-for-byte как auxiliary organ; direct answer authority не передан ему.
6. **R7.18 Evidence Credit Assignment** — отдельная оценка каждого кандидата A/B/C/D по evidence, counterfactual leave-one-organ contribution, disagreement, confidence и question structure.
7. **R7.18 Next-Teacher Credit** — прогноз того, какой ещё независимый organ вероятнее всего даст полезное evidence; recurrent/BIP39 используются только для слабого tie-break.
8. **Stepwise verification** — ответ фиксируется при высоком credit либо после устойчивого подтверждения новым organ; максимум 5 teacher calls.

## Development / regression results

Эти результаты НЕ являются fresh blind после разработки R7.18:

- B22–B28 disclosed replay: **624/624 = 100%**.
- Blind-30 disclosed replay after analyzing Blind-30: **200/200 = 100%**, mean teacher calls 0.0, потому что весь набор был покрыт verified structural/multilingual operators после его анализа.
- Credit-only model trained on B22–B28, before adding B30 labels to credit training: **131/200 = 65.5%** on B30 evidence vs frozen R7.16 **129/200 = 64.5%**.
- 4-fold B30 OOF after including other B30 folds in training: **140/200 = 70.0%**. Это development evidence, не confirmatory.

Blind-30 после его раскрытия является только regression/development set. Он не используется для заявления о blind-обобщении R7.18.

## Scientific boundary

На момент freeze **Blind-31 DOES NOT EXIST**. Любое подтверждение улучшения R7.18 должно быть получено только на post-freeze Blind-31 без изменения source/models/thresholds.
