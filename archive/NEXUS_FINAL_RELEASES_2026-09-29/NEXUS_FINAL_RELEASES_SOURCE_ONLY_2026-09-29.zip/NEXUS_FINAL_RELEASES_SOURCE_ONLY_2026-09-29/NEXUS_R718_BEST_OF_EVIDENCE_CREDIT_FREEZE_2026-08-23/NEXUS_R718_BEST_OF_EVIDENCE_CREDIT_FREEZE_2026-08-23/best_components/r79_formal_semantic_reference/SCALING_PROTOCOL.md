# R7.9×N — Identical-node collective proof-search protocol

Frozen before the final scaling benchmark is generated.

- task family: planted satisfiable 3-SAT
- variables: 36
- clauses: 150
- identical node algorithm: `IdenticalProofNode`
- per-node budget: 120 local flips
- local noise: 0.12
- exchange interval: 40 flips
- peer adoption cap: 30% of differing variables
- topology:
  - N=2: one bidirectional edge
  - N=3: ring
  - N>=4: ring + i→i+2 shortcut
- route diversity: same code and state schema, different deterministic `route_seed`
- coupling payload: only best proof-search assignment/state; no answer label, no benchmark metadata
- final N values: 1,2,3,4,5
- equal-compute controls:
  - one node with 2B flips
  - two independent identical nodes with B each, no exchange
- primary two-node success criterion:
  1. coupled N=2 solve rate > N=1 solve rate
  2. coupled N=2 solve rate >= independent N=2
  3. coupled N=2 solve rate > single N=1 with 2B equal total flip budget
- scaling diagnostic:
  fit `e(N)=e1*exp(-a*(N**beta-1))`.
  `0 < beta < 1` is reported as subexponential error decay only if fit is stable and observed error decreases monotonically enough for interpretation.
