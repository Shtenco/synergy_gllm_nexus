# NEXUS R7.9 — Formal Semantic IR + Proof Objects + Evidence Independence

## Sovereignty pipeline

Natural Language
→ Semantic Compiler
→ typed Formal IR
→ domain Solver / Prover
→ immutable Proof Object
→ independent Verifier
→ VERIFIED / UNKNOWN / REJECTED

Only VERIFIED proofs may directly determine the answer.

UNKNOWN/REJECTED routes to the foreign-evidence plane:

Question-conditioned Meta-Teacher Selector
→ Node-0 primary evidence
→ Node-1 same NEXUS runtime with complementary route state
→ two-node evidence graph
→ calibrated competence + error-correlation independence
→ conservative peer switch
→ Trust Governor / fallback.

## Identical-node definition

The two R7.9 nodes have:
- identical NEXUS architecture;
- identical native weights;
- identical Formal Compiler / Solver / Verifier code;
- identical meta-selector and calibration parameters.

They differ only in **route state / phase**. This is intentional cognitive orthogonalization, not a second separately trained model.

## Hard invariants

1. Native VERIFIED proof overrides foreign evidence.
2. Verifier is a separate implementation from the Solver.
3. Compiler/solver/verifier are frozen before Blind-26 creation.
4. Dual-node calibrator is trained only on already disclosed real Blind-22/24/25 evidence.
5. Blind-26 teacher outputs/logits cannot modify routing, proof code, calibration, or thresholds.
6. Native R7-L core and R7.2 binder are immutable.
7. “Subexponential growth” is not inferred from two points. It is tested separately on N=1..5 identical proof-search nodes with a frozen scaling protocol.
