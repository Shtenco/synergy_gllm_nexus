import re,json,math,random,hashlib,time,itertools,zipfile
from pathlib import Path
import numpy as np, torch
import torch.nn as nn, torch.nn.functional as F
ROOT=Path('/mnt/data/_r7l/NEXUS_R7L_FAST_LEARNING_UNSEEN_OPERATOR_D192_2026-08-18')
OUT=Path('/mnt/data/NEXUS_R72_DISENTANGLED_NATURAL_UNSEEN_2026-08-18');OUT.mkdir(exist_ok=True)
torch.set_num_threads(4)
D=192;PERMS=list(itertools.permutations(range(4)));OPS=[(p,q) for p in PERMS for q in PERMS];rr=random.Random(20260818);rr.shuffle(OPS);TRAIN_OPS=OPS[:448];HELD=OPS[512:]
STATE=['янтарь','лазурь','графит','нефрит'];EFFECT=['север','восток','юг','запад'];ACTION=['мост','маяк','контур','шлюз']
class R7(nn.Module):
 def __init__(self,d=D,steps=3):
  super().__init__();self.d=d;self.steps=steps;self.demo=nn.Sequential(nn.Linear(12,d),nn.GELU(),nn.Linear(d,d),nn.LayerNorm(d));self.query=nn.Sequential(nn.Linear(6,d),nn.GELU(),nn.Linear(d,d),nn.LayerNorm(d));self.sk=nn.Linear(d,d,bias=False);self.sv=nn.Linear(d,d,bias=False);self.hq=nn.Linear(d,d,bias=False);self.msg=nn.Sequential(nn.Linear(2*d,2*d),nn.GELU(),nn.Linear(2*d,d));self.g=nn.Linear(2*d,d);self.ln=nn.LayerNorm(d);self.eh=nn.Linear(d,4);self.ah=nn.Linear(d,4);self.halt=nn.Linear(d,1);self.ie=nn.Embedding(2,d)
 def forward(self,Sraw,Q):
  S=self.demo(Sraw);h=self.query(Q)+self.ie(Q[:,4:].argmax(-1));states=[];ps=[]
  for _ in range(self.steps):
   att=(self.hq(h)[:,None]@self.sk(S).transpose(-1,-2)/math.sqrt(self.d)).softmax(-1);mem=(att@self.sv(S)).squeeze(1);cand=self.msg(torch.cat([h,mem],-1));g=.08+.22*torch.sigmoid(self.g(torch.cat([h,mem],-1)));h=self.ln((1-g)*h+g*cand);states.append(h);ps.append(torch.sigmoid(self.halt(h)).squeeze(-1))
  rem=torch.ones(h.shape[0]);ws=[]
  for k,p in enumerate(ps):w=rem if k==len(ps)-1 else rem*p;ws.append(w);rem=rem*(1-p)
  W=torch.stack(ws,1);W=W/(W.sum(1,keepdim=True)+1e-9);z=sum(states[k]*W[:,k,None] for k in range(len(states)));return self.eh(z),self.ah(z)
core=R7();core.load_state_dict(torch.load(ROOT/'r7_seed712.pt',map_location='cpu'));core.eval()
for p in core.parameters():p.requires_grad=False

N=4096
def grams(t):
 t='^'+t.lower()+'$';a=[]
 for n in (3,4,5):
  for i in range(len(t)-n+1):a.append(int(hashlib.blake2b(t[i:i+n].encode(),digest_size=8).hexdigest(),16)%N)
 return a or [0]
def bag(xs):
 flat=[];off=[];c=0
 for x in xs:off.append(c);z=grams(x);flat+=z;c+=len(z)
 return torch.tensor(flat),torch.tensor(off)
class SpanClassifier(nn.Module):
 def __init__(self,out):super().__init__();self.e=nn.EmbeddingBag(N,48,mode='mean');self.m=nn.Sequential(nn.Linear(48,96),nn.GELU(),nn.Linear(96,out))
 def forward(self,xs):x,o=bag(xs);return self.m(self.e(x,o))
state_cl=SpanClassifier(4);eff_cl=SpanClassifier(4);act_cl=SpanClassifier(4);intent_cl=SpanClassifier(2)
params=list(state_cl.parameters())+list(eff_cl.parameters())+list(act_cl.parameters())+list(intent_cl.parameters());opt=torch.optim.AdamW(params,lr=3e-3,weight_decay=.01)
# Broad pre-freeze instruction grammar. Blind20 sentences are composed differently and not listed here.
E_PH=['какой эффект','какое следствие','какой результат','что получится','что произойдет','какой выход','что станет итогом','что предсказывает правило','что вернет механизм','что наблюдаем на выходе']
A_PH=['какое действие','какую команду','что сделать регулятору','какое управление','какой управляющий шаг','какую коррекцию выбрать','что должен сделать контроллер','какой сигнал управления','какое решение принять','что выбрать исполнителю']
PREFIX=['определи','вычисли','скажи','укажи','найди','по примерам установи','используя скрытое правило определи','после демонстраций реши']
SUFFIX=['для нового состояния','по найденному оператору','согласно закономерности','не меняя правила','для текущего входа','по изученным примерам']
# train isolated lexical labels and instruction channel
r=random.Random(7201)
for step in range(220):
 xs=[];ys=[];xe=[];ye=[];xa=[];ya=[];xi=[];yi=[]
 for _ in range(48):
  i=r.randrange(4);xs.append(r.choice(['{}','метка {}','состояние {}','режим {}']).format(STATE[i]));ys.append(i)
  i=r.randrange(4);xe.append(r.choice(['{}','эффект {}','результат {}','следствие {}']).format(EFFECT[i]));ye.append(i)
  i=r.randrange(4);xa.append(r.choice(['{}','действие {}','команда {}','управление {}']).format(ACTION[i]));ya.append(i)
  intent=r.randrange(2);ph=r.choice(E_PH if intent==0 else A_PH);xi.append(f'{r.choice(PREFIX)} {ph} {r.choice(SUFFIX)}');yi.append(intent)
 loss=F.cross_entropy(state_cl(xs),torch.tensor(ys))+F.cross_entropy(eff_cl(xe),torch.tensor(ye))+F.cross_entropy(act_cl(xa),torch.tensor(ya))+1.3*F.cross_entropy(intent_cl(xi),torch.tensor(yi))
 opt.zero_grad();loss.backward();opt.step()

def spans(t):return re.findall(r'«([^»]+)»',t)
def contentless(t):return re.sub(r'«[^»]+»',' ',t)
def sup_text(s,e,a,k):
 T=[f'Опыт номер {k}: режим «{s}» дал следствие «{e}», а регулятор выбрал «{a}».',f'В демонстрации {k} состояние «{s}» связано с результатом «{e}» и командой «{a}».',f'Наблюдение {k}: при «{s}» появляется «{e}», управление — «{a}».']
 return T[k%len(T)]
def parse_support(texts):
 ss=[];ee=[];aa=[]
 for t in texts:
  q=spans(t);ss.append(q[0]);ee.append(q[1]);aa.append(q[2])
 ps=state_cl(ss).argmax(-1);pe=eff_cl(ee).argmax(-1);pa=act_cl(aa).argmax(-1);S=torch.zeros(len(texts),12);S[range(len(texts)),ps]=1;S[range(len(texts)),4+pe]=1;S[range(len(texts)),8+pa]=1;return S,(ps,pe,pa)
def parse_query(texts):
 st=[spans(t)[0] for t in texts];qst=state_cl(st).argmax(-1);it=intent_cl([contentless(t) for t in texts]).argmax(-1);Q=torch.zeros(len(texts),6);Q[range(len(texts)),qst]=1;Q[range(len(texts)),4+it]=1;return Q,(qst,it)
# freeze before Blind20
weights=OUT/'r72_language_binder.pt';torch.save({'state':state_cl.state_dict(),'effect':eff_cl.state_dict(),'action':act_cl.state_dict(),'intent':intent_cl.state_dict()},weights)
freeze={'name':'R7.2 Disentangled Russian Language Binder + frozen R7-L','binder_sha256':hashlib.sha256(weights.read_bytes()).hexdigest(),'core_sha256':hashlib.sha256((ROOT/'r7_seed712.pt').read_bytes()).hexdigest(),'operator_authority':'NONE','train_operators':448,'heldout_pool':64,'blind20_created_after_freeze':True,'content_instruction_disentangled':True,'boundary':'Natural-language interface to unseen structured operators; labels are lexically grounded before test.'};(OUT/'00_FREEZE_MANIFEST.json').write_text(json.dumps(freeze,ensure_ascii=False,indent=2),encoding='utf-8')
# Blind20 = 16 heldout operators never used in Blind19. Construct after freeze.
old=HELD.copy();random.Random(2026081819).shuffle(old);used=set(old[:48]);blind=[o for o in HELD if o not in used]
E_BL=['После этих примеров для состояния «{s}» требуется назвать лишь непосредственный итог.','У нового входа «{s}» какой выход порождает выведенная закономерность?','Если механизм получает «{s}», укажи наблюдаемое последствие, не управляющую команду.','Применив правило к «{s}», что следует ожидать как результат процесса?','Как завершится преобразование для «{s}» в части эффекта?']
A_BL=['После этих примеров для состояния «{s}» требуется назвать лишь управляющее решение.','У нового входа «{s}» какой сигнал должен выдать регулятор?','Если механизм получает «{s}», укажи корректирующую команду, не последствие.','Применив правило к «{s}», что следует выбрать как действие управления?','Как должен отреагировать контроллер на «{s}»?']
correct=total=0;per=[];parser=parserN=0;r=random.Random(7220)
with torch.no_grad():
 for oi,op in enumerate(blind):
  ok=n=0
  for rep in range(20):
   qs=r.randrange(4);intent=r.randrange(2);sup=[s for s in range(4) if s!=qs];r.shuffle(sup);p,a=op
   texts=[sup_text(STATE[s],EFFECT[p[s]],ACTION[a[s]],j+r.randrange(3)) for j,s in enumerate(sup)];q=(r.choice(E_BL if intent==0 else A_BL)).format(s=STATE[qs])
   Sflat,pp=parse_support(texts);S=Sflat.view(1,3,12);Q,pq=parse_query([q]);el,al=core(S,Q);pred=int((el if intent==0 else al).argmax(-1));y=(p if intent==0 else a)[qs];ok+=pred==y;n+=1;correct+=pred==y;total+=1
   # parsing components
   for j,s in enumerate(sup):parser+=int(pp[0][j]==s)+int(pp[1][j]==p[s])+int(pp[2][j]==a[s]);parserN+=3
   parser+=int(pq[0][0]==qs)+int(pq[1][0]==intent);parserN+=2
  per.append(ok/n)
res={'accuracy':correct/total,'operator_all_queries':float(np.mean([x==1 for x in per])),'worst_operator':float(min(per)),'parser_component_accuracy':parser/parserN,'operators':len(blind),'n':total}
(OUT/'01_BLIND20_RESULTS.json').write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding='utf-8');(OUT/'train_r72_disentangled_language.py').write_text(Path('/mnt/data/train_r72_disentangled_language.py').read_text(),encoding='utf-8');(OUT/'README_RU.md').write_text('# NEXUS R7.2\n\n'+json.dumps({'freeze':freeze,'blind20':res},ensure_ascii=False,indent=2),encoding='utf-8')
files=[p for p in OUT.iterdir() if p.is_file() and p.name!='SHA256SUMS.txt'];(OUT/'SHA256SUMS.txt').write_text('\n'.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}' for p in sorted(files))+'\n')
zp=Path('/mnt/data/NEXUS_R72_DISENTANGLED_NATURAL_UNSEEN_2026-08-18.zip');
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in OUT.iterdir():z.write(p,arcname=OUT.name+'/'+p.name)
print('RESULT',res);print('ZIP',zp,hashlib.sha256(zp.read_bytes()).hexdigest())
