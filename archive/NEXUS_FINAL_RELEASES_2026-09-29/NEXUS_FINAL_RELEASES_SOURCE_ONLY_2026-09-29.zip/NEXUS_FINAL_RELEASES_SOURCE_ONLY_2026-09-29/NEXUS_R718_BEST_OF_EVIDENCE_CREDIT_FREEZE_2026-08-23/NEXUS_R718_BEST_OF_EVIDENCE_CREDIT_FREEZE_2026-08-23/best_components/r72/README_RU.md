# NEXUS R7.2

{
  "freeze": {
    "name": "R7.2 Disentangled Russian Language Binder + frozen R7-L",
    "binder_sha256": "b6ef32052ddd3144dde76a84a81c41b5d7caf7761d5658eed18ebee21bef5eb7",
    "core_sha256": "a6b949fde908aa801b5c69e702e1710d32e84e1c2627d0fadd9aab71e5cb7c18",
    "operator_authority": "NONE",
    "train_operators": 448,
    "heldout_pool": 64,
    "blind20_created_after_freeze": true,
    "content_instruction_disentangled": true,
    "boundary": "Natural-language interface to unseen structured operators; labels are lexically grounded before test."
  },
  "blind20": {
    "accuracy": 1.0,
    "operator_all_queries": 1.0,
    "worst_operator": 1.0,
    "parser_component_accuracy": 0.98125,
    "operators": 16,
    "n": 320
  }
}