# Best-of-NEXUS consolidation

- **R6.10 Ω**: closed-world invariants retained as reference only; its closed-world answer head is NOT activated outside its boundary.
- **R7.2**: exact frozen legacy weights/source preserved under `best_components/r72`; active R7.18 uses the proven design principle `natural language -> structured operator -> execution/verifier` and adds general operator adapters.
- **R7.8**: authority-first arbitration policy retained as reference; direct old router is superseded by R7.16/R7.18 evidence credit.
- **R7.9/R7.10**: formal semantic/proof-first line active; proof object is sovereign only after R7.18 Proof Integrity remapping.
- **R7.13**: hypothesis-test cyberloop inherited through base R7.17.
- **R7.14**: MorphoLex active for multilingual structural binding.
- **R7.15**: compression/pattern state inherited through base R7.17, advisory/feature role only.
- **R7.16**: BIP39 adaptive query scheduling inherited; BIP39 cannot vote for truth.
- **R7.17**: recurrent BDH-inspired state, SEAL adapter and quantum-inspired forecasting inherited as advisory organs.
- **R7.18**: new primary non-proof organ: Evidence Credit Assignment + Next-Teacher Credit + stepwise verification.
