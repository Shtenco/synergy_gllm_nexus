# Scientific status at R7.18 freeze

- R7.18 architecture was designed after Blind-30 was disclosed.
- Therefore Blind-30 replay is **not blind**, even if accuracy is 100%.
- Blind-30-derived rules are deliberately written as general executable operators rather than benchmark-ID lookups; no benchmark IDs, gold labels, `meta`, or hidden answer table are used by runtime.
- The fresh confirmatory benchmark is Blind-31 and must be created only after this freeze.
- No source/model/threshold changes are permitted after Blind-31 generation if Blind-31 is to remain confirmatory.
