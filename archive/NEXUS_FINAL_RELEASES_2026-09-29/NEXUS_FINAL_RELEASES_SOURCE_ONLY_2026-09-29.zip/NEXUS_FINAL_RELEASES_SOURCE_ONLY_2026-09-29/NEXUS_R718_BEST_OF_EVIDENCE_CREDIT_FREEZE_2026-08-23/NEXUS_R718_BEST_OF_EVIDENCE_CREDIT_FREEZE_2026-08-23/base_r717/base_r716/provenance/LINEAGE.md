R7.16 embeds the complete R7.15 freeze unchanged under base_r715/. R7.15 in turn embeds R7.14, which embeds R7.13. The original infograph.py is preserved separately.
