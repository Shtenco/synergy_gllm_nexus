from __future__ import annotations
from dataclasses import dataclass
from collections import Counter
import math, re, zlib, lzma
import brotli
import numpy as np

# NEXUS R7.15 compression/pattern core.
# Structural sensors intentionally mirror the active SHTENCO ai_compress Tier-1 v2
# feature family: entropy, printable/zero ratios, adjacent repeats, local smoothness,
# block similarity and repeated atoms. Reversible transforms mirror delta/XOR/RLE.

TOKEN_RE = re.compile(r"\w+|[^\w\s]", re.UNICODE)


def _b(text: str) -> bytes:
    return text.encode('utf-8', errors='surrogatepass')


def entropy_bytes(data: bytes) -> float:
    if not data: return 0.0
    n=len(data); c=Counter(data)
    return -sum((v/n)*math.log2(v/n) for v in c.values())


def structural_features(data: bytes) -> np.ndarray:
    sample=data[:min(len(data),8192)]; n=max(1,len(sample)); c=Counter(sample)
    entropy=-sum((v/n)*math.log2(v/n) for v in c.values()) if sample else 0.0
    printable=sum(x in (9,10,13) or 32<=x<127 for x in sample)/n
    zero=sample.count(0)/n
    adjacent=sum(sample[i]==sample[i-1] for i in range(1,len(sample)))/n
    smooth=sum(abs(sample[i]-sample[i-1])<=2 for i in range(1,len(sample)))/n
    similar=0.0
    half=min(4096,len(data)//2)
    if half: similar=sum(a==b for a,b in zip(data[:half],data[half:2*half]))/half
    atoms=[sample[i:i+16] for i in range(0,len(sample)-15,16)]
    atom_repeat=1.0-len(set(atoms))/len(atoms) if atoms else 0.0
    return np.array([entropy/8.0,printable,zero,adjacent,smooth,similar,atom_repeat],np.float32)


def delta(data: bytes, order:int=1)->bytes:
    out=data
    for _ in range(order):
        prev=0; b=bytearray(len(out))
        for i,v in enumerate(out): b[i]=(v-prev)&255; prev=v
        out=bytes(b)
    return out


def xor_lag(data: bytes, lag:int)->bytes:
    if lag<=0 or lag>=len(data): return data
    out=bytearray(data)
    for i in range(len(out)-1,lag-1,-1): out[i]^=data[i-lag]
    return bytes(out)


def rle(data: bytes)->bytes:
    out=bytearray(); i=0
    while i<len(data):
        run=1
        while i+run<len(data) and data[i+run]==data[i] and run<65535: run+=1
        if run>=4:
            out.extend((1,(run>>8)&255,run&255,data[i])); i+=run; continue
        start=i; i+=run
        while i<len(data):
            nr=1
            while i+nr<len(data) and data[i+nr]==data[i] and nr<65535: nr+=1
            if nr>=4 or i-start>=65535: break
            i+=nr
        lit=data[start:i]; L=len(lit)
        out.extend((0,(L>>8)&255,L&255)); out.extend(lit)
    return bytes(out)


def _raw_deflate(data:bytes,level:int=9,zdict:bytes|None=None)->int:
    kw=dict(level=level,wbits=-15)
    if zdict: kw['zdict']=zdict
    co=zlib.compressobj(**kw); return len(co.compress(data)+co.flush())


def codec_lengths(data:bytes,zdict:bytes|None=None)->dict[str,int]:
    if not data: return {'raw':0,'deflate':0,'deflate_dict':0,'brotli':0,'lzma':0,'delta1':0,'delta2':0,'xor1':0,'xor4':0,'xor16':0,'rle':0}
    out={
      'raw':len(data),
      'deflate':_raw_deflate(data,9),
      'deflate_dict':_raw_deflate(data,9,zdict) if zdict else _raw_deflate(data,9),
      'brotli':len(brotli.compress(data,quality=9)),
      'lzma':len(lzma.compress(data,preset=6)),
      'delta1':_raw_deflate(delta(data,1),9),
      'delta2':_raw_deflate(delta(data,2),9),
      'xor1':_raw_deflate(xor_lag(data,1),9),
      'xor4':_raw_deflate(xor_lag(data,4),9),
      'xor16':_raw_deflate(xor_lag(data,16),9),
      'rle':_raw_deflate(rle(data),9),
    }
    return out


def repeated_ngram_features(text:str)->np.ndarray:
    # Patternization proxies: repeated character atoms, token reuse, longest repeated atom.
    s=text.casefold(); vals=[]
    for n in (2,3,4,6,8):
        grams=[s[i:i+n] for i in range(max(0,len(s)-n+1))]
        vals.append(0.0 if not grams else 1-len(set(grams))/len(grams))
    toks=TOKEN_RE.findall(s)
    tok_rep=0.0 if not toks else 1-len(set(toks))/len(toks)
    big=[tuple(toks[i:i+2]) for i in range(max(0,len(toks)-1))]
    bi_rep=0.0 if not big else 1-len(set(big))/len(big)
    return np.array(vals+[tok_rep,bi_rep],np.float32)


def longest_common_substring_ratio(a:str,b:str)->float:
    # O(n*m), fine for short MCQ strings.
    a=a.casefold(); b=b.casefold()
    if not a or not b: return 0.0
    prev=[0]*(len(b)+1); best=0
    for ca in a:
        cur=[0]
        for j,cb in enumerate(b,1):
            x=prev[j-1]+1 if ca==cb else 0
            cur.append(x); best=max(best,x)
        prev=cur
    return best/max(1,min(len(a),len(b)))


@dataclass
class PatternDictionary:
    patterns:list[str]
    scores:dict[str,float]
    zdict:bytes

    @classmethod
    def fit(cls,texts:list[str],max_patterns:int=256,max_zdict:int=24000):
        # Unsupervised MDL dictionary. No labels/gold are consumed.
        counts=Counter()
        for text in texts:
            s=' '.join(TOKEN_RE.findall(text.casefold()))
            # character atoms 3..12 sampled at stride 1 for compact corpora
            for n in (3,4,5,6,8,10,12):
                for i in range(max(0,len(s)-n+1)):
                    g=s[i:i+n]
                    if not g.strip(): continue
                    counts[g]+=1
            toks=s.split()
            for n in (1,2,3):
                for i in range(max(0,len(toks)-n+1)):
                    g=' '.join(toks[i:i+n]); counts[g]+=1
        scored=[]
        for p,c in counts.items():
            if c<3: continue
            # Approximate MDL savings: repeated literal bytes avoided minus one dictionary definition.
            savings=(len(_b(p))-1)*(c-1)-len(_b(p))
            if savings>0: scored.append((float(savings),c,p))
        scored.sort(reverse=True)
        pats=[]; seen=set()
        for score,c,p in scored:
            # reduce near-duplicate dictionary pollution
            if p in seen: continue
            pats.append(p); seen.add(p)
            if len(pats)>=max_patterns: break
        # zlib's dictionary benefits from frequent suffixes; put highest-score patterns last.
        zb=bytearray()
        for p in reversed(pats):
            q=_b(p)+b'\n'
            if len(zb)+len(q)>max_zdict: continue
            zb.extend(q)
        scores={p:next(s for s,c,q in scored if q==p) for p in pats}
        return cls(pats,scores,bytes(zb))

    def greedy_parse(self,text:str)->dict[str,float]:
        s=text.casefold(); i=0; used=[]; literals=0
        byfirst={}
        for p in self.patterns: byfirst.setdefault(p[:1],[]).append(p)
        for k in byfirst: byfirst[k].sort(key=len,reverse=True)
        while i<len(s):
            hit=None
            for p in byfirst.get(s[i:i+1],[]):
                if s.startswith(p,i): hit=p; break
            if hit:
                used.append(hit); i+=len(hit)
            else:
                literals+=1; i+=1
        raw_bits=max(1,len(_b(s))*8)
        id_bits=max(1,math.ceil(math.log2(max(2,len(self.patterns)))))
        code_bits=literals*8+len(used)*(id_bits+1)
        uniq=len(set(used)); meanlen=np.mean([len(x) for x in used]) if used else 0.0
        maxlen=max([len(x) for x in used],default=0)
        weighted=sum(self.scores.get(x,0.) for x in used)/max(1,len(_b(s)))
        return {'ratio':code_bits/raw_bits,'coverage':1-literals/max(1,len(s)),'n_patterns':len(used)/max(1,len(s)),
                'unique_patterns':uniq/max(1,len(self.patterns)),'mean_len':meanlen/12.,'max_len':maxlen/12.,'weighted_savings':weighted/100.}


def text_sensor(text:str,pdict:PatternDictionary|None=None)->np.ndarray:
    data=_b(text); st=structural_features(data); ng=repeated_ngram_features(text)
    lens=codec_lengths(data,pdict.zdict if pdict else None)
    n=max(1,len(data))
    keys=['deflate','deflate_dict','brotli','lzma','delta1','delta2','xor1','xor4','xor16','rle']
    ratios=np.array([min(4.0,lens[k]/n)/4.0 for k in keys],np.float32)
    best=min(lens[k] for k in keys); second=sorted(lens[k] for k in keys)[1]
    summary=np.array([math.log1p(n)/8.,min(4,best/n)/4.,min(4,(second-best)/n)/4.],np.float32)
    if pdict:
        p=pdict.greedy_parse(text)
        pv=np.array([p[k] for k in ['ratio','coverage','n_patterns','unique_patterns','mean_len','max_len','weighted_savings']],np.float32)
    else: pv=np.zeros(7,np.float32)
    return np.concatenate([st,ng,ratios,summary,pv]).astype(np.float32)


def conditional_mdl(q:str,opt:str,pdict:PatternDictionary|None=None)->np.ndarray:
    qb=_b(q); ob=_b(opt); combo=_b(q+'\n<HYP>'+opt)
    zd=pdict.zdict if pdict else None
    Cq=codec_lengths(qb,zd); Co=codec_lengths(ob,zd); Cqo=codec_lengths(combo,zd)
    keys=['deflate','deflate_dict','brotli','lzma','delta1','xor1','rle']
    vals=[]
    for k in keys:
        inc=Cqo[k]-Cq[k]
        vals.append(np.clip(inc/max(1,len(ob)),-2,4)/4.)
        ncd=(Cqo[k]-min(Cq[k],Co[k]))/max(1,max(Cq[k],Co[k]))
        vals.append(np.clip(ncd,-1,4)/4.)
    # lexical/shared-atom compatibility -- compression-equivalent repeat signal.
    qt=set(TOKEN_RE.findall(q.casefold())); ot=set(TOKEN_RE.findall(opt.casefold()))
    overlap=len(qt&ot)/max(1,len(ot))
    lcs=longest_common_substring_ratio(q,opt)
    vals += [overlap,lcs]
    return np.asarray(vals,np.float32)


class CompressionPatternCore:
    def __init__(self,pdict:PatternDictionary): self.pdict=pdict
    @classmethod
    def fit(cls,questions:list[str],options:list[dict[str,str]]):
        texts=[]
        for q,op in zip(questions,options):
            texts.append(q); texts.extend(op.get(a,'') for a in 'ABCD')
            texts.append(q+' '+' '.join(op.get(a,'') for a in 'ABCD'))
        return cls(PatternDictionary.fit(texts))
    def question_features(self,q:str)->np.ndarray: return text_sensor(q,self.pdict)
    def option_features(self,q:str,opt:str)->np.ndarray:
        return np.concatenate([text_sensor(opt,self.pdict),conditional_mdl(q,opt,self.pdict)])
    def option_scores(self,q:str,options:dict[str,str])->np.ndarray:
        # Unsupervised MDL plausibility used only for optional exploration ordering.
        scores=[]
        for a in 'ABCD':
            v=conditional_mdl(q,options.get(a,''),self.pdict)
            # smaller incremental description length / NCD -> larger score
            scores.append(float(-np.mean(v[:14])))
        z=np.asarray(scores,float); z-=z.mean(); sd=z.std()+1e-8
        return (z/sd).astype(np.float32)
    def pair_features(self,q:str,options:dict[str,str],a:int,b:int)->np.ndarray:
        qa=self.question_features(q)
        oa=self.option_features(q,options.get('ABCD'[a],'')); ob=self.option_features(q,options.get('ABCD'[b],''))
        # both endpoints + directional difference + question-only structural state
        return np.concatenate([qa,oa,ob,oa-ob]).astype(np.float32)

