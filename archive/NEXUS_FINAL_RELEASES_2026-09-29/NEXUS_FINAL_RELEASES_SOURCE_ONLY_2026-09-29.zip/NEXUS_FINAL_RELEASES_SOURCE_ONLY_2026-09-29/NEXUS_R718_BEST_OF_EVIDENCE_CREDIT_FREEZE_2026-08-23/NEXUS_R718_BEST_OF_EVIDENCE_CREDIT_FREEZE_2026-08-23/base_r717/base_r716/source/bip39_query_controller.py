from __future__ import annotations
import math, numpy as np

LABELS='ABCD'
TEACHERS=['ministral3_3b','phi4mini_3_8b','granite33_2b','qwen3_1_7b','gemma3_1b']
GATE={'confidence_lo':0.50,'confidence_hi':0.66,'entropy_lo':0.70,'entropy_hi':0.82,'max_extra_calls':3}

def softmax1(z):
    x=np.asarray(z,float); x=x-x.max(); e=np.exp(np.clip(x,-50,50)); return e/(e.sum()+1e-12)

def state_delta(raw, previous_raw=None, stable_count=0):
    p=softmax1(raw); order=np.argsort(-p); gap=float(p[order[0]]-p[order[1]])
    ent=float(-(p*np.log(np.clip(p,1e-12,1))).sum()/math.log(4))
    changed=0.0 if previous_raw is None else float(np.argmax(previous_raw)!=np.argmax(raw))
    drift=0.0 if previous_raw is None else float(np.mean(np.abs(softmax1(previous_raw)-p)))
    return np.array([ent,1-gap,changed,drift,min(1.0,stable_count/2.0)],dtype=float)

def full_delta(control_delta, language_state=None, compression_state=None, formal_unknown=True):
    ls=language_state or {}; cs=compression_state or {}
    dl=ls.get('delta_language') or {}
    constraints=ls.get('constraints') or []
    return {
      'uncertainty':float(control_delta[0]),
      'evidence_ambiguity':float(control_delta[1]),
      'state_change':float(control_delta[2]),
      'probability_drift':float(control_delta[3]),
      'stability':float(control_delta[4]),
      'proof_unknown':1.0 if formal_unknown else 0.0,
      'language_uncertainty':float(dl.get('language_uncertainty',0.0)),
      'language_rule_disagreement':1.0 if dl.get('rule_learner_disagreement') else 0.0,
      'causal_constraint':1.0 if 'CAUSAL_DIRECTION_TEST' in constraints else 0.0,
      'compression_novelty':float(cs.get('novelty',0.0)),
      'compression_pattern_coverage':float((cs.get('pattern_parse') or {}).get('coverage',0.0)),
    }

def in_query_gain_window(confidence, entropy):
    return (GATE['confidence_lo'] <= confidence <= GATE['confidence_hi'] and
            GATE['entropy_lo'] <= entropy <= GATE['entropy_hi'])

def query_mode(stable_count):
    return 'FALSIFY' if stable_count==0 else 'VERIFY'

def make_query_pack(bip_module, question, cycle, current, called_mask, control_delta, mode):
    db=','.join(str(int(np.clip(round(x*15),0,15))) for x in control_delta)
    cs=''.join(str(int(x)) for x in called_mask)
    seed=f'{question}\n<QUERY={mode};C={cycle};H={LABELS[current]};CALLED={cs};DELTA={db}>'
    return bip_module.route_pack(seed,cycle,LABELS[current],mode,float(control_delta[0]-.5))

def choose_next_teacher(question, cycle, current, called_mask, competence, independence, pack, use_bip=True):
    avail=[i for i in range(len(TEACHERS)) if not called_mask[i]]
    if not avail: return None
    called=np.where(np.asarray(called_mask)>0)[0]
    scored=[]
    for j in avail:
        ind=float(np.mean([independence[j,k] for k in called])) if len(called) else float(independence[j].mean())
        base=float((max(competence[j],1e-4)**.78)*(max(ind,1e-4)**.22))
        if use_bip:
            idx=np.asarray(pack['indices'],float)/2047.0; route=np.asarray(pack['route'],float)/2047.0
            bonus=.6*(idx[(3*j+cycle)%24]-.5)+.4*(route[j%len(route)]-.5)
            base*=1+.09*bonus
        scored.append((j,base))
    return max(scored,key=lambda x:x[1])[0]
