from __future__ import annotations
from pathlib import Path
import sys, json, math, re, zlib
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'base_r714'
sys.path.insert(0, str(BASE / 'source'))
import runtime_r714 as r714
sys.path.insert(0, str(ROOT / 'source'))
import compression_pattern_core as cc

LABELS='ABCD'
POLICY={
    'answer_authority':'R7.14/R7.13 sovereign answer remains authoritative',
    'compression_role':[
        'ai_compress structural complexity sensors',
        'MDL critic',
        'unsupervised pattern dictionary',
        'NCD episodic pattern retrieval',
        'novelty / familiar-pattern signal',
        'compression-guided test request',
        'delta_compression on H->T states'
    ],
    'direct_answer_override':False,
    'reason':'All disclosed leave-one-benchmark-out answer-changing compression ablations failed to exceed R7.13 585/624 = 93.75%; nested NCD rescue was 584/624.',
    'blind30_status':'DOES NOT EXIST AT FREEZE'
}

_PATTERNS=json.loads((ROOT/'models'/'pattern_dictionary.json').read_text(encoding='utf-8'))
PDICT=cc.PatternDictionary(_PATTERNS['patterns'], _PATTERNS['scores'], bytes.fromhex(_PATTERNS['zdict_hex']))
CORE=cc.CompressionPatternCore(PDICT)
EPISODES=json.loads((ROOT/'models'/'episodic_memory.json').read_text(encoding='utf-8'))

_num_re=re.compile(r'[-+]?\d+(?:[.,]\d+)?')

def _c(data:bytes)->int:
    co=zlib.compressobj(level=9,wbits=-15)
    return len(co.compress(data)+co.flush())

def _ncd(a:str,b:str)->float:
    x=a.encode('utf-8'); y=b.encode('utf-8')
    cx=_c(x); cy=_c(y); cxy=min(_c(x+b'\n'+y),_c(y+b'\n'+x))
    return float((cxy-min(cx,cy))/max(1,max(cx,cy)))

def _route_name(lengths:dict[str,int])->str:
    return min((k for k in lengths if k!='raw'), key=lambda k:lengths[k])

def _episodic_neighbors(question:str,k:int=5):
    vals=[]
    for e in EPISODES:
        # Exclude exact self/text identity. Memory should surface another stored pattern,
        # not win by returning the same training record.
        if e['q'].strip().casefold() == question.strip().casefold():
            continue
        d=_ncd(question,e['q'])
        vals.append((d,e))
    vals.sort(key=lambda x:x[0])
    out=[]
    for d,e in vals[:k]:
        out.append({'distance':float(d),'block':e['block'],'id':e['id'],'q':e['q'],'domain':e['domain']})
    return out

def compression_state(item:dict):
    q=item['q']; options=item.get('options') or {}
    data=q.encode('utf-8')
    lengths=cc.codec_lengths(data,PDICT.zdict)
    best=_route_name(lengths); raw=max(1,len(data)); best_len=lengths[best]
    p=PDICT.greedy_parse(q)
    neigh=_episodic_neighbors(q,5)
    d0=neigh[0]['distance'] if neigh else 1.0
    novelty=float(np.clip(d0,0,1.5)/1.5)
    mdls=CORE.option_scores(q,options) if all(a in options for a in LABELS) else np.zeros(4,dtype=np.float32)
    suggestions=[]
    if d0 <= .38: suggestions.append('PATTERN_ANALOGY_TEST')
    if novelty >= .55: suggestions.append('NOVELTY_RECHECK')
    if best in ('delta1','delta2'): suggestions.append('SEQUENCE_STRUCTURE_TEST')
    if best.startswith('xor'): suggestions.append('RELATIONAL_PATTERN_TEST')
    if lengths.get('rle',raw) < .90*raw or p['coverage']>.35: suggestions.append('REPETITION_MACRO_TEST')
    if lengths.get('deflate_dict',raw) + 2 < lengths.get('deflate',raw): suggestions.append('DICTIONARY_PATTERN_TEST')
    return {
        'sensor_dim':int(len(cc.text_sensor(q,PDICT))),
        'entropy_bits_per_byte':float(cc.entropy_bytes(data)),
        'raw_bytes':int(raw),
        'codec_lengths':{k:int(v) for k,v in lengths.items()},
        'best_transform':best,
        'best_ratio':float(best_len/raw),
        'pattern_parse':{k:float(v) for k,v in p.items()},
        'novelty':novelty,
        'nearest_patterns':neigh,
        'option_mdl_z':{a:float(mdls[i]) for i,a in enumerate(LABELS)},
        'test_requests':suggestions,
        'authority':'CRITIC_ONLY'
    }

def decide(item:dict, teacher_rows=None):
    cs=compression_state(item)
    out=r714.decide(item,teacher_rows)
    out['r715_policy']=POLICY
    out['compression']=cs
    opts=item.get('options') or {}
    for step in out.get('cyber_chain') or []:
        hb=step.get('hypothesis_before'); ha=step.get('hypothesis_after')
        zb=cs['option_mdl_z'].get(hb,0.0); za=cs['option_mdl_z'].get(ha,0.0)
        step['compression_best_transform']=cs['best_transform']
        step['compression_novelty']=cs['novelty']
        step['compression_test_requests']=cs['test_requests']
        step['delta_compression']={
            'mdl_z_before':float(zb),
            'mdl_z_after':float(za),
            'mdl_z_change':float(za-zb),
            'pattern_coverage':float(cs['pattern_parse']['coverage']),
            'nearest_ncd':float(cs['nearest_patterns'][0]['distance'] if cs['nearest_patterns'] else 1.0)
        }
    return out
