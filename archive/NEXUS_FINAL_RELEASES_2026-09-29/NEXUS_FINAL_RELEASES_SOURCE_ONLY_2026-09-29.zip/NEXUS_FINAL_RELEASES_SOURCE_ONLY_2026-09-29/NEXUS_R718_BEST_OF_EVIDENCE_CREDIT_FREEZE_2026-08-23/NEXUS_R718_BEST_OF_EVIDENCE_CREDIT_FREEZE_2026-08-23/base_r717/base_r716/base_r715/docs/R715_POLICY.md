# R7.15 Compression Policy

1. Compression is a representation/critic/memory organ, not a truth oracle.
2. `CompressionState` may annotate every H→T step with complexity, pattern coverage, novelty, NCD neighbors and MDL deltas.
3. It may request an additional test class.
4. It MUST NOT override FORMAL_VERIFIED, R7.14/R7.13 answer, or teacher evidence by itself.
5. Answer override stays disabled because disclosed OOF ablations did not exceed 93.75%.
6. Blind-30 does not exist at freeze and must not be created until this freeze is externally timestamped.
7. Future answer authority requires a fresh post-freeze benchmark showing net improvement without proof-soundness regression.
