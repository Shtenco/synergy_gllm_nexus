# R7.16 policy

1. BIP39 is a deterministic exploration/query-routing mechanism, never evidence of truth.
2. Formal VERIFIED remains sovereign.
3. Initial unknown item calls the frozen top-2 independent teacher organs.
4. The sequential fusion model produces H0.
5. Extra query cycle is activated only inside the frozen controllability window: confidence 0.50..0.66 and normalized entropy 0.70..0.82.
6. The next teacher is selected by competence × evidence-independence with a bounded BIP39 scheduling perturbation.
7. The new teacher returns ordinary independent A/B/C/D evidence + option log-probabilities. BIP39 is not shown as factual evidence.
8. Evidence is fused again; cycle repeats up to three extra organs, with early stop on a fixed point.
9. MorphoLex and Compression Pattern Core provide advisory delta channels and test requests; they cannot directly change truth.
10. Blind30 does not exist at freeze.
