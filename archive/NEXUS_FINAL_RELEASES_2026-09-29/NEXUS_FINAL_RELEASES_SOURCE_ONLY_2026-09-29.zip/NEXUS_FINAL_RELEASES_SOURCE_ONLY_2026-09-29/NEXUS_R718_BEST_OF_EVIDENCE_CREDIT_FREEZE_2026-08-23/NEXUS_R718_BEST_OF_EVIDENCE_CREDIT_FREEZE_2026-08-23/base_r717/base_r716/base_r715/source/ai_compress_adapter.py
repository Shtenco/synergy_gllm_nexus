from __future__ import annotations
"""NEXUS R7.15 adapter for SHTENCO ai_compress structural primitives.

The canonical ai_compress repository remains the source of truth for full Tier-1,
GRAAL/UMC and Gabriel-Horn archive formats.  R7.15 uses the same structural
sensor/transform family as cognition features and performs exact portable
round-trip checks for the reversible subset used in-core.
"""
import zlib
from dataclasses import dataclass


def delta_encode(data:bytes,order:int=1)->bytes:
    out=data
    for _ in range(order):
        b=bytearray(len(out)); prev=0
        for i,v in enumerate(out): b[i]=(v-prev)&255; prev=v
        out=bytes(b)
    return out

def delta_decode(data:bytes,order:int=1)->bytes:
    # decode outermost delta first; repeated cumulative sums invert repeated deltas
    out=data
    for _ in range(order):
        b=bytearray(len(out)); prev=0
        for i,v in enumerate(out): prev=(prev+v)&255; b[i]=prev
        out=bytes(b)
    return out

def xor_lag_encode(data:bytes,lag:int)->bytes:
    if lag<=0 or lag>=len(data): return data
    out=bytearray(data)
    for i in range(len(out)-1,lag-1,-1): out[i]^=data[i-lag]
    return bytes(out)

def xor_lag_decode(data:bytes,lag:int)->bytes:
    if lag<=0 or lag>=len(data): return data
    out=bytearray(data)
    for i in range(lag,len(out)): out[i]^=out[i-lag]
    return bytes(out)

def rle_encode(data:bytes)->bytes:
    out=bytearray(); i=0
    while i<len(data):
        run=1
        while i+run<len(data) and data[i+run]==data[i] and run<65535: run+=1
        if run>=4:
            out.extend((1,(run>>8)&255,run&255,data[i]));i+=run;continue
        start=i;i+=run
        while i<len(data):
            nr=1
            while i+nr<len(data) and data[i+nr]==data[i] and nr<65535:nr+=1
            if nr>=4 or i-start>=65535:break
            i+=nr
        lit=data[start:i];L=len(lit);out.extend((0,(L>>8)&255,L&255));out.extend(lit)
    return bytes(out)
def rle_decode(data:bytes)->bytes:
    out=bytearray();i=0
    while i<len(data):
        if i+3>len(data):raise ValueError('truncated RLE')
        kind=data[i];L=(data[i+1]<<8)|data[i+2];i+=3
        if kind==1:
            if i>=len(data):raise ValueError('truncated RLE run')
            out.extend(bytes([data[i]])*L);i+=1
        elif kind==0:
            if i+L>len(data):raise ValueError('truncated RLE literal')
            out.extend(data[i:i+L]);i+=L
        else:raise ValueError('bad RLE kind')
    return bytes(out)

def deflate_roundtrip(transformed:bytes)->bytes:
    return zlib.decompress(zlib.compress(transformed,9))

def selftest()->dict:
    corpus=[
      b'', b'aaaaabbbbbcccccc', bytes(range(256)),
      (b'pattern-123-'*100), bytes((i*i+7*i)%256 for i in range(4096))
    ]
    tests=0
    for x in corpus:
        for o in (1,2):
            y=delta_encode(x,o); assert deflate_roundtrip(y)==y; assert delta_decode(y,o)==x; tests+=1
        for lag in (1,4,16):
            y=xor_lag_encode(x,lag); assert deflate_roundtrip(y)==y; assert xor_lag_decode(y,lag)==x; tests+=1
        y=rle_encode(x); assert deflate_roundtrip(y)==y; assert rle_decode(y)==x; tests+=1
    return {'portable_reversible_roundtrips':tests,'passed':tests,'backend':'PORTABLE_AI_COMPRESS_PATTERN_CORE'}
