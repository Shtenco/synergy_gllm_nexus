from __future__ import annotations
import re,zlib,difflib,math
import numpy as np
NUM_RE=re.compile(r'^\s*[-+]?\d+(?:[.,]\d+)?%?\s*$')

def norm(s): return ' '.join(re.findall(r'\w+|[^\w\s]',str(s).casefold(),re.UNICODE))
def template(s): return re.sub(r'\d+(?:[.,]\d+)?','<n>',norm(s))
def C(s):
    co=zlib.compressobj(9,wbits=-15);b=norm(s).encode('utf-8');return len(co.compress(b)+co.flush())
def ncd(a,b):
    a=norm(a);b=norm(b);ca=C(a);cb=C(b);cab=C(a+'\n'+b)
    return (cab-min(ca,cb))/max(1,max(ca,cb))
def stems(s):
    ts=re.findall(r'\w+',norm(s),re.UNICODE);return {t[:max(3,min(6,len(t)))] for t in ts if len(t)>=3}
def ans_sim(a,b):
    a=norm(a);b=norm(b)
    if not a or not b:return 0.
    if a==b:return 1.
    if NUM_RE.match(a) or NUM_RE.match(b):return 0.
    seq=difflib.SequenceMatcher(None,a,b).ratio(); sa,sb=stems(a),stems(b);jac=len(sa&sb)/max(1,len(sa|sb))
    sub=0.95 if (len(a)>=4 and a in b) or (len(b)>=4 and b in a) else 0.
    comp=max(0.,1.-min(1.5,ncd(a,b))/1.5)
    return max(sub,.40*seq+.35*jac+.25*comp)

def propose(train,test,k=5,temp=.10):
    tq=[norm(x) for x in train.q]; cq=np.array([C(x) for x in tq]); tt=[template(x) for x in tq]
    out=[]
    for _,row in test.iterrows():
        x=norm(row.q);cx=C(x);tmp=template(x); ds=[]
        for j,y in enumerate(tq):
            d=(C(x+'\n'+y)-min(cx,cq[j]))/max(1,max(cx,cq[j]))
            if tt[j]==tmp:d-=.18
            ds.append(d)
        idx=np.argsort(ds)[:min(k,len(ds))]; dv=np.array([ds[j] for j in idx]);w=np.exp(-(dv-dv.min())/temp);w/=w.sum()+1e-12
        scores=np.zeros(4); ng=[]
        for ww,j in zip(w,idx):
            gt=train.iloc[j].options[train.iloc[j].gold]
            for oi,a in enumerate('ABCD'):scores[oi]+=ww*ans_sim(row.options[a],gt)
            ng.append({'id':train.iloc[j].id,'q':train.iloc[j].q,'gold_text':gt,'distance':float(ds[j]),'weight':float(ww)})
        order=np.argsort(-scores); best,second=int(order[0]),int(order[1])
        out.append({'pred':'ABCD'[best],'score':float(scores[best]),'margin':float(scores[best]-scores[second]),'distance':float(dv.min()),'template_hits':sum(tt[j]==tmp for j in idx),'neighbors':ng})
    return out
