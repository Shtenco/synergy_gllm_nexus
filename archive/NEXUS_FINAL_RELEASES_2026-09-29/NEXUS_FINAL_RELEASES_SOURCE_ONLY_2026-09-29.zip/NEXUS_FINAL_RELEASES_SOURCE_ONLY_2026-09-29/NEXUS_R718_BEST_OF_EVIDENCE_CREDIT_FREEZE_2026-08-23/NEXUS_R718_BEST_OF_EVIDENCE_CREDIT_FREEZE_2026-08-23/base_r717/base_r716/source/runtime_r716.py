from __future__ import annotations
from pathlib import Path
import sys, math, numpy as np
ROOT=Path(__file__).resolve().parents[1]
R715=ROOT/'base_r715'; R714=R715/'base_r714'; R713=R714/'base_r713'
sys.path.insert(0,str(R715/'source')); import runtime_r715 as r715
sys.path.insert(0,str(R714/'source')); import runtime_r714 as r714
sys.path.insert(0,str(R713/'source')); import graphboost_training as g, bip39_cyber_layer as bip
sys.path.insert(0,str(ROOT/'source'))
import sequential_fusion_core as sf
import bip39_query_controller as qc
L=g.LABELS; T=g.TEACHERS
POLICY={
 'name':'NEXUS R7.16 BIP39 Adaptive Query CyberCore',
 'authority':'Formal VERIFIED remains sovereign. BIP39 never votes for truth.',
 'bip39_role':'deterministic adaptive query scheduling / exploration',
 'evidence_role':'selected independent teacher answer/logprobs update the evidence graph',
 'query_gain_gate':qc.GATE,
 'max_extra_calls':3,
 'direct_bip39_answer_override':False,
 'blind30_status':'DOES NOT EXIST AT FREEZE'
}

def _metrics(raw):
    p=qc.softmax1(raw); order=np.argsort(-p); gap=float(p[order[0]]-p[order[1]]); ent=float(-(p*np.log(np.clip(p,1e-12,1))).sum()/math.log(4))
    return p,gap,ent

def _request(teacher,pack,mode,delta_full,current,called):
    return {
      'teacher':teacher,
      'query_type':mode,
      'current_hypothesis':L[current],
      'called_before':called,
      'bip39':{'sha256':pack['sha256'],'base58':pack['base58'],'indices':pack['indices'],'rows_4x6':pack['rows'],'cols_6x4':pack['cols'],'route_id':pack['route_id'],'route_kind':pack['route_kind']},
      'delta':delta_full,
      'evidence_request':'Independently answer the original A/B/C/D question and return option log-probabilities. Do not treat BIP39 as evidence.',
      'truth_source':'teacher evidence + NEXUS verifier, never BIP39'
    }

def decide(item,teacher_rows=None):
    teacher_rows=teacher_rows or {}; q=item['q']; formal=g.formal_pass(item)
    ls=r714.language_state(q); cs=r715.compression_state(item)
    initial=bip.route_pack(q,0,None,'INIT',0.0)
    symbolic={'sha256':initial['sha256'],'base58':initial['base58'],'indices':initial['indices'],'rows_4x6':initial['rows'],'cols_6x4':initial['cols']}
    if formal['status']=='VERIFIED' and formal.get('answer') in g.L2I:
        return {'answer':formal['answer'],'stage':'FORMAL_VERIFIED','calls':0,'used':[],'formal':formal,'morpholex':ls,'compression':cs,'symbolic_layer':symbolic,'r716_policy':POLICY,'query_chain':[]}
    mask,top2,comp,route=sf.initial_route(q); top2names=[T[i] for i in top2]
    missing=[t for t in top2names if t not in teacher_rows]
    if missing:
        return {'answer':None,'stage':'NEED_INITIAL_TEACHERS','required':top2names,'missing':missing,'calls_needed':len(missing),'formal':formal,'morpholex':ls,'compression':cs,'symbolic_layer':symbolic,'r716_policy':POLICY,'query_chain':[]}
    current=0; previous_raw=None; stable=0; trace=[]; calls=2; used=top2names.copy()
    for cycle in range(qc.GATE['max_extra_calls']+1):
        # Benchmark-compatible control delta. Full multi-organ delta is logged alongside it.
        if cycle==0:
            df=sf.record(item,teacher_rows,formal); X,B,aux=sf.called_features(df,mask); current=int(np.argmax(B[0])); control=np.array([.75,.75,0,0,0],float); mode='INIT'
        else:
            control=qc.state_delta(previous_raw,None,stable); mode='VERIFY' if stable else 'DISCRIMINATE'
        pack=qc.make_query_pack(bip,q,cycle,current,mask,control,mode)
        raw,B,aux=sf.evaluate(item,teacher_rows,formal,mask,cycle,current,control,mode,pack)
        old=current; sug=int(np.argmax(raw)); p,gap,ent=_metrics(raw)
        if cycle==0: current=sug
        elif sug==old: stable+=1
        else:
            adv=float(raw[sug]-raw[old])
            if adv>=.18: current=sug; stable=0
            else: stable+=1
        full=qc.full_delta(control,ls,cs,True)
        trace.append({'cycle':cycle,'query_type':mode,'called':[T[j] for j in np.where(mask>0)[0]],'hypothesis_before':L[old],'suggested':L[sug],'hypothesis_after':L[current],'confidence':float(p[current]),'entropy':ent,'margin':gap,'control_delta':control.tolist(),'delta_full':full,'bip39_sha256':pack['sha256'],'route_id':pack['route_id'],'route_kind':pack['route_kind']})
        previous_raw=raw.copy()
        # First state: activate costly query loop only in the preregistered controllability window.
        if cycle==0 and not qc.in_query_gain_window(float(p[current]),ent):
            return {'answer':L[current],'stage':'SEQUENTIAL_TOP2_FIXED_POINT','calls':calls,'used':used,'formal':formal,'morpholex':ls,'compression':cs,'symbolic_layer':symbolic,'r716_policy':POLICY,'query_chain':trace}
        if cycle>0 and ((p[current]>=.72 and gap>=.22 and ent<=.62) or stable>=2 or cycle==qc.GATE['max_extra_calls'] or np.sum(mask)>=5):
            return {'answer':L[current],'stage':'BIP39_QUERY_FIXED_POINT','calls':calls,'used':used,'formal':formal,'morpholex':ls,'compression':cs,'symbolic_layer':symbolic,'r716_policy':POLICY,'query_chain':trace}
        # Need a fresh independent organ. BIP39 chooses where to query, never what answer to accept.
        control2=qc.state_delta(previous_raw,None,stable); qmode=qc.query_mode(stable); qpack=qc.make_query_pack(bip,q,cycle+1,current,mask,control2,qmode)
        j=qc.choose_next_teacher(q,cycle+1,current,mask,aux['comp'],sf.INDEP,qpack,True)
        if j is None:
            return {'answer':L[current],'stage':'NO_MORE_ORGANS','calls':calls,'used':used,'formal':formal,'morpholex':ls,'compression':cs,'symbolic_layer':symbolic,'r716_policy':POLICY,'query_chain':trace}
        t=T[j]; delta_full=qc.full_delta(control2,ls,cs,True); req=_request(t,qpack,qmode,delta_full,current,used)
        if t not in teacher_rows:
            return {'answer':None,'stage':'NEED_BIP39_QUERY_TEACHER','next_teacher':t,'query_packet':req,'calls_so_far':calls,'used':used,'formal':formal,'morpholex':ls,'compression':cs,'symbolic_layer':symbolic,'r716_policy':POLICY,'query_chain':trace}
        mask[j]=1; calls+=1; used.append(t)
    return {'answer':L[current],'stage':'MAX_QUERY_CYCLES','calls':calls,'used':used,'formal':formal,'morpholex':ls,'compression':cs,'symbolic_layer':symbolic,'r716_policy':POLICY,'query_chain':trace}
