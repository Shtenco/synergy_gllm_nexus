from __future__ import annotations
from pathlib import Path
import sys, joblib, numpy as np, pandas as pd
from catboost import CatBoostClassifier, Pool
ROOT=Path(__file__).resolve().parents[1]
R713=ROOT/'base_r715'/'base_r714'/'base_r713'
sys.path.insert(0,str(R713/'source'))
import graphboost_training as g
import bip39_cyber_layer as bip
from bip39_query_controller import softmax1
T=g.TEACHERS; L=g.LABELS; L2I=g.L2I
ROUTER=joblib.load(ROOT/'models'/'domain_router.joblib')
REL=np.load(ROOT/'models'/'reliability.npy'); INDEP=np.load(ROOT/'models'/'independence.npy'); CENTRAL=np.load(ROOT/'models'/'centrality.npy'); A=np.load(ROOT/'models'/'adjacency.npy')
MODEL=CatBoostClassifier(); MODEL.load_model(str(ROOT/'models'/'sequential_query_fusion.cbm'))

def record(item,teacher_rows,formal):
    rec={'block':'LIVE','id':item.get('id','LIVE'),'q':item['q'],'domain_true':item.get('domain','mixed_reasoning'),'gold':'A',
         'formal_status':formal['status'],'formal_answer':formal.get('answer'),
         'formal_kind':((formal.get('ir') or {}).get('kind') if formal.get('ir') else 'NONE'),
         'formal_rule':((formal.get('ir') or {}).get('compiler_rule') if formal.get('ir') else 'NONE')}
    for t in T:
        rr=teacher_rows.get(t) or {}; rec[t+'_pred']=rr.get('pred')
        p=g.probs_from_lp(rr.get('option_logprobs') or {}) if rr else np.ones(4)/4
        for j,a in enumerate(L): rec[f'{t}_p{a}']=float(p[j])
    return pd.DataFrame([rec])

def initial_route(question):
    dp=g.domain_post(ROUTER,[question]); comp=dp@REL
    route=(np.clip(comp,1e-4,1)**.80)*(np.clip(CENTRAL[None,:],1e-4,1)**.20)
    idx=np.argsort(-route[0])[:2]; mask=np.zeros(len(T),float); mask[idx]=1
    return mask,idx,comp[0],route[0]

def called_features(df,mask):
    n=len(df); dp=g.domain_post(ROUTER,df.q); H=g.HV.transform(df.q).toarray().astype(np.float32)
    tprob=np.zeros((n,len(T),4)); conf=np.zeros((n,len(T)))
    for ti,t in enumerate(T):
        for j,a in enumerate(L): tprob[:,ti,j]=df[f'{t}_p{a}'].values
        conf[:,ti]=tprob[:,ti,:].max(1)
    comp=dp@REL; route=(np.clip(comp,1e-4,1)**.80)*(np.clip(CENTRAL[None,:],1e-4,1)**.20)
    m=np.asarray(mask,float).reshape(1,-1); called=tprob*m[:,:,None]; w=route*m*(np.clip(conf,1e-4,1)**.10)
    support=np.einsum('nt,ntc->nc',w,called)/(w.sum(1,keepdims=True)+1e-12); support[w.sum(1)<=1e-12]=.25
    B=np.log(np.clip(support,1e-8,1)); diff=[]
    for c in range(4):
        s=called[:,:,c]; p1=s@A.T; p2=p1@A.T; diff += [s,p1,p2]
    G=np.concatenate(diff,axis=1); preds=np.argmax(tprob,2); agree=[]
    for i in range(len(T)):
        for j in range(i+1,len(T)):
            both=(m[:,i]*m[:,j])[:,None]; agree.append(((preds[:,i]==preds[:,j]).astype(float)[:,None])*both)
    agree=np.concatenate(agree,axis=1); fv=(df.formal_status.values=='VERIFIED').astype(float)[:,None]; fa=np.zeros((n,4))
    for i,a in enumerate(df.formal_answer.values):
        if a in L2I: fa[i,L2I[a]]=1
    qlen=np.array([len(x) for x in df.q],float)[:,None]/200; numcnt=np.array([sum(ch.isdigit() for ch in x) for x in df.q],float)[:,None]/20
    X=np.concatenate([H,dp,called.reshape(n,-1),m,comp,conf*m,support,G,agree,fv,fa,qlen,numcnt],axis=1).astype(np.float32)
    return X,B,{'comp':comp[0],'route':route[0]}

def query_feature(pack,cycle,current,called_mask,delta,mode):
    x,_=bip.probe_features(pack['seed_text'],min(cycle,3),L[current],mode,float(delta[0]-.5))
    modes=['INIT','VERIFY','FALSIFY','DISCRIMINATE','CONSISTENCY']; modev=np.array([1.0 if mode==m else 0.0 for m in modes],np.float32)
    return np.concatenate([x,delta.astype(np.float32),np.asarray(called_mask,np.float32),modev,np.array([cycle/3],np.float32)])

def evaluate(item,teacher_rows,formal,mask,cycle,current,delta,mode,pack):
    df=record(item,teacher_rows,formal); X,B,aux=called_features(df,mask); qf=query_feature(pack,cycle,current,mask,delta,mode)
    XF=np.concatenate([X,qf[None,:],np.array([[1.0,np.sum(mask)/5]],np.float32)],axis=1)
    raw=np.asarray(MODEL.predict(Pool(XF,baseline=B),prediction_type='RawFormulaVal'))[0]
    return raw,B[0],aux
