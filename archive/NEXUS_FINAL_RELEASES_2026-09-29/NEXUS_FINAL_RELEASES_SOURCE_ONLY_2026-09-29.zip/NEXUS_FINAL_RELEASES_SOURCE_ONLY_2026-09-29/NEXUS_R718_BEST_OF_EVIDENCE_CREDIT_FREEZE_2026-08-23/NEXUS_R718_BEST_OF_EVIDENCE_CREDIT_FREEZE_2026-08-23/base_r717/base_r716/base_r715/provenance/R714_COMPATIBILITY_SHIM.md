# R7.14 packaging compatibility shim

The frozen R7.14 source `source/morpholex_layer.py` resolves its model as
`ROOT/models_morpholex_distiller.joblib`, while the R7.14 archive stores the exact
model bytes at `models/morpholex_distiller.joblib`.

R7.15 does not alter the frozen R7.14 source or model. It adds a byte-identical
compatibility copy at `base_r714/models_morpholex_distiller.joblib` so the parent
runtime can be imported from the self-contained R7.15 package.
