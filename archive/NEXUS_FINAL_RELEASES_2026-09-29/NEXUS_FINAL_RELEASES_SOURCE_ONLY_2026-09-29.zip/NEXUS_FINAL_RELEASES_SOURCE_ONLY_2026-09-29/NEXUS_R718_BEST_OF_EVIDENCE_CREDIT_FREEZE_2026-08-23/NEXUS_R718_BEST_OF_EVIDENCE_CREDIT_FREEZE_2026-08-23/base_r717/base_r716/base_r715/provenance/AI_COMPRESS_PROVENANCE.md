# ai_compress provenance

Canonical repository: `Shtenco/ai_compress` (`main`).
Canonical main commit observed before freeze: `31e087530a61c05e6ff23e554f13f5b7bc1d35d7`.

R7.15 integrates the architecture-level mechanisms of the active repository, not a renamed third-party codec:
- Tier-1 v2 structural sensors: entropy, printable, zero, adjacent repeats, local smoothness, block similarity, repeated 16-byte atoms;
- reversible delta / lag-XOR / RLE pattern transforms in the portable in-core adapter;
- UMC/OMNIA MDL-style expert selection as an MDL critic;
- GRAAL-style dedup/pattern references as episodic pattern memory;
- Gabriel-Horn multiscale/shell principle as progressive complexity diagnostics.

Canonical blob SHAs observed before R7.15 freeze:
- README.md: `a0f96cb4e53b84d15963b165b514ce0e65986745`
- compression_lab/gabriel_horn_engine.py: `ac621bdbc28993eb4273bec55f143f4259f3632c`
- compression_lab/shtenco_tier1_engines.py: `0bb4d653ac7d5f6bd7d755a78f0debf642b311b2`
- compression_lab/shtenco_tier1_v2.py: `ab155d5bcd1aa8de3d109528957e4cefeefa4ceb`

Full SGH1/Tier-1 container formats remain canonical in `ai_compress`; this NEXUS package vendors a cognition adapter and portable exact reversible subset rather than silently forking archive formats.
