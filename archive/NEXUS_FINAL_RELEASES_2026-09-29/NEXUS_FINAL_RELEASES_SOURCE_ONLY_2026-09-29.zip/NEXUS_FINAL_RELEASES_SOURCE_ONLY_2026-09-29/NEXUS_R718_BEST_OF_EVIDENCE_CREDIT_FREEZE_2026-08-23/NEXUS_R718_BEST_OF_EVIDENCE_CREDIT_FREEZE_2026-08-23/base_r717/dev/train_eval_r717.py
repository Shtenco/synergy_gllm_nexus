from __future__ import annotations
from pathlib import Path
import os,sys,json,math,random,time,copy
import numpy as np,pandas as pd, torch
import torch.nn.functional as F
from torch import optim

BASE=Path('/mnt/data'); DEV=BASE/'r717_dev'
R716=Path('/mnt/data/r717_work/NEXUS_R716_BIP39_QUERY_CYBERCORE_FREEZE_2026-08-23')
R713=R716/'base_r715'/'base_r714'/'base_r713'; R714=R716/'base_r715'/'base_r714'; R715=R716/'base_r715'
sys.path[:0]=[str(R713/'source'),str(R714/'source'),str(R715/'source'),str(DEV)]
import graphboost_training as g
import morpholex_layer as ml
import compression_pattern_core as cp
from r717_bdh_core import BDHRecurrentEvidence,BDHCoreConfig,softmax_np,entropy4,LoRAAnswerAdapter
from r717_quantum_branches import choose_teacher

SEED=717
random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED); torch.set_num_threads(4)
T=g.TEACHERS; L=g.LABELS; L2I=g.L2I
DF=pd.read_csv(DEV/'R717_DISCLOSED_624.csv')
BLOCKS=['B22','B24','B25','B26','B27','B28']
# Fixed linguistic features: the R7.14 engine itself is frozen and independent of B22-B28 gold.
MORPH=np.stack([ml.feature_vector(q) for q in DF.q])

# teacher probability tensor
TP=np.zeros((len(DF),len(T),4),np.float32)
for ti,t in enumerate(T):
    for a_i,a in enumerate(L): TP[:,ti,a_i]=DF[f'{t}_p{a}'].values
GOLD=np.array([L2I[a] for a in DF.gold])
FORMAL=(DF.formal_status.values=='VERIFIED')
FORMAL_ANS=np.array([L2I.get(str(a),-1) for a in DF.formal_answer.values])
OPTIONS=[json.loads(s) for s in DF.options_json]


def make_context(train_idx,eval_idx):
    tr=DF.iloc[train_idx]; ev=DF.iloc[eval_idx]
    router=g.fit_router(tr); rel,indep,central,A=g.hist_stats(tr)
    # Unsupervised compression dictionary fitted on outer-train only.
    pdict=cp.PatternDictionary.fit(
        [DF.q.iloc[i]+' '+' '.join(OPTIONS[i].get(a,'') for a in L) for i in train_idx],max_patterns=256)
    def ctx_for(indices):
        sub=DF.iloc[indices]
        H=g.HV.transform(sub.q).toarray().astype(np.float32)
        dp=g.domain_post(router,sub.q).astype(np.float32)
        cf=np.stack([cp.text_sensor(DF.q.iloc[i],pdict) for i in indices])
        formal=np.zeros((len(indices),5),np.float32)
        for r,i in enumerate(indices):
            formal[r,0]=1.0 if FORMAL[i] else 0.0
            if FORMAL_ANS[i]>=0: formal[r,1+FORMAL_ANS[i]]=1.0
        return np.concatenate([H,dp,MORPH[indices],cf,formal],axis=1),dp
    xtr,dptr=ctx_for(train_idx); xev,dpev=ctx_for(eval_idx)
    comp_tr=dptr@rel; comp_ev=dpev@rel
    return xtr,xev,comp_tr,comp_ev,rel,indep,central,router,pdict


def build_evidence(indices,teacher_ids,comp,central):
    # indices local into provided tensor rows (0..B-1), teacher_ids BxS
    B,S=teacher_ids.shape; out=np.zeros((B,S,11),np.float32)
    for b in range(B):
        for s in range(S):
            j=int(teacher_ids[b,s]); out[b,s,:4]=TP[indices[b],j]
            out[b,s,4+j]=1.; out[b,s,9]=comp[b,j]; out[b,s,10]=central[j]
    return out


def random_sequences(indices,comp,rng,min_len=2,max_len=5,order_aug=True):
    B=len(indices); ids=np.zeros((B,max_len),np.int64); mask=np.zeros((B,max_len),bool)
    for b in range(B):
        arr=list(range(5));
        if order_aug: rng.shuffle(arr)
        ln=int(rng.integers(min_len,max_len+1)); ids[b,:ln]=arr[:ln]; mask[b,:ln]=1
        if ln<max_len: ids[b,ln:]=arr[0]
    ev=build_evidence(indices,ids,comp,GLOBAL_CENTRAL)
    return ids,ev,mask

GLOBAL_CENTRAL=None

def train_model(train_idx,xtr,comp_tr,central,cfg=None,epochs=20,lr=8e-4,order_aug=True,seed=717):
    global GLOBAL_CENTRAL; GLOBAL_CENTRAL=central
    device='cpu'; model=BDHRecurrentEvidence(xtr.shape[1],11,cfg or BDHCoreConfig()).to(device)
    opt=optim.AdamW(model.parameters(),lr=lr,weight_decay=1e-4)
    rng=np.random.default_rng(seed); BATCH=64
    local_indices=np.arange(len(train_idx))
    # map local -> global ids for TP/GOLD
    for ep in range(epochs):
        rng.shuffle(local_indices); model.train()
        for st in range(0,len(local_indices),BATCH):
            loc=local_indices[st:st+BATCH]; glob=np.asarray(train_idx)[loc]
            _,ev,mask=random_sequences(glob,comp_tr[loc],rng,2,5,order_aug)
            ctx=torch.tensor(xtr[loc],dtype=torch.float32)
            evt=torch.tensor(ev,dtype=torch.float32); mt=torch.tensor(mask,dtype=torch.bool)
            y=torch.tensor(GOLD[glob],dtype=torch.long)
            last,outs=model.forward_sequence(ctx,evt,mt)
            loss=F.cross_entropy(last,y)
            # Small anytime loss: teaches useful intermediate recurrent states.
            for k,o in enumerate(outs[1:],start=1): loss=loss+.035*F.cross_entropy(o,y)
            opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1.0); opt.step()
    return model


def infer_item(model,global_i,ctxrow,comp_row,central,indep,quantum=False,max_extra=0,conf_gate=.69,ent_gate=.58,seed='R717',adapter=None):
    if FORMAL[global_i] and FORMAL_ANS[global_i]>=0:
        return FORMAL_ANS[global_i],0,[],{'formal':True}
    route=(np.clip(comp_row,1e-4,1)**.80)*(np.clip(central,1e-4,1)**.20)
    order=list(np.argsort(-route)); called=order[:2]
    h=None;sf=None;ss=None
    model.eval()
    with torch.no_grad():
        ctx=torch.tensor(ctxrow[None,:],dtype=torch.float32)
        h,sf,ss=model.init_state(ctx); logits=model.head(h)
        trace=[]
        for step,j in enumerate(called):
            ev=np.zeros((1,11),np.float32); ev[0,:4]=TP[global_i,j]; ev[0,4+j]=1; ev[0,9]=comp_row[j]; ev[0,10]=central[j]
            h,sf,ss,logits=model.step(h,sf,ss,torch.tensor(ev))
            trace.append((j,softmax_np(logits.numpy()[0]).tolist()))
        if adapter is not None: logits=logits+adapter(h)
        p=softmax_np(logits.numpy()[0]);
        extras=0
        while extras<max_extra:
            conf=float(p.max()); ent=entropy4(p)
            if not (conf<conf_gate and ent>ent_gate): break
            avail=[j for j in range(5) if j not in called]
            j=choose_teacher(p,avail,comp_row,indep,called,f'{seed}|{DF.id.iloc[global_i]}|{extras}',quantum=quantum)
            if j is None: break
            called.append(j); extras+=1
            ev=np.zeros((1,11),np.float32); ev[0,:4]=TP[global_i,j]; ev[0,4+j]=1; ev[0,9]=comp_row[j]; ev[0,10]=central[j]
            h,sf,ss,logits=model.step(h,sf,ss,torch.tensor(ev))
            if adapter is not None: logits=logits+adapter(h)
            p=softmax_np(logits.numpy()[0]); trace.append((j,p.tolist()))
        return int(np.argmax(p)),len(called),called,{'p':p.tolist(),'trace':trace,'formal':False}


def eval_model(model,eval_idx,xev,comp_ev,central,indep,**kw):
    preds=[];calls=[];details=[]
    for r,gi in enumerate(eval_idx):
        pr,c,used,d=infer_item(model,gi,xev[r],comp_ev[r],central,indep,**kw)
        preds.append(pr);calls.append(c);details.append(d)
    pred=np.array(preds); gold=GOLD[eval_idx]
    return {'acc':float((pred==gold).mean()),'correct':int((pred==gold).sum()),'pred':pred,'calls':np.array(calls),'details':details}


def run_base_folds(out_path):
    results=[]
    for fi,hold in enumerate(BLOCKS):
        tr_idx=np.where(DF.block.values!=hold)[0]; te_idx=np.where(DF.block.values==hold)[0]
        print('FOLD',hold,'train',len(tr_idx),'test',len(te_idx),flush=True)
        xtr,xte,ctr,cte,rel,indep,central,router,pdict=make_context(tr_idx,te_idx)
        cfg=BDHCoreConfig(latent_rounds=2)
        model=train_model(tr_idx,xtr,ctr,central,cfg,epochs=16,lr=8e-4,seed=SEED+fi)
        top2=eval_model(model,te_idx,xte,cte,central,indep,max_extra=0)
        classical=eval_model(model,te_idx,xte,cte,central,indep,max_extra=2,quantum=False)
        quantum=eval_model(model,te_idx,xte,cte,central,indep,max_extra=2,quantum=True)
        row={'holdout':hold,'n':len(te_idx),'top2':top2['acc'],'classical_extra':classical['acc'],'quantum_extra':quantum['acc'],
             'top2_correct':top2['correct'],'classical_correct':classical['correct'],'quantum_correct':quantum['correct'],
             'top2_calls':float(top2['calls'].mean()),'classical_calls':float(classical['calls'].mean()),'quantum_calls':float(quantum['calls'].mean())}
        results.append(row); print(row,flush=True)
    n=sum(r['n'] for r in results)
    summary={'n':n,'folds':results}
    for k in ['top2','classical_extra','quantum_extra']:
        summary[k]=sum(r[k]*r['n'] for r in results)/n
        summary[k+'_correct']=sum(r[('top2_correct' if k=='top2' else 'classical_correct' if k=='classical_extra' else 'quantum_correct')] for r in results)
    Path(out_path).write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    print(json.dumps(summary,indent=2),flush=True)

if __name__=='__main__':
    run_base_folds('/mnt/data/r717_dev/R717_BDH_BASE_OOF.json')
