from __future__ import annotations
from pathlib import Path
import sys,json,random,copy
import numpy as np,torch
import torch.nn.functional as F
from torch import optim
sys.path.insert(0,'/mnt/data/r717_dev')
import train_eval_r717_meta as m
from r717_bdh_core import LoRAMetaAdapter
from seal_nexus import generate_self_edits,reward_score,edit_to_json

SEED=71717
np.random.seed(SEED);torch.manual_seed(SEED);random.seed(SEED);torch.set_num_threads(4)


def adapter_train(base,train_idx,xtr,comp_tr,central,edit,seed):
    for p in base.parameters(): p.requires_grad_(False)
    rank=int(edit.training['lora_rank']); ad=LoRAMetaAdapter(base.cfg.d_state,rank,edit.training['lora_alpha'])
    opt=optim.AdamW(ad.parameters(),lr=float(edit.training['learning_rate']),weight_decay=1e-4)
    rng=np.random.default_rng(seed); n=len(train_idx); BATCH=64
    tc_all=m.teacher_correct(train_idx); preds=np.argmax(m.TP[train_idx],2)
    hard=np.apply_along_axis(lambda x: len(set(x.tolist())),1,preds)>=3
    all_steps=edit.training['strategy']=='all_recurrent_steps'
    drop=float(edit.data_generation['teacher_evidence_dropout']); replay=float(edit.data_generation['hard_example_replay_ratio'])
    base.eval(); ad.train()
    for ep in range(int(edit.training['num_train_epochs'])):
        order=np.arange(n)
        if replay>0 and hard.any():
            extra=rng.choice(np.where(hard)[0],size=max(1,int(n*replay)),replace=True);order=np.concatenate([order,extra])
        rng.shuffle(order)
        for st in range(0,len(order),BATCH):
            loc=order[st:st+BATCH];glob=np.asarray(train_idx)[loc]
            ctx=torch.tensor(xtr[loc],dtype=torch.float32)
            with torch.no_grad(): h,sf,ss=base.init_state(ctx)
            seq=[]
            for b in range(len(loc)):
                arr=list(range(5));rng.shuffle(arr);ln=int(rng.integers(1,4));seq.append(arr[:ln])
            losses=[]
            for step in range(3):
                active=[b for b,s in enumerate(seq) if step<len(s)]
                if not active: continue
                ev=np.zeros((len(loc),11),np.float32);mask=np.zeros(len(loc),bool)
                for b in active:
                    j=seq[b][step];e=m.ev_vec(glob[b],j,comp_tr[loc[b]],central)
                    if drop and rng.random()<drop: e[:4]=.25
                    ev[b]=e;mask[b]=1
                with torch.no_grad():
                    hn,sfn,ssn,_,_,_=base.step(h,sf,ss,torch.tensor(ev))
                    mm=torch.tensor(mask).view(-1,1);mmm=mm.view(-1,1,1)
                    h=torch.where(mm,hn,h);sf=torch.where(mmm,sfn,sf);ss=torch.where(mmm,ssn,ss)
                    btc,bg,br=base.read_heads(h)
                at,ag,ar=ad(h.detach());tc=btc+at;gain=bg+ag;risk=br+ar
                ytc=torch.tensor(tc_all[loc],dtype=torch.float32)
                yg=[];yr=[]
                for b in range(len(loc)):
                    called=seq[b][:min(step+1,len(seq[b]))]
                    gg,rr=m.gain_targets(glob[b],called,comp_tr[loc[b]],central);yg.append(gg);yr.append(rr)
                yg=torch.tensor(np.stack(yg),dtype=torch.float32);yr=torch.tensor(yr,dtype=torch.float32)
                loss=F.binary_cross_entropy_with_logits(tc,ytc)+.70*F.smooth_l1_loss(torch.tanh(gain),yg)+.35*F.binary_cross_entropy_with_logits(risk,yr)
                if all_steps or step==2 or step==max(len(s) for s in seq)-1: losses.append(loss)
            if losses:
                loss=sum(losses)/len(losses);opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(ad.parameters(),1.0);opt.step()
    return ad


def eval_policy(base,adapter,idx,x,comp,central,indep,budget=3,mode='classical'):
    oracle=[];fusion=[];rescue=[];records=[]
    route=m.route_scores(comp,central);static=np.argsort(-route,axis=1)
    for r,gi in enumerate(idx):
        if m.FORMAL[gi] and m.FORMAL_ANS[gi]>=0:
            ok=int(m.FORMAL_ANS[gi]==m.GOLD[gi]);oracle.append(ok);fusion.append(ok);rescue.append(0);continue
        called,pred,post,tr=m.run_sequence(base,gi,x[r],comp[r],central,indep,mode=mode,max_calls=budget,adapter=adapter)
        tc=[int(np.argmax(m.TP[gi,j])==m.GOLD[gi]) for j in called]
        oracle.append(int(any(tc)));fusion.append(int(pred==m.GOLD[gi]));rescue.append(int(tc[0]==0 and any(tc[1:])))
        records.append({'id':m.DF.id.iloc[gi],'called':[m.T[j] for j in called],'fusion_correct':int(pred==m.GOLD[gi]),'oracle':int(any(tc))})
    first_wrong=0
    for r,gi in enumerate(idx):
        if m.FORMAL[gi]: continue
        j=int(static[r,0]); first_wrong+=int(np.argmax(m.TP[gi,j])!=m.GOLD[gi])
    return {'oracle':float(np.mean(oracle)),'fusion':float(np.mean(fusion)),'rescue':int(np.sum(rescue)),
            'rescue_rate':float(np.sum(rescue)/max(first_wrong,1)),'n':len(idx),'first_wrong':first_wrong,'records':records}

# SEARCH: B22-B26 train, B27 validation; B28 untouched for layer-local pseudo-holdout.
search_train=np.where(np.isin(m.DF.block.values,['B22','B24','B25','B26']))[0]
search_val=np.where(m.DF.block.values=='B27')[0]
xtr,xv,ctr,cv,rel,indep,central,router,pdict=m.d.make_context(search_train,search_val)
print('SEAL SEARCH base train',len(search_train),'val',len(search_val),flush=True)
base_search=m.train_critic(search_train,xtr,ctr,central,epochs=7,seed=SEED)
base_val=eval_policy(base_search,None,search_val,xv,cv,central,indep,3,'classical')
profile={'validation_block':'B27','base_oracle':base_val['oracle'],'base_fusion':base_val['fusion'],'rescue_rate':base_val['rescue_rate'],
         'teacher_disagreement_rate':float(np.mean(np.apply_along_axis(lambda x:len(set(x.tolist()))>=3,1,np.argmax(m.TP[search_train],2))))}
edits,proposal_meta=generate_self_edits(profile,'R717-SEAL-B27')
results=[]
for ci,e in enumerate(edits):
    print('candidate',ci,edit_to_json(e),flush=True)
    ad=adapter_train(base_search,search_train,xtr,ctr,central,e,SEED+100+ci)
    met=eval_policy(base_search,ad,search_val,xv,cv,central,indep,3,'classical')
    rew,forget=reward_score(met,base_val,e)
    row={'candidate':ci,'edit':edit_to_json(e),'metrics':{k:v for k,v in met.items() if k!='records'},'reward':rew,'forgetting':forget}
    results.append((rew,e,row));print(' ->',json.dumps(row,ensure_ascii=False),flush=True)
results.sort(key=lambda x:x[0],reverse=True);best_reward,best_edit,best_row=results[0]
print('SELECTED',json.dumps(best_row,ensure_ascii=False,indent=2),flush=True)

# FINAL DEV TRAIN B22-B27, evaluate once on disclosed B28.
final_train=np.where(m.DF.block.values!='B28')[0]; final_test=np.where(m.DF.block.values=='B28')[0]
xf,xt,cf,ct,rel2,indep2,central2,router2,pdict2=m.d.make_context(final_train,final_test)
print('FINAL layer-local train B22-B27',len(final_train),'pseudo-holdout B28',len(final_test),flush=True)
base_final=m.train_critic(final_train,xf,cf,central2,epochs=9,seed=SEED+999)
base_b28=eval_policy(base_final,None,final_test,xt,ct,central2,indep2,3,'classical')
ad_final=adapter_train(base_final,final_train,xf,cf,central2,best_edit,SEED+1999)
seal_b28=eval_policy(base_final,ad_final,final_test,xt,ct,central2,indep2,3,'classical')
seal_q_b28=eval_policy(base_final,ad_final,final_test,xt,ct,central2,indep2,3,'quantum')
# save selected adapter and base recurrent critic
Path('/mnt/data/r717_dev/models').mkdir(exist_ok=True)
torch.save(base_final.state_dict(),'/mnt/data/r717_dev/models/r717_recurrent_critic_preb28.pt')
torch.save(ad_final.state_dict(),'/mnt/data/r717_dev/models/r717_seal_adapter_preb28.pt')
out={'name':'R7.17 SEAL-NEXUS layer development','search_train_blocks':['B22','B24','B25','B26'],'search_validation':'B27',
     'pseudo_holdout':'B28 (disclosed historically; not confirmatory)','base_validation':{k:v for k,v in base_val.items() if k!='records'},
     'proposal_meta':proposal_meta,'candidates':[x[2] for x in results],'selected':best_row,
     'b28_before_seal':{k:v for k,v in base_b28.items() if k!='records'},'b28_after_seal_classical':{k:v for k,v in seal_b28.items() if k!='records'},
     'b28_after_seal_quantum':{k:v for k,v in seal_q_b28.items() if k!='records'},
     'scientific_boundary':'SEAL method is faithfully inspired by structured self-edit -> adaptation -> downstream reward, but adapted to NEXUS metacognitive LoRA. B28 is disclosed, not fresh blind.'}
Path('/mnt/data/r717_dev/R717_SEAL_DEVELOPMENT.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print('FINAL',json.dumps(out,ensure_ascii=False,indent=2),flush=True)
