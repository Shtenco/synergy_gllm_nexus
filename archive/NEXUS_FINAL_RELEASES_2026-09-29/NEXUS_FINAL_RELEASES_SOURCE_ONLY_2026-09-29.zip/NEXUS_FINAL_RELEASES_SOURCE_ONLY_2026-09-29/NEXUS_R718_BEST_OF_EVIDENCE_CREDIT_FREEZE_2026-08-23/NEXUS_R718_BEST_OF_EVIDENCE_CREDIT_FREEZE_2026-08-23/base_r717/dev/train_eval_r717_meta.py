from __future__ import annotations
from pathlib import Path
import json,sys,random,math
import numpy as np, pandas as pd, torch
import torch.nn.functional as F
from torch import optim
BASE=Path('/mnt/data'); DEV=BASE/'r717_dev'
sys.path.insert(0,str(DEV))
import train_eval_r717 as d
from r717_bdh_core import BDHRecurrentCritic,BDHCoreConfig
from r717_quantum_branches_v2 import branch_forecast

SEED=1717
random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED); torch.set_num_threads(4)
DF=d.DF; TP=d.TP; GOLD=d.GOLD; FORMAL=d.FORMAL; FORMAL_ANS=d.FORMAL_ANS; T=d.T; BLOCKS=d.BLOCKS

def route_scores(comp,central):
    return (np.clip(comp,1e-4,1)**.80)*(np.clip(central[None,:],1e-4,1)**.20)

def teacher_correct(global_idx):
    return (np.argmax(TP[global_idx],axis=2)==GOLD[global_idx,None]).astype(np.float32)

def fuse_pred(global_i,called,comp_row,central):
    if not called: return 0,np.ones(4)/4
    w=(np.clip(comp_row[called],1e-4,1)**.80)*(np.clip(central[called],1e-4,1)**.20)
    s=(TP[global_i,called]*w[:,None]).sum(0)/(w.sum()+1e-12)
    return int(np.argmax(s)),s/(s.sum()+1e-12)

def gain_targets(global_i,called,comp_row,central):
    cur,_=fuse_pred(global_i,called,comp_row,central); cur_ok=(cur==GOLD[global_i])
    g=np.zeros(5,np.float32)
    for j in range(5):
        if j in called: continue
        nxt,_=fuse_pred(global_i,called+[j],comp_row,central); nxt_ok=(nxt==GOLD[global_i])
        g[j]=float(nxt_ok)-float(cur_ok)
    return g,float(not cur_ok)

def ev_vec(global_i,j,comp_row,central):
    ev=np.zeros(11,np.float32); ev[:4]=TP[global_i,j]; ev[4+j]=1.; ev[9]=comp_row[j]; ev[10]=central[j]; return ev

def train_critic(train_idx,xtr,comp_tr,central,cfg=None,epochs=10,lr=8e-4,seed=SEED,order_aug=True,teacher_dropout=.08,hard_replay=.0):
    model=BDHRecurrentCritic(xtr.shape[1],11,cfg or BDHCoreConfig(d_state=48,n_neurons=48,rank=16,active_k=10,latent_rounds=2,dropout=.06))
    opt=optim.AdamW(model.parameters(),lr=lr,weight_decay=1e-4)
    rng=np.random.default_rng(seed); n=len(train_idx); BATCH=48
    tc_all=teacher_correct(train_idx)
    # hardness: disagreement among teacher predictions
    pred=np.argmax(TP[train_idx],2); hard=(np.apply_along_axis(lambda x: len(set(x.tolist())),1,pred)>=3)
    base_local=np.arange(n)
    for ep in range(epochs):
        if hard_replay>0:
            extra=rng.choice(np.where(hard)[0],size=max(1,int(n*hard_replay)),replace=True) if hard.any() else np.array([],int)
            order=np.concatenate([base_local,extra]); rng.shuffle(order)
        else:
            order=base_local.copy(); rng.shuffle(order)
        model.train()
        for st in range(0,len(order),BATCH):
            loc=order[st:st+BATCH]; glob=np.asarray(train_idx)[loc]
            ctx=torch.tensor(xtr[loc],dtype=torch.float32)
            h,sf,ss=model.init_state(ctx)
            total=0.; steps=0
            # independent random sequence per sample; 1..4 teachers
            seq=[]
            for b in range(len(loc)):
                arr=list(range(5));
                if order_aug: rng.shuffle(arr)
                ln=int(rng.integers(1,5)); seq.append(arr[:ln])
            for step in range(4):
                active=[b for b,s in enumerate(seq) if step<len(s)]
                if not active: continue
                # update whole batch with zero evidence but mask inactive states afterwards
                ev=np.zeros((len(loc),11),np.float32); mask=np.zeros(len(loc),bool)
                for b in active:
                    j=seq[b][step]; e=ev_vec(glob[b],j,comp_tr[loc[b]],central)
                    if teacher_dropout>0 and rng.random()<teacher_dropout:
                        e[:4]=.25
                    ev[b]=e; mask[b]=1
                old=(h,sf,ss)
                hn,sfn,ssn,tc,gain,risk=model.step(h,sf,ss,torch.tensor(ev))
                m=torch.tensor(mask).view(-1,1); mm=m.view(-1,1,1)
                h=torch.where(m,hn,h); sf=torch.where(mm,sfn,sf); ss=torch.where(mm,ssn,ss)
                tc,gain,risk=model.read_heads(h)
                ytc=torch.tensor(tc_all[loc],dtype=torch.float32)
                yg=[]; yr=[]
                for b in range(len(loc)):
                    called=seq[b][:min(step+1,len(seq[b]))]
                    gg,rr=gain_targets(glob[b],called,comp_tr[loc[b]],central); yg.append(gg);yr.append(rr)
                yg=torch.tensor(np.stack(yg),dtype=torch.float32); yr=torch.tensor(yr,dtype=torch.float32)
                loss_tc=F.binary_cross_entropy_with_logits(tc,ytc)
                loss_gain=F.smooth_l1_loss(torch.tanh(gain),yg)
                loss_r=F.binary_cross_entropy_with_logits(risk,yr)
                total=total+loss_tc+.70*loss_gain+.35*loss_r; steps+=1
            if steps:
                loss=total/steps; opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1.0); opt.step()
    return model

def posterior_from_called(global_i,called,comp_row,central):
    return fuse_pred(global_i,called,comp_row,central)[1]

def run_sequence(model,global_i,ctxrow,comp_row,central,indep,mode='classical',max_calls=3,adapter=None):
    route=route_scores(comp_row[None,:],central)[0]; first=int(np.argmax(route)); called=[first]
    model.eval(); trace=[]
    with torch.no_grad():
        ctx=torch.tensor(ctxrow[None,:],dtype=torch.float32); h,sf,ss=model.init_state(ctx)
        for step in range(max_calls):
            if step==0:
                j=first
            else:
                tc,gain,risk=model.read_heads(h)
                if adapter is not None:
                    at,ag,ar=adapter(h); tc=tc+at; gain=gain+ag; risk=risk+ar
                avail=[k for k in range(5) if k not in called]
                post=posterior_from_called(global_i,called,comp_row,central)
                quantum=(mode=='quantum')
                j,branches=branch_forecast(post,avail,tc.numpy()[0],gain.numpy()[0],indep,called,f'R717|{DF.id.iloc[global_i]}|{step}',quantum=quantum)
                if j is None: break
                called.append(int(j)); trace.append({'selection_step':step,'branches':branches,'selected':int(j),'quantum_inspired':quantum})
            ev=torch.tensor(ev_vec(global_i,j,comp_row,central)[None,:])
            h,sf,ss,tc,gain,risk=model.step(h,sf,ss,ev)
    pred,post=fuse_pred(global_i,called,comp_row,central)
    return called,pred,post,trace

def eval_fold(model,te_idx,xte,cte,central,indep):
    route=route_scores(cte,central); base_order=np.argsort(-route,axis=1)
    out={}
    item=[]
    for mode in ['static','classical','quantum']:
        for budget in [2,3]:
            oracle=[]; fusion=[]; rescue=[]; calls=[]
            for r,gi in enumerate(te_idx):
                if FORMAL[gi] and FORMAL_ANS[gi]>=0:
                    ok=int(FORMAL_ANS[gi]==GOLD[gi]); oracle.append(ok); fusion.append(ok); rescue.append(0); calls.append(0); continue
                if mode=='static': called=[int(x) for x in base_order[r,:budget]]; pred,_=fuse_pred(gi,called,cte[r],central); tr=[]
                else: called,pred,_,tr=run_sequence(model,gi,xte[r],cte[r],central,indep,mode,max_calls=budget)
                tc=[int(np.argmax(TP[gi,j])==GOLD[gi]) for j in called]
                oracle.append(int(any(tc))); fusion.append(int(pred==GOLD[gi])); rescue.append(int(tc[0]==0 and any(tc[1:])) if len(tc)>1 else 0); calls.append(len(called))
                if budget==3 and mode!='static': item.append({'id':DF.id.iloc[gi],'block':DF.block.iloc[gi],'mode':mode,'called':[T[j] for j in called],'fusion_correct':int(pred==GOLD[gi]),'oracle':int(any(tc)),'trace':tr})
            key=f'{mode}_k{budget}'; out[key]={'oracle':float(np.mean(oracle)),'fusion':float(np.mean(fusion)),'rescue':int(np.sum(rescue)),'mean_calls':float(np.mean(calls)),'correct_oracle':int(np.sum(oracle)),'correct_fusion':int(np.sum(fusion))}
    return out,item

def run(out_path='/mnt/data/r717_dev/R717_META_CRITIC_OOF.json'):
    folds=[];items=[]
    for fi,hold in enumerate(BLOCKS):
        tr_idx=np.where(DF.block.values!=hold)[0];te_idx=np.where(DF.block.values==hold)[0]
        print('META FOLD',hold,len(tr_idx),len(te_idx),flush=True)
        xtr,xte,ctr,cte,rel,indep,central,router,pdict=d.make_context(tr_idx,te_idx)
        model=train_critic(tr_idx,xtr,ctr,central,epochs=10,seed=SEED+fi)
        r,it=eval_fold(model,te_idx,xte,cte,central,indep); folds.append({'holdout':hold,'n':len(te_idx),'metrics':r});items+=it
        print(hold,json.dumps(r),flush=True)
    n=sum(f['n'] for f in folds); weighted={}
    for key in folds[0]['metrics']:
        weighted[key]={}
        for m in ['oracle','fusion']:
            weighted[key][m]=sum(f['metrics'][key][m]*f['n'] for f in folds)/n
        weighted[key]['rescue']=sum(f['metrics'][key]['rescue'] for f in folds)
        weighted[key]['mean_calls']=sum(f['metrics'][key]['mean_calls']*f['n'] for f in folds)/n
    out={'name':'R7.17 BDH-inspired recurrent metacognitive critic LOBO','n':n,'folds':folds,'weighted':weighted,
         'answer_policy':'R7.16 sovereign; these are teacher-query policy diagnostics, no answer override',
         'quantum_boundary':'classical quantum-inspired complex-amplitude branch scoring only; no quantum hardware/advantage claim'}
    Path(out_path).write_text(json.dumps(out,ensure_ascii=False,indent=2));
    Path('/mnt/data/r717_dev/R717_META_CRITIC_ITEM_TRACES.json').write_text(json.dumps(items,ensure_ascii=False))
    print('WEIGHTED',json.dumps(weighted,indent=2),flush=True)
if __name__=='__main__': run()
