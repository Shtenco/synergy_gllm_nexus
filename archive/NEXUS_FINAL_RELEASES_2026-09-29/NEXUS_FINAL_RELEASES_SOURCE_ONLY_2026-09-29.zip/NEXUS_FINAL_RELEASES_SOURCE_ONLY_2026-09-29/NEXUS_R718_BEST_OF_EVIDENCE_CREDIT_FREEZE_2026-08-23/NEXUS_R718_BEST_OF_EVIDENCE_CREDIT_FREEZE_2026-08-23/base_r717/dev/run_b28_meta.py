import sys,json,numpy as np
from pathlib import Path
sys.path.insert(0,'/mnt/data/r717_dev')
import train_eval_r717_meta as m
hold='B28'; fi=5
tr_idx=np.where(m.DF.block.values!=hold)[0]; te_idx=np.where(m.DF.block.values==hold)[0]
print('META FOLD',hold,len(tr_idx),len(te_idx),flush=True)
xtr,xte,ctr,cte,rel,indep,central,router,pdict=m.d.make_context(tr_idx,te_idx)
model=m.train_critic(tr_idx,xtr,ctr,central,epochs=10,seed=m.SEED+fi)
r,it=m.eval_fold(model,te_idx,xte,cte,central,indep)
out={'holdout':hold,'n':len(te_idx),'metrics':r}
Path('/mnt/data/r717_dev/R717_META_B28.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
Path('/mnt/data/r717_dev/R717_META_B28_TRACES.json').write_text(json.dumps(it,ensure_ascii=False))
print(json.dumps(out,indent=2),flush=True)
