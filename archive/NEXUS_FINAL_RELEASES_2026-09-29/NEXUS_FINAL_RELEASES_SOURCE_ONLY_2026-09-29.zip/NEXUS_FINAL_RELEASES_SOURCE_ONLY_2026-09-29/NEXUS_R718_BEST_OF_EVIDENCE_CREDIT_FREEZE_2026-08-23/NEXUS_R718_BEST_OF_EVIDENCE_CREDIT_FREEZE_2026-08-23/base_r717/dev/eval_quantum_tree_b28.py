import sys,torch,numpy as np,json
sys.path.insert(0,'/mnt/data/r717_dev')
import train_eval_r717_meta as m
from r717_bdh_core import BDHRecurrentCritic,BDHCoreConfig,LoRAMetaAdapter
from quantum_reasoning_tree import forecast_tree

train_idx=np.where(m.DF.block.values!='B28')[0];te_idx=np.where(m.DF.block.values=='B28')[0]
xtr,xte,ctr,cte,rel,indep,central,router,pdict=m.d.make_context(train_idx,te_idx)
cfg=BDHCoreConfig(d_state=48,n_neurons=48,rank=16,active_k=10,latent_rounds=2,dropout=.06)
model=BDHRecurrentCritic(xtr.shape[1],11,cfg);model.load_state_dict(torch.load('/mnt/data/r717_dev/models/r717_recurrent_critic_preb28.pt',weights_only=True));model.eval()
ad=LoRAMetaAdapter(48,4,4.0);ad.load_state_dict(torch.load('/mnt/data/r717_dev/models/r717_seal_adapter_preb28.pt',weights_only=True));ad.eval()

def run(gi,ctxrow,comp_row,budget=3,quantum=True):
 route=m.route_scores(comp_row[None,:],central)[0];first=int(np.argmax(route));called=[first]
 with torch.no_grad():
  h,sf,ss=model.init_state(torch.tensor(ctxrow[None,:],dtype=torch.float32))
  for step in range(budget):
   if step==0:j=first
   else:
    tc,gain,risk=model.read_heads(h);at,ag,ar=ad(h);tc=tc+at;gain=gain+ag
    avail=[k for k in range(5) if k not in called];post=m.posterior_from_called(gi,called,comp_row,central)
    j,rows,leaves=forecast_tree(post,avail,tc.numpy()[0],gain.numpy()[0],indep,called,f'R717TREE|{m.DF.id.iloc[gi]}|{step}',depth=2,quantum=quantum)
    if j is None:break
    called.append(j)
   ev=torch.tensor(m.ev_vec(gi,j,comp_row,central)[None,:]);h,sf,ss,_,_,_=model.step(h,sf,ss,ev)
 pred,_=m.fuse_pred(gi,called,comp_row,central);return called,pred
for quantum in [False,True]:
 oracle=fusion=rescue=0;first_wrong=0
 for r,gi in enumerate(te_idx):
  if m.FORMAL[gi] and m.FORMAL_ANS[gi]>=0:
   ok=int(m.FORMAL_ANS[gi]==m.GOLD[gi]);oracle+=ok;fusion+=ok;continue
  called,pred=run(gi,xte[r],cte[r],3,quantum);tc=[int(np.argmax(m.TP[gi,j])==m.GOLD[gi]) for j in called]
  oracle+=int(any(tc));fusion+=int(pred==m.GOLD[gi]);first_wrong+=int(tc[0]==0);rescue+=int(tc[0]==0 and any(tc[1:]))
 print(('quantum' if quantum else 'classical'),{'oracle':oracle/len(te_idx),'fusion':fusion/len(te_idx),'rescue':rescue,'first_wrong':first_wrong})
