from pathlib import Path
import sys, json, glob, numpy as np, pandas as pd
BASE=Path('/mnt/data')
R716=Path('/mnt/data/r717_work/NEXUS_R716_BIP39_QUERY_CYBERCORE_FREEZE_2026-08-23')
R713=R716/'base_r715'/'base_r714'/'base_r713'
sys.path.insert(0,str(R713/'source'))
import graphboost_training as g

TEACHERS=g.TEACHERS; LABELS=g.LABELS

def probs(lp):
    z=np.array([lp.get(a,-50.) if lp.get(a) is not None else -50. for a in LABELS],float)
    z-=z.max(); e=np.exp(z); return e/(e.sum()+1e-12)

# B22-B27 from canonical disclosed loader
old=g.load_data()
# add options from R715 episodic memory
mem=json.load(open(R716/'base_r715'/'models'/'episodic_memory.json',encoding='utf-8'))
memmap={(r['block'],r['id']):r for r in mem}
old['options_json']=[json.dumps(memmap[(b,i)]['options'],ensure_ascii=False,sort_keys=True) for b,i in zip(old.block,old.id)]
# B28
root=Path('/mnt/data/r717_data/NEXUS_R712_GRAPHBOOST_REAL_BLIND28_2026-08-23')
bench=json.load(open(root/'BENCHMARKS'/'BLIND28_FROZEN.json',encoding='utf-8'))['items']
form=json.load(open(root/'BENCHMARKS'/'BLIND28_FORMAL_PREINFERENCE.json',encoding='utf-8'))['results']
fmap={r['id']:r for r in form}
raw={}
for t in TEACHERS:
    obj=json.load(open(root/'RAW_TEACHERS'/f'blind28_{t}.json',encoding='utf-8'))
    raw[t]={r['id']:r for r in obj['rows']}
rows=[]
for it in bench:
    fp=fmap[it['id']]
    rec={'block':'B28','id':it['id'],'q':it['q'],'domain_true':it['domain'],'gold':it['answer'],
         'formal_status':fp['status'],'formal_answer':fp.get('answer'),
         'formal_kind':((fp.get('ir') or {}).get('kind') if fp.get('ir') else 'NONE'),
         'formal_rule':((fp.get('ir') or {}).get('compiler_rule') if fp.get('ir') else 'NONE'),
         'options_json':json.dumps(it['options'],ensure_ascii=False,sort_keys=True)}
    for t in TEACHERS:
        rr=raw[t][it['id']]; rec[t+'_pred']=rr.get('pred')
        p=probs(rr.get('option_logprobs') or {})
        for j,a in enumerate(LABELS): rec[f'{t}_p{a}']=float(p[j])
    rows.append(rec)
b28=pd.DataFrame(rows)
all_df=pd.concat([old,b28],ignore_index=True)
all_df.to_csv('/mnt/data/r717_dev/R717_DISCLOSED_624.csv',index=False)
print(all_df.shape)
print(all_df.groupby('block').size().to_dict())
print('formal verified',int((all_df.formal_status=='VERIFIED').sum()))
print(all_df[['block','id','q','gold','domain_true']].tail(3).to_string(index=False))
