import sys,joblib,json,base64,torch,numpy as np
from pathlib import Path
sys.path.insert(0,'/mnt/data/r717_dev')
import train_eval_r717_meta as m
from run_seal_r717 import adapter_train
from seal_nexus import SelfEdit
idx=np.arange(len(m.DF))
xtr,xev,ctr,cev,rel,indep,central,router,pdict=m.d.make_context(idx,idx)
print('FINAL R717 TRAIN',len(idx),xtr.shape,flush=True)
model=m.train_critic(idx,xtr,ctr,central,epochs=9,seed=17717)
edit=SelfEdit(
 data_generation={'teacher_order_augmentation':True,'teacher_evidence_dropout':0.0,'hard_example_replay_ratio':0.1,'recurrent_prefix_augmentation':True},
 training={'strategy':'all_recurrent_steps','learning_rate':0.0005,'num_train_epochs':3,'lora_rank':4,'lora_alpha':4.0},
 inference={'max_query_branches':3,'quantum_inspired_branching':False})
ad=adapter_train(model,idx,xtr,ctr,central,edit,18717)
out=Path('/mnt/data/r717_final_models');out.mkdir(exist_ok=True)
torch.save(model.state_dict(),out/'recurrent_critic.pt');torch.save(ad.state_dict(),out/'seal_meta_adapter.pt')
joblib.dump(router,out/'domain_router.joblib');np.save(out/'reliability.npy',rel);np.save(out/'independence.npy',indep);np.save(out/'centrality.npy',central)
(out/'pattern_dictionary.json').write_text(json.dumps({'patterns':pdict.patterns,'scores':pdict.scores,'zdict_b64':base64.b64encode(pdict.zdict).decode()},ensure_ascii=False))
(out/'selected_self_edit.json').write_text(json.dumps({'data_generation':edit.data_generation,'training':edit.training,'inference':edit.inference},ensure_ascii=False,indent=2))
print('saved',out,flush=True)
