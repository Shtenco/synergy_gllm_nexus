from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
import runtime_r717 as r
item={'id':'SMOKE_ARITH','q':'Чему равно 17 × 23?','options':{'A':'371','B':'381','C':'391','D':'401'}}
out=r.decide(item,{})
assert out['answer']=='C' and out['stage']=='FORMAL_VERIFIED'
assert out['r717_policy']['direct_answer_override'] is False
assert out['recurrent_feedback']['feedback_role'].startswith('returned into')
print(json.dumps({'ok':True,'answer':out['answer'],'stage':out['stage'],'feedback_digest':out['recurrent_feedback']['feedback_digest']},ensure_ascii=False))
