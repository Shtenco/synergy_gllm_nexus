# R7.17 POLICY

- R7.16 formal/proof/answer core remains sovereign.
- R7.17 recurrent critic is advisory until fresh Blind-30 validation.
- SEAL updates only the small metacognitive LoRA surface; verifier/core hashes are not modified.
- Quantum-inspired branches rank future information-acquisition paths only.
- BIP39 remains deterministic exploration/query scheduling, never truth evidence.
- Direct BDH answer-head was rejected after disclosed LOBO accuracy 72.7564%.
- Blind-30 does not exist at freeze.
