# NEXUS R7.17 — Adaptive Recurrent Reasoning Core

R7.17 extends frozen R7.16 with three auxiliary organs:
1. BDH-inspired recurrent metacognitive critic with sparse positive activity, low-rank projections, Hebbian fast/slow synaptic memory and iterative latent rounds.
2. SEAL-inspired persistent LoRA self-adaptation on the metacognitive surface, selected by held-out reward with forgetting penalty.
3. Quantum-inspired complex-amplitude forecast of future query branches. This is classical software; it does not claim quantum computation or quantum advantage.

## Sovereignty
R7.16 remains the answer/proof core. R7.17 does not override final answers before fresh Blind-30 validation.

## Disclosed development evidence
- Direct BDH-inspired answer-head: 72.7564% on B22-B28 LOBO -> REJECTED.
- Static top-2 teacher oracle: 600/624; fusion 576/624.
- Recurrent classical top-3 teacher oracle: 605/624; fusion 585/624.
- Quantum-inspired top-2 fusion: 578/624 vs static 576/624, but oracle 599/624 vs 600/624 -> trade-off, advisory only.
- SEAL selected rank-4 LoRA, lr 5e-4, 3 epochs; B27/B28 classical metrics unchanged; forgetting 0 on the development protocol.

## Runtime feedback
`runtime_r717.decide()` returns the frozen R7.16 decision plus:
- current-hypothesis risk;
- predicted correctness/gain of each teacher;
- fast/slow synaptic norms;
- one-step and two-step quantum-inspired branch forecasts;
- recurrent feedback SHA-256 digest.

## Portability
R7.17 ships a local copy of the exact R7.10 formal compiler/solver/verifier runtime used by the historical graph code, removing dependence on a machine-specific `/mnt/data/r710_src/...` path while leaving frozen R7.16 bytes unchanged.

Blind-30 does not exist at freeze.
