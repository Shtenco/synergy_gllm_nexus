from __future__ import annotations
from pathlib import Path
import sys,json,base64,hashlib,math,joblib,numpy as np,torch
ROOT=Path(__file__).resolve().parents[1]
R716=ROOT/'base_r716'; R715=R716/'base_r715';R714=R715/'base_r714';R713=R714/'base_r713'
sys.path[:0]=[str(R716/'source'),str(R715/'source'),str(R714/'source'),str(R713/'source'),str(ROOT/'source')]
import runtime_r716 as r716
import graphboost_training as g
import morpholex_layer as ml
import compression_pattern_core as cp
from r717_bdh_core import BDHRecurrentCritic,BDHCoreConfig,LoRAMetaAdapter
from r717_quantum_branches_v2 import branch_forecast
from quantum_reasoning_tree import forecast_tree

T=g.TEACHERS;L=g.LABELS
ROUTER=joblib.load(ROOT/'models'/'domain_router.joblib')
REL=np.load(ROOT/'models'/'reliability.npy');INDEP=np.load(ROOT/'models'/'independence.npy');CENTRAL=np.load(ROOT/'models'/'centrality.npy')
pd=json.loads((ROOT/'models'/'pattern_dictionary.json').read_text())
PDICT=cp.PatternDictionary(pd['patterns'],pd['scores'],base64.b64decode(pd['zdict_b64']))
CFG=BDHCoreConfig(d_state=48,n_neurons=48,rank=16,active_k=10,latent_rounds=2,dropout=.06)
CONTEXT_DIM=311
CRITIC=BDHRecurrentCritic(CONTEXT_DIM,11,CFG);CRITIC.load_state_dict(torch.load(ROOT/'models'/'recurrent_critic.pt',map_location='cpu',weights_only=True));CRITIC.eval()
ADAPTER=LoRAMetaAdapter(48,4,4.0);ADAPTER.load_state_dict(torch.load(ROOT/'models'/'seal_meta_adapter.pt',map_location='cpu',weights_only=True));ADAPTER.eval()

POLICY={
 'name':'NEXUS R7.17 Adaptive Recurrent Reasoning Core',
 'base_answer_core':'R7.16 frozen BIP39 Adaptive Query CyberCore',
 'seal':'structured self-edit -> LoRA metacognitive adaptation -> held-out reward -> forgetting penalty',
 'pathway_public_methods':['sparse positive latent activity','low-rank communication','fixed-size recurrent synaptic memory','Hebbian outer-product writes','fast/slow memory timescales','iterative latent reasoning','evidence-conditioned recurrent context'],
 'quantum_branching':'classical quantum-inspired complex-amplitude future-query forecast; no quantum hardware or advantage claim',
 'direct_answer_override':False,
 'recurrent_query_override':False,
 'blind30_status':'DOES NOT EXIST AT FREEZE'
}

def _context(q,formal):
    H=g.HV.transform([q]).toarray().astype(np.float32)
    dp=g.domain_post(ROUTER,[q]).astype(np.float32)
    morph=ml.feature_vector(q)[None,:].astype(np.float32)
    comp=cp.text_sensor(q,PDICT)[None,:].astype(np.float32)
    fv=np.zeros((1,5),np.float32);fv[0,0]=1.0 if formal.get('status')=='VERIFIED' else 0.
    a=formal.get('answer');
    if a in g.L2I:fv[0,1+g.L2I[a]]=1.
    x=np.concatenate([H,dp,morph,comp,fv],axis=1)
    if x.shape[1]!=CONTEXT_DIM: raise RuntimeError(f'R717 context dim {x.shape[1]} != {CONTEXT_DIM}')
    return x,dp[0]

def _teacher_probs(row):
    if not row:return np.ones(4,np.float32)/4
    p=g.probs_from_lp(row.get('option_logprobs') or {})
    return np.asarray(p,np.float32)

def _ev(name,row,comp):
    j=T.index(name);e=np.zeros((1,11),np.float32);e[0,:4]=_teacher_probs(row);e[0,4+j]=1.;e[0,9]=comp[j];e[0,10]=CENTRAL[j];return e

def _softmax(z):
    z=np.asarray(z,float);z-=z.max();e=np.exp(np.clip(z,-50,50));return e/(e.sum()+1e-12)

def recurrent_state(item,teacher_rows,used,formal):
    q=item['q'];x,dp=_context(q,formal);comp=dp@REL;route=(np.clip(comp,1e-4,1)**.80)*(np.clip(CENTRAL,1e-4,1)**.20)
    with torch.no_grad():
        h,sf,ss=CRITIC.init_state(torch.tensor(x,dtype=torch.float32));steps=[];called=[]
        for name in used:
            if name not in T or name not in teacher_rows: continue
            h,sf,ss,tc,gn,risk=CRITIC.step(h,sf,ss,torch.tensor(_ev(name,teacher_rows[name],comp)))
            at,ag,ar=ADAPTER(h);tc=tc+at;gn=gn+ag;risk=risk+ar;called.append(T.index(name))
            steps.append({'teacher':name,'risk':float(torch.sigmoid(risk)[0]),'fast_synaptic_norm':float(sf.norm()),'slow_synaptic_norm':float(ss.norm()),'hidden_norm':float(h.norm())})
        tc,gn,risk=CRITIC.read_heads(h);at,ag,ar=ADAPTER(h);tc=tc+at;gn=gn+ag;risk=risk+ar
        pteacher=torch.sigmoid(tc).numpy()[0];gain=np.tanh(gn.numpy()[0]);riskp=float(torch.sigmoid(risk)[0])
        # Current answer posterior for forecasting only: average evidence if available, else uniform.
        if called:
            w=route[called];ps=np.stack([_teacher_probs(teacher_rows[T[j]]) for j in called]);post=(ps*w[:,None]).sum(0)/(w.sum()+1e-12);post=post/(post.sum()+1e-12)
        else:post=np.ones(4)/4
        avail=[j for j in range(5) if j not in called]
        seed=f"R717|{item.get('id','LIVE')}|{','.join(T[j] for j in called)}"
        one,one_rows=branch_forecast(post,avail,tc.numpy()[0],gn.numpy()[0],INDEP,called,seed,quantum=True)
        two,two_rows,leaves=forecast_tree(post,avail,tc.numpy()[0],gn.numpy()[0],INDEP,called,seed,depth=2,quantum=True)
        # Compact state fingerprint returned into the cybernetic feedback packet.
        digest_payload=np.concatenate([h.numpy().ravel(),np.array([float(sf.norm()),float(ss.norm()),riskp]),pteacher,gain]).round(6).tobytes()
        digest=hashlib.sha256(digest_payload).hexdigest()
        return {'steps':steps,'risk_current_hypothesis':riskp,'teacher_correctness_forecast':{T[j]:float(pteacher[j]) for j in range(5)},
                'teacher_gain_forecast':{T[j]:float(gain[j]) for j in range(5)},'one_step_quantum_branches':one_rows,
                'two_step_quantum_branches':two_rows,'two_step_leaf_count':len(leaves),'suggested_teacher_one_step':T[one] if one is not None else None,
                'suggested_teacher_two_step':T[two] if two is not None else None,'feedback_digest':digest,
                'feedback_role':'returned into latent/query planning state; not evidence of answer truth'}

def decide(item,teacher_rows=None):
    teacher_rows=teacher_rows or {}
    base=r716.decide(item,teacher_rows)
    formal=base.get('formal') or g.formal_pass(item)
    used=base.get('used') or []
    meta=recurrent_state(item,teacher_rows,used,formal)
    out=dict(base);out['r717_policy']=POLICY;out['recurrent_feedback']=meta
    # R7.16 remains sovereign until fresh Blind30 validates active override.
    if base.get('stage')=='NEED_BIP39_QUERY_TEACHER':
        out['r717_query_advice']={'r716_required_teacher':base.get('next_teacher'),'recurrent_suggested_teacher':meta['suggested_teacher_one_step'],
                                  'quantum_tree_suggested_teacher':meta['suggested_teacher_two_step'],'override_applied':False}
    return out
