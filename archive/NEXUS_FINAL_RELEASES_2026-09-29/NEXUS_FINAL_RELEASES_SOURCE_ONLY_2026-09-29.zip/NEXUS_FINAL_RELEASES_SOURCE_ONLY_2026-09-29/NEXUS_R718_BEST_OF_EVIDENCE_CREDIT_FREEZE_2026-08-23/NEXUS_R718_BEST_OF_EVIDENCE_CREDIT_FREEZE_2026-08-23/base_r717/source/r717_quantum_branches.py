from __future__ import annotations
import hashlib, math, numpy as np

# Classical implementation of a quantum-inspired branch forecaster.
# Complex amplitudes are used ONLY to diversify/score future query branches.
# They never vote directly on answer truth.

def phase_from_seed(seed:str,j:int,h:int)->float:
    d=hashlib.sha256(f'{seed}|T{j}|H{h}'.encode()).digest()
    u=int.from_bytes(d[:8],'big')/2**64
    return 2*math.pi*u

def choose_teacher(posterior, available, competence, independence, called, seed:str, quantum=True):
    p=np.asarray(posterior,float); p=p/(p.sum()+1e-12)
    scores=[]
    for j in available:
        ind=float(np.mean([independence[j,k] for k in called])) if called else float(independence[j].mean())
        rel=float(np.clip(competence[j],1e-4,1))
        classical=(rel**.80)*(max(ind,1e-4)**.20)
        if quantum:
            # amplitude branch across competing hypotheses; phase affects only query scheduling.
            amps=[]
            for h in range(4):
                phi=phase_from_seed(seed,j,h)
                # uncertain hypotheses get more exploration mass
                amps.append(math.sqrt(max(p[h],1e-12)*classical)*complex(math.cos(phi),math.sin(phi)))
            coherent=abs(sum(amps))**2
            incoherent=sum(abs(a)**2 for a in amps)+1e-12
            interference=np.clip(coherent/incoherent,0,4)
            # Keep the quantum-inspired term deliberately small and bounded.
            score=classical*(.94+.06*interference)
        else:
            score=classical
        scores.append((j,float(score)))
    return max(scores,key=lambda x:x[1])[0] if scores else None
