from __future__ import annotations
import math, random, copy
from dataclasses import dataclass
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F

@dataclass
class BDHCoreConfig:
    d_state:int=32
    n_neurons:int=32
    rank:int=16
    active_k:int=8
    latent_rounds:int=2
    fast_decay:float=.72
    slow_decay:float=.965
    fast_write:float=.55
    slow_write:float=.12
    dropout:float=.08

class BDHRecurrentEvidence(nn.Module):
    """BDH-inspired recurrent evidence aggregator.

    Not Pathway's BDH-CQ checkpoint. It ports published structural ideas:
    sparse non-negative neuron activity, low-rank projections, fixed-size
    Hebbian synaptic state, and iterative latent computation.
    """
    def __init__(self, context_dim:int, evidence_dim:int=11, cfg:BDHCoreConfig|None=None):
        super().__init__(); self.cfg=cfg or BDHCoreConfig(); C=self.cfg
        D,N,R=C.d_state,C.n_neurons,C.rank
        self.context=nn.Sequential(nn.Linear(context_dim,D), nn.LayerNorm(D), nn.GELU())
        inp=D+evidence_dim
        self.x_down=nn.Linear(inp,R,bias=False); self.x_up=nn.Linear(R,N,bias=False)
        self.v_down=nn.Linear(inp,R,bias=False); self.v_up=nn.Linear(R,N,bias=False)
        self.q_down=nn.Linear(D,R,bias=False); self.q_up=nn.Linear(R,N,bias=False)
        self.decoder=nn.Linear(N,D,bias=False)
        self.norm=nn.LayerNorm(D)
        self.drop=nn.Dropout(C.dropout)
        self.head=nn.Linear(D,4)

    def sparse_positive(self,z):
        z=F.relu(z)
        k=min(self.cfg.active_k,z.shape[-1])
        if k<z.shape[-1]:
            vals,idx=torch.topk(z,k,dim=-1)
            out=torch.zeros_like(z); out.scatter_(-1,idx,vals); z=out
        return z

    def init_state(self,ctx):
        h=self.context(ctx); B=h.shape[0]; N=self.cfg.n_neurons
        sf=torch.zeros(B,N,N,device=h.device,dtype=h.dtype)
        ss=torch.zeros_like(sf)
        return h,sf,ss

    def _latent(self,h,sigma):
        q=self.sparse_positive(self.q_up(self.q_down(h)))
        read=torch.bmm(q.unsqueeze(1),sigma).squeeze(1)
        y=q*F.relu(read)
        h=self.norm(h+self.drop(self.decoder(y)))
        return h

    def step(self,h,sf,ss,evidence):
        C=self.cfg
        u=torch.cat([h,evidence],dim=-1)
        x=self.sparse_positive(self.x_up(self.x_down(u)))
        v=self.sparse_positive(self.v_up(self.v_down(u)))
        outer=x.unsqueeze(2)*v.unsqueeze(1)
        sf=C.fast_decay*sf+C.fast_write*outer
        ss=C.slow_decay*ss+C.slow_write*outer
        sigma=sf+ss
        read=torch.bmm(x.unsqueeze(1),sigma).squeeze(1)
        y=x*F.relu(read)
        h=self.norm(h+self.drop(self.decoder(y)))
        for _ in range(C.latent_rounds): h=self._latent(h,sigma)
        return h,sf,ss,self.head(h)

    def forward_sequence(self,ctx,evidence_seq,step_mask=None,return_hidden=False):
        h,sf,ss=self.init_state(ctx); outs=[]; hs=[]
        B,T,_=evidence_seq.shape
        if step_mask is None: step_mask=torch.ones(B,T,device=ctx.device,dtype=torch.bool)
        last=self.head(h)
        for t in range(T):
            hn,sfn,ssn,logits=self.step(h,sf,ss,evidence_seq[:,t])
            m=step_mask[:,t].view(B,1)
            h=torch.where(m,hn,h)
            mm=m.view(B,1,1); sf=torch.where(mm,sfn,sf); ss=torch.where(mm,ssn,ss)
            last=torch.where(m,logits,last)
            outs.append(last); hs.append(h)
        if return_hidden: return last,outs,h,sf,ss
        return last,outs

class LoRAAnswerAdapter(nn.Module):
    def __init__(self,d_state:int=32,rank:int=4,alpha:float=4.0):
        super().__init__(); self.rank=rank; self.scale=alpha/max(1,rank)
        self.A=nn.Linear(d_state,rank,bias=False); self.B=nn.Linear(rank,4,bias=False)
        nn.init.normal_(self.A.weight,std=.02); nn.init.zeros_(self.B.weight)
    def forward(self,h): return self.B(self.A(h))*self.scale


def entropy4(p):
    p=np.clip(np.asarray(p,float),1e-12,1); return float(-(p*np.log(p)).sum()/math.log(4))


def softmax_np(z):
    z=np.asarray(z,float); z=z-z.max(); e=np.exp(np.clip(z,-50,50)); return e/(e.sum()+1e-12)

class BDHRecurrentCritic(nn.Module):
    """Metacognitive BDH-inspired organ.

    The sovereign answer core is external (R7.16). This organ predicts:
      * correctness probability of each still-uncalled teacher;
      * expected answer-fusion gain from querying each teacher;
      * risk that current weighted evidence hypothesis is wrong.
    It therefore controls information acquisition rather than answer truth.
    """
    def __init__(self, context_dim:int, evidence_dim:int=11, cfg:BDHCoreConfig|None=None):
        super().__init__()
        self.core=BDHRecurrentEvidence(context_dim,evidence_dim,cfg)
        D=self.core.cfg.d_state
        self.teacher_head=nn.Linear(D,5)
        self.gain_head=nn.Linear(D,5)
        self.risk_head=nn.Linear(D,1)

    @property
    def cfg(self): return self.core.cfg

    def init_state(self,ctx): return self.core.init_state(ctx)

    def read_heads(self,h):
        return self.teacher_head(h), self.gain_head(h), self.risk_head(h).squeeze(-1)

    def step(self,h,sf,ss,evidence):
        h,sf,ss,_=self.core.step(h,sf,ss,evidence)
        tc,g,r=self.read_heads(h)
        return h,sf,ss,tc,g,r


class LoRAMetaAdapter(nn.Module):
    """Small persistent SEAL adaptation surface; base recurrent critic stays frozen."""
    def __init__(self,d_state:int=32,rank:int=4,alpha:float=4.0):
        super().__init__(); self.rank=rank; self.scale=alpha/max(rank,1)
        self.A=nn.Linear(d_state,rank,bias=False)
        self.B_teacher=nn.Linear(rank,5,bias=False)
        self.B_gain=nn.Linear(rank,5,bias=False)
        self.B_risk=nn.Linear(rank,1,bias=False)
        nn.init.normal_(self.A.weight,std=.02)
        for m in (self.B_teacher,self.B_gain,self.B_risk): nn.init.zeros_(m.weight)
    def forward(self,h):
        z=self.A(h)*self.scale
        return self.B_teacher(z),self.B_gain(z),self.B_risk(z).squeeze(-1)
