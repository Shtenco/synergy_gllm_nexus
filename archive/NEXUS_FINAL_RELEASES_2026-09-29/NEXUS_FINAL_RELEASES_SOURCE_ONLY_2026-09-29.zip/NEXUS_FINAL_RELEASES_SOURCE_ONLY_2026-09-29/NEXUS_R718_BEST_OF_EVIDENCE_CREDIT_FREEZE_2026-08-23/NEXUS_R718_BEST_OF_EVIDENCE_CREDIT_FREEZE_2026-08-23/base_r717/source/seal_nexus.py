from __future__ import annotations
from dataclasses import dataclass,asdict
import hashlib,json,math,copy
from pathlib import Path
import numpy as np, torch
import torch.nn.functional as F
from torch import optim
from r717_bdh_core import LoRAMetaAdapter
from r717_quantum_branches_v2 import branch_forecast

@dataclass(frozen=True)
class SelfEdit:
    data_generation: dict
    training: dict
    inference: dict
    source: str='NEXUS recurrent error profile + deterministic BIP39 proposal bank'


def _bip_indices(seed:str):
    h=hashlib.sha256(seed.encode()).digest(); bits=''.join(f'{b:08b}' for b in h)
    cs=''.join(f'{b:08b}' for b in hashlib.sha256(h).digest())[:8]; s=bits+cs
    return [int(s[i:i+11],2) for i in range(0,264,11)]

def generate_self_edits(error_profile:dict,seed='R717-SEAL'):
    """SEAL-inspired structured self-edits.

    Like the official SEAL ARC prompt, edits select data-generation tools and
    training hyperparameters. Here the proposal seed is the recurrent error
    profile; BIP39 deterministically diversifies a bounded safe proposal bank.
    """
    state=json.dumps(error_profile,sort_keys=True,separators=(',',':'))
    idx=_bip_indices(seed+'|'+state)
    banks=[
      dict(drop=.00,hard=.10,lr=5e-4,epochs=3,rank=4,all_steps=True),
      dict(drop=.08,hard=.20,lr=8e-4,epochs=4,rank=4,all_steps=True),
      dict(drop=.16,hard=.35,lr=1.0e-3,epochs=4,rank=6,all_steps=True),
      dict(drop=.24,hard=.50,lr=7e-4,epochs=5,rank=6,all_steps=True),
      dict(drop=.12,hard=.60,lr=1.3e-3,epochs=3,rank=8,all_steps=False),
      dict(drop=.05,hard=.40,lr=1.6e-3,epochs=2,rank=8,all_steps=False),
    ]
    # select 5 distinct candidates by BIP39-derived ordering, always include balanced candidate 1
    order=[1]+[int(x%len(banks)) for x in idx]
    uniq=[]
    for j in order:
        if j not in uniq: uniq.append(j)
        if len(uniq)>=5: break
    edits=[]
    for j in uniq:
        b=banks[j]
        edits.append(SelfEdit(
          data_generation={'teacher_order_augmentation':True,'teacher_evidence_dropout':b['drop'],
                           'hard_example_replay_ratio':b['hard'],'recurrent_prefix_augmentation':True},
          training={'strategy':'all_recurrent_steps' if b['all_steps'] else 'final_recurrent_state',
                    'learning_rate':b['lr'],'num_train_epochs':b['epochs'],'lora_rank':b['rank'],'lora_alpha':float(b['rank'])},
          inference={'max_query_branches':3,'quantum_inspired_branching':False}
        ))
    return edits,{'seed_sha256':hashlib.sha256((seed+'|'+state).encode()).hexdigest(),'bip39_indices':idx}

def reward_score(metrics,base_metrics,edit):
    # Accuracy/retrieval gain, explicit catastrophic-forgetting penalty, and tiny update-cost penalty.
    forgetting=max(0.0,base_metrics['oracle']-metrics['oracle'])
    rescue_gain=metrics['rescue_rate']-base_metrics['rescue_rate']
    fusion_gain=metrics['fusion']-base_metrics['fusion']
    cost=.0005*edit.training['num_train_epochs']+.0001*edit.training['lora_rank']
    reward=(metrics['oracle']-base_metrics['oracle'])+.45*fusion_gain+.25*rescue_gain-1.25*forgetting-cost
    return float(reward),float(forgetting)

def edit_to_json(edit): return asdict(edit)
