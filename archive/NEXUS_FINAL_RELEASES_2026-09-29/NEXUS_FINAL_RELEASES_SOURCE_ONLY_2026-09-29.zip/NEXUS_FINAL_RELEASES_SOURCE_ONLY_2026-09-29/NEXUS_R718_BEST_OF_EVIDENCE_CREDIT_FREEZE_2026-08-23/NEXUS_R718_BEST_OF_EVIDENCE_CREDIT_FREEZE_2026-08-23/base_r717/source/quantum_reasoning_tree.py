from __future__ import annotations
import hashlib,math,numpy as np

# Classical quantum-inspired future-evidence tree.
# It represents alternative future query/answer trajectories with complex amplitudes.
# No quantum processor, superposition of physical states, or quantum speedup is claimed.

def _phase(seed,*parts):
    s='|'.join(map(str,(seed,)+parts));d=hashlib.sha256(s.encode()).digest()
    return 2*math.pi*(int.from_bytes(d[:8],'big')/2**64)

def _teacher_answer_predictive(current_p,q_correct):
    """Prior predictive answer distribution before the teacher is actually queried."""
    p=np.asarray(current_p,float);p=p/(p.sum()+1e-12);q=float(np.clip(q_correct,0,1))
    # Teacher is more likely to agree with high-posterior candidates when predicted reliable;
    # uncertainty allocates mass to alternatives. This is a branch prior, never evidence.
    base=q*p+(1-q)*(1-p)/3
    return base/(base.sum()+1e-12)

def _update_hypothetical(p,h,q):
    p=np.asarray(p,float).copy(); like=np.ones(4)*(1-q)/3; like[h]=q
    z=p*np.clip(like,1e-6,1); return z/(z.sum()+1e-12)

def forecast_tree(current_p,available,p_teacher,p_gain,independence,called,seed,depth=2,quantum=True):
    p=np.asarray(current_p,float);p=p/(p.sum()+1e-12)
    tq=1/(1+np.exp(-np.asarray(p_teacher,float)));gg=np.tanh(np.asarray(p_gain,float))
    leaves=[]
    for j in available:
        ind1=float(np.mean([independence[j,k] for k in called])) if called else float(np.mean(independence[j]))
        util1=float(np.clip(.58*tq[j]+.27*((gg[j]+1)/2)+.15*np.clip(ind1,0,1),1e-5,1))
        ah=_teacher_answer_predictive(p,tq[j])
        for h in range(4):
            prob1=float(ah[h]); p1=_update_hypothetical(p,h,tq[j])
            phi1=_phase(seed,'d1',j,h)
            amp1=math.sqrt(max(prob1*util1,1e-12))*complex(math.cos(phi1),math.sin(phi1)) if quantum else complex(math.sqrt(max(prob1*util1,1e-12)),0)
            if depth<2 or len(available)<=1:
                leaves.append({'path':[j],'answers':[h],'prob':prob1,'utility':util1,'amplitude':amp1})
                continue
            avail2=[k for k in available if k!=j]
            for k in avail2:
                ind2=float(np.mean([independence[k,z] for z in called+[j]]))
                util2=float(np.clip(.58*tq[k]+.27*((gg[k]+1)/2)+.15*np.clip(ind2,0,1),1e-5,1))
                ak=_teacher_answer_predictive(p1,tq[k])
                # Expected second-step utility is integrated over possible second answer.
                for h2 in range(4):
                    prob2=float(ak[h2]);phi2=_phase(seed,'d2',j,h,k,h2)
                    amp2=amp1*math.sqrt(max(prob2*util2,1e-12))*complex(math.cos(phi2),math.sin(phi2)) if quantum else amp1*math.sqrt(max(prob2*util2,1e-12))
                    leaves.append({'path':[j,k],'answers':[h,h2],'prob':prob1*prob2,'utility':util1*util2,'amplitude':amp2})
    # Marginalize by first action. Coherent amplitude is deliberately bounded by an incoherent term.
    action_rows=[]
    for j in available:
        ls=[x for x in leaves if x['path'][0]==j]
        if not ls: continue
        coherent=abs(sum(x['amplitude'] for x in ls))**2
        incoherent=sum(abs(x['amplitude'])**2 for x in ls)+1e-12
        expected=sum(x['prob']*x['utility'] for x in ls)
        interf=float(np.clip(coherent/incoherent,0,4))
        score=float(expected*(.985+.015*interf)) if quantum else float(expected)
        action_rows.append({'teacher':int(j),'score':score,'expected_utility':float(expected),'interference':interf,
                            'complex_amplitude':[float(sum(x['amplitude'] for x in ls).real),float(sum(x['amplitude'] for x in ls).imag)],
                            'n_future_paths':len(ls)})
    action_rows.sort(key=lambda x:x['score'],reverse=True)
    return (action_rows[0]['teacher'] if action_rows else None),action_rows,leaves
