from __future__ import annotations
import hashlib,math,numpy as np

# Quantum-inspired, classical-only branch forecasting.
# No quantum hardware and no quantum advantage are claimed.
# Complex amplitudes rank future INFORMATION-ACQUISITION branches only.

def _phase(seed,j,h):
    d=hashlib.sha256(f'{seed}|branch={j}|hyp={h}'.encode()).digest()
    return 2*math.pi*(int.from_bytes(d[:8],'big')/2**64)

def branch_forecast(posterior,available,p_teacher,p_gain,independence,called,seed,quantum=True):
    p=np.asarray(posterior,float); p=p/(p.sum()+1e-12)
    tq=1/(1+np.exp(-np.asarray(p_teacher,float)))
    gain=np.tanh(np.asarray(p_gain,float))
    rows=[]
    for j in available:
        ind=float(np.mean([independence[j,k] for k in called])) if called else float(np.mean(independence[j]))
        # classical expected information/gain utility, bounded positive
        classical=float(np.clip(.62*tq[j]+.23*((gain[j]+1)/2)+.15*np.clip(ind,0,1),1e-6,1))
        if quantum:
            amps=[]
            for h in range(4):
                phi=_phase(seed,j,h)
                a=math.sqrt(max(p[h],1e-12)*classical)*complex(math.cos(phi),math.sin(phi))
                amps.append(a)
            coherent=abs(sum(amps))**2; incoherent=sum(abs(a)**2 for a in amps)+1e-12
            interference=float(np.clip(coherent/incoherent,0,4))
            # Very small exploration modulation: quantum-inspired, never truth.
            score=classical*(.97+.03*interference)
            amp_real=float(sum(a.real for a in amps)); amp_imag=float(sum(a.imag for a in amps))
        else:
            interference=1.; score=classical; amp_real=amp_imag=0.
        rows.append({'teacher':int(j),'score':float(score),'classical':classical,
                     'p_teacher_correct':float(tq[j]),'pred_gain':float(gain[j]),
                     'independence':ind,'interference':interference,
                     'amplitude':[amp_real,amp_imag]})
    rows=sorted(rows,key=lambda r:r['score'],reverse=True)
    return (rows[0]['teacher'] if rows else None),rows
