import json, math, random, hashlib, time, zipfile, itertools
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
OUT=Path('/mnt/data/NEXUS_R7L_FAST_LEARNING_UNSEEN_OPERATOR_D192_2026-08-18');OUT.mkdir(exist_ok=True)
torch.set_num_threads(4)
try: torch.set_num_interop_threads(1)
except: pass
D=192; NSTATE=4; NOUT=4; STEPS=3; SEEDS=[711,712,713]
PERMS=list(itertools.permutations(range(NOUT))); OPS=[(p,q) for p in PERMS for q in PERMS]
rng=random.Random(20260818); rng.shuffle(OPS)
TRAIN_OPS=OPS[:448]; DEV_OPS=OPS[448:512]; HELDOUT_POOL=OPS[512:]
class Episode:
 def __init__(self,op,support_states,query_state,intent):
  self.op=op;self.support_states=support_states;self.query_state=query_state;self.intent=intent
  self.target=op[intent][query_state]
def make_episode(op,r):
 q=r.randrange(4);sup=[s for s in range(4) if s!=q];r.shuffle(sup);return Episode(op,sup,q,r.randrange(2))
def batch_features(eps):
 B=len(eps);S=torch.zeros(B,3,12);Q=torch.zeros(B,6);Y=torch.zeros(B,dtype=torch.long)
 for b,e in enumerate(eps):
  p,a=e.op
  for j,s in enumerate(e.support_states):S[b,j,s]=1;S[b,j,4+p[s]]=1;S[b,j,8+a[s]]=1
  Q[b,e.query_state]=1;Q[b,4+e.intent]=1;Y[b]=e.target
 return S,Q,Y
class R7(nn.Module):
 def __init__(self,d=D,steps=STEPS):
  super().__init__();self.d=d;self.steps=steps
  self.demo=nn.Sequential(nn.Linear(12,d),nn.GELU(),nn.Linear(d,d),nn.LayerNorm(d))
  self.query=nn.Sequential(nn.Linear(6,d),nn.GELU(),nn.Linear(d,d),nn.LayerNorm(d))
  self.sk=nn.Linear(d,d,bias=False);self.sv=nn.Linear(d,d,bias=False);self.hq=nn.Linear(d,d,bias=False)
  self.msg=nn.Sequential(nn.Linear(2*d,2*d),nn.GELU(),nn.Linear(2*d,d));self.g=nn.Linear(2*d,d);self.ln=nn.LayerNorm(d)
  self.eh=nn.Linear(d,4);self.ah=nn.Linear(d,4);self.halt=nn.Linear(d,1);self.ie=nn.Embedding(2,d)
 def forward(self,Sraw,Q):
  S=self.demo(Sraw);h=self.query(Q)+self.ie(Q[:,4:].argmax(-1));states=[];ps=[]
  for _ in range(self.steps):
   att=(self.hq(h)[:,None]@self.sk(S).transpose(-1,-2)/math.sqrt(self.d)).softmax(-1);mem=(att@self.sv(S)).squeeze(1)
   cand=self.msg(torch.cat([h,mem],-1));g=.08+.22*torch.sigmoid(self.g(torch.cat([h,mem],-1)));h=self.ln((1-g)*h+g*cand)
   states.append(h);ps.append(torch.sigmoid(self.halt(h)).squeeze(-1))
  rem=torch.ones(h.shape[0]);ws=[]
  for k,p in enumerate(ps):w=rem if k==len(ps)-1 else rem*p;ws.append(w);rem=rem*(1-p)
  W=torch.stack(ws,1);W=W/(W.sum(1,keepdim=True)+1e-9);z=sum(states[k]*W[:,k,None] for k in range(len(states)))
  ms=(W*torch.arange(1,len(states)+1)[None]).sum(1).mean();return self.eh(z),self.ah(z),ms,S,z
def train_seed(seed):
 torch.manual_seed(seed);m=R7();opt=torch.optim.AdamW(m.parameters(),lr=1.8e-3,weight_decay=.01);r=random.Random(seed+1000);ls=[];t=time.time()
 for step in range(260):
  eps=[make_episode(r.choice(TRAIN_OPS),r) for _ in range(64)];S,Q,Y=batch_features(eps);el,al,ms,_,_=m(S,Q);ints=Q[:,4:].argmax(-1);logits=torch.where(ints[:,None]==0,el,al)
  ye=torch.tensor([e.op[0][e.query_state] for e in eps]);ya=torch.tensor([e.op[1][e.query_state] for e in eps])
  loss=F.cross_entropy(logits,Y)+.35*F.cross_entropy(el,ye)+.35*F.cross_entropy(al,ya)+.012*ms
  opt.zero_grad();loss.backward();nn.utils.clip_grad_norm_(m.parameters(),1);opt.step();ls.append(float(loss))
 p=OUT/f'r7_seed{seed}.pt';torch.save(m.state_dict(),p)
 return m,{'seed':seed,'train_sec':time.time()-t,'final_loss':float(np.mean(ls[-100:])),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
@torch.no_grad()
def eval_ops(m,ops,seed,reps=4):
 correct=total=0;per=[];steps=[]
 for oi,op in enumerate(ops):
  eps=[]
  for rep in range(reps):
   for qs in range(4):
    for intent in (0,1):
     sup=[s for s in range(4) if s!=qs];random.Random(seed+oi*1000+rep*10+qs*2+intent).shuffle(sup);eps.append(Episode(op,sup,qs,intent))
  S,Q,Y=batch_features(eps);el,al,ms,_,_=m(S,Q);ints=Q[:,4:].argmax(-1);pred=torch.where(ints[:,None]==0,el,al).argmax(-1);ok=int((pred==Y).sum())
  correct+=ok;total+=len(eps);per.append(ok/len(eps));steps.append(float(ms))
 return {'accuracy':correct/total,'operator_all_queries':float(np.mean([x==1 for x in per])),'worst_operator':float(min(per)),'mean_steps':float(np.mean(steps)),'n':total}
models=[];train_info=[];dev=[]
for seed in SEEDS:
 m,ti=train_seed(seed);models.append(m);train_info.append(ti);dv=eval_ops(m,DEV_OPS,seed+50,2);dev.append({'seed':seed,**dv});print('trained',seed,ti['final_loss'],dv,flush=True)
freeze={'name':'NEXUS R7 Fast-Learning Unseen Operator','date':'2026-08-18','hidden_dim':D,'latent_steps_max':STEPS,'train_operator_count':len(TRAIN_OPS),'dev_operator_count':len(DEV_OPS),'heldout_pool_count':len(HELDOUT_POOL),'checkpoint_sha256':{str(x['seed']):x['sha256'] for x in train_info},'blind18_created_after_freeze':True,'authority_for_heldout_operators':'NONE','inference_weight_updates':False,'S_contract':'immutable fast memory written only from support demonstrations','H_contract':'contractive recurrent query workspace','boundary':'Synthetic/structured unseen-operator induction laboratory; not open-domain LM or ARC proof.'}
(OUT/'00_FREEZE_MANIFEST.json').write_text(json.dumps(freeze,indent=2,ensure_ascii=False),encoding='utf-8');(OUT/'01_TRAIN_DEV.json').write_text(json.dumps({'train':train_info,'dev':dev},indent=2,ensure_ascii=False),encoding='utf-8')
br=random.Random(2026081818);blind_ops=HELDOUT_POOL.copy();br.shuffle(blind_ops);blind_ops=blind_ops[:48]
blind=[]
for m,seed in zip(models,SEEDS):ev=eval_ops(m,blind_ops,seed+9000,8);blind.append({'seed':seed,**ev});print('blind',seed,ev,flush=True)
@torch.no_grad()
def eval_collective(models,ops,seed):
 correct=total=0;per=[];steps=[]
 for oi,op in enumerate(ops):
  eps=[]
  for rep in range(8):
   for qs in range(4):
    for intent in (0,1):
     sup=[s for s in range(4) if s!=qs];random.Random(seed+oi*10000+rep*100+qs*2+intent).shuffle(sup);eps.append(Episode(op,sup,qs,intent))
  S,Q,Y=batch_features(eps);ints=Q[:,4:].argmax(-1);els=[];als=[]
  for m in models:el,al,ms,_,_=m(S,Q);els.append(el);als.append(al);steps.append(float(ms))
  pred=torch.where(ints[:,None]==0,torch.stack(els).mean(0),torch.stack(als).mean(0)).argmax(-1);ok=int((pred==Y).sum());correct+=ok;total+=len(eps);per.append(ok/len(eps))
 return {'accuracy':correct/total,'operator_all_queries':float(np.mean([x==1 for x in per])),'worst_operator':float(min(per)),'mean_steps':float(np.mean(steps)),'n':total}
coll=eval_collective(models,blind_ops,2026081819);print('collective',coll,flush=True)
res={'freeze':freeze,'blind18':{'operator_count':len(blind_ops),'single_seed':blind,'collective':coll}}
(OUT/'02_BLIND18_RESULTS.json').write_text(json.dumps(res,indent=2,ensure_ascii=False),encoding='utf-8')
(OUT/'train_r7_unseen_operator.py').write_text(Path('/mnt/data/r7_large_unseen_operator_training.py').read_text(encoding='utf-8'),encoding='utf-8')
(OUT/'README_RU.md').write_text('# NEXUS R7 Fast-Learning Unseen Operator\n\n'+json.dumps(res,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
files=[p for p in OUT.iterdir() if p.is_file() and p.name!='SHA256SUMS.txt'];(OUT/'SHA256SUMS.txt').write_text('\n'.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}' for p in sorted(files))+'\n')
zp=Path('/mnt/data/NEXUS_R7L_FAST_LEARNING_UNSEEN_OPERATOR_D192_2026-08-18.zip')
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in OUT.iterdir():z.write(p,arcname=OUT.name+'/'+p.name)
print('ZIP',zp,hashlib.sha256(zp.read_bytes()).hexdigest(),flush=True)
