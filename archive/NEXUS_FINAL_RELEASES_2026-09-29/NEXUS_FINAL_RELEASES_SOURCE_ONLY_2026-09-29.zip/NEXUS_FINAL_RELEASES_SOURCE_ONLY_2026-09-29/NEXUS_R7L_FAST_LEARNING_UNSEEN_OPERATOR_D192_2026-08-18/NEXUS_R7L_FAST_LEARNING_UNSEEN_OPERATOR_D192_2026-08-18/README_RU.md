# NEXUS R7 Fast-Learning Unseen Operator

{
  "freeze": {
    "name": "NEXUS R7 Fast-Learning Unseen Operator",
    "date": "2026-08-18",
    "hidden_dim": 192,
    "latent_steps_max": 3,
    "train_operator_count": 448,
    "dev_operator_count": 64,
    "heldout_pool_count": 64,
    "checkpoint_sha256": {
      "711": "c447d872a0e9299aa3bbf0e82ad884c9b9ba4fcdf7514960c91b33d2ee50aff3",
      "712": "a6b949fde908aa801b5c69e702e1710d32e84e1c2627d0fadd9aab71e5cb7c18",
      "713": "b01679fa280a375966fae3221b98abe7528d5188675bae702f1f9c122b33116f"
    },
    "blind18_created_after_freeze": true,
    "authority_for_heldout_operators": "NONE",
    "inference_weight_updates": false,
    "S_contract": "immutable fast memory written only from support demonstrations",
    "H_contract": "contractive recurrent query workspace",
    "boundary": "Synthetic/structured unseen-operator induction laboratory; not open-domain LM or ARC proof."
  },
  "blind18": {
    "operator_count": 48,
    "single_seed": [
      {
        "seed": 711,
        "accuracy": 0.9348958333333334,
        "operator_all_queries": 0.6041666666666666,
        "worst_operator": 0.75,
        "mean_steps": 2.337776944041252,
        "n": 3072
      },
      {
        "seed": 712,
        "accuracy": 1.0,
        "operator_all_queries": 1.0,
        "worst_operator": 1.0,
        "mean_steps": 2.5100160390138626,
        "n": 3072
      },
      {
        "seed": 713,
        "accuracy": 0.9921875,
        "operator_all_queries": 0.9375,
        "worst_operator": 0.875,
        "mean_steps": 2.3502842634916306,
        "n": 3072
      }
    ],
    "collective": {
      "accuracy": 1.0,
      "operator_all_queries": 1.0,
      "worst_operator": 1.0,
      "mean_steps": 2.3993590821822486,
      "n": 3072
    }
  }
}
