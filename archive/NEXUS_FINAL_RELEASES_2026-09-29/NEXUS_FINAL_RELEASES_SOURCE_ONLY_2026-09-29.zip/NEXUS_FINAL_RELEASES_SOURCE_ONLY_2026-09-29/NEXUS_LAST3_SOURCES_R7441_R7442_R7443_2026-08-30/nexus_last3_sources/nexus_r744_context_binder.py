from __future__ import annotations
import re, json, hashlib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set
from nexus_r738_active_x2_semantic import R738Semantic, ChatResult

ROOT=Path(__file__).resolve().parent

@dataclass
class PendingSlotFrame:
    task_type:str
    slots:Dict[str,Optional[str]]
    required:List[str]
    created_turn:int
    source_text:str=''
    validated:bool=False
    def missing(self)->List[str]:
        return [k for k in self.required if not self.slots.get(k)]

@dataclass
class ValidatedContext:
    task_type:str
    entities:Set[str]=field(default_factory=set)
    answer_text:str=''
    explanation_text:str=''
    turn:int=0

class R744ContextBinder(R738Semantic):
    """NEXUS R7.44 CONTEXT BINDER.

    Adds three sovereign discourse mechanisms over frozen R7.38.3/X2:
      1. AnaphoraBinder: continuation requires explicit anaphora + compatible task/entities.
      2. PendingSlotFrame: ACTIVE_INQUIRY creates a typed persistent slot frame.
      3. HardContextBoundary: explicit topic reset clears executive + V8 conversational state.

    No neural/X2/semantic-governor weights are modified.
    """
    VERSION='NEXUS R7.44 CONTEXT BINDER'

    HARD_BOUNDARY=(
        'отдельный вопрос','другая тема','теперь о другом','новая тема','сменим тему',
        'не продолжая предыдущ','забудь предыдущ','сначала новый вопрос'
    )
    ANAPHORA=(
        'это','этот вывод','эта логика','эти три','эти контуры','вместе','так','такой вывод',
        'предыдущий вывод','предыдущий ответ','сказанное','из этого','почему именно так','объясни это'
    )

    def __init__(self,v8_package_root:Path):
        super().__init__(v8_package_root)
        self.turn_no=0
        self.pending_frame:Optional[PendingSlotFrame]=None
        self.validated_context:Optional[ValidatedContext]=None
        self.context_log=[]
        self.suspended_frames:List[PendingSlotFrame]=[]

    # ---------------- context mechanics ----------------
    @staticmethod
    def _norm(text:str)->str:
        return re.sub(r'\s+',' ',text.lower().replace('ё','е')).strip()

    @staticmethod
    def _tokens(text:str)->Set[str]:
        stop={'почему','как','что','кто','где','когда','какой','какая','какие','это','этот','эта','эти','и','или','но','а','в','на','по','для','из','с','со','к','ко','ли','же','бы','у','мы','я','мне','нам','он','она','они','его','ее','их','нужно','надо'}
        toks=set(re.findall(r'[а-яa-z0-9]+',R744ContextBinder._norm(text)))
        return {x for x in toks if len(x)>=3 and x not in stop}

    def _clear_v8_context(self):
        try:
            self.v8._page.locator('#nexusClear').click(timeout=1000)
        except Exception:
            try:
                self.v8._page.evaluate("()=>{document.querySelector('#nexusClear')?.click()}")
            except Exception:
                pass

    def _hard_reset(self,reason='explicit-boundary'):
        self.pending_frame=None
        self.suspended_frames.clear()
        self.validated_context=None
        self.last_inquiry=None
        self.last_world_result=None
        self.last_world_question=None
        self.last_route=None
        self._clear_v8_context()
        self.context_log.append({'turn':self.turn_no,'event':'HARD_CONTEXT_BOUNDARY','reason':reason})

    def _is_hard_boundary(self,t:str)->bool:
        return any(x in t for x in self.HARD_BOUNDARY)

    def _has_anaphora(self,t:str)->bool:
        return any(re.search(r'(?<![а-я])'+re.escape(x)+r'(?![а-я])',t) for x in self.ANAPHORA)

    def _new_semantic_entities(self,text:str)->Set[str]:
        t=self._norm(text)
        ents=set()
        lex={
            'маржа':('марж','нацен'), 'оборотный_капитал':('запас','дебитор','оборотн'),
            'налоги':('налог','усн','ндс','псн','нпд','ооо','ип'), 'резерв':('резерв','подуш','запас безопасности','страховоч'),
            'долг':('кредит','долг','займ','мфо'), 'портфель':('портфел','акци','облигац','инвест'),
            'ликвидность':('ликвид','кассов','денежн поток'), 'бизнес':('бизнес','проект','выручк','точк безубыточ','клиент','сотрудник'),
        }
        for name,stems in lex.items():
            if any(s in t for s in stems): ents.add(name)
        return ents

    def _anaphoric_followup_allowed(self,raw:str)->bool:
        if not self.validated_context:return False
        t=self._norm(raw)
        if not self._has_anaphora(t):return False
        current=self._new_semantic_entities(raw)
        # Pronoun/anaphora-only continuation is valid. If new explicit entities exist,
        # at least one must overlap the validated context; otherwise it is a new task.
        if not current:return True
        return bool(current & self.validated_context.entities)

    def _commit(self,task_type:str,answer:str,explanation:str='',entities:Optional[Set[str]]=None):
        ents=set(entities or ())
        self.validated_context=ValidatedContext(task_type,ents,answer,explanation or answer,self.turn_no)
        self.context_log.append({'turn':self.turn_no,'event':'VALIDATED_CONTEXT_COMMIT','task_type':task_type,'entities':sorted(ents)})

    def _followup_answer(self)->ChatResult:
        c=self.validated_context
        txt=c.explanation_text if c else 'Предыдущий валидированный вывод недоступен.'
        hidden={'status':'ANSWER','provenance':'DERIVED','context_binding':'ANAPHORA_VALIDATED','task_type':c.task_type if c else None,'context_committed':False}
        return ChatResult(txt,'R744_ANAPHORA_BINDER',hidden)

    # ---------------- slot frames ----------------
    def _start_tax_frame(self,raw:str)->ChatResult:
        slots={'form':None,'region':None,'activity':None,'revenue':None,'costs':None,'clients':None,'employees':None,'vat_need':None,'input_vat':None}
        self._fill_slots(slots,raw)
        req=['form','region','activity','revenue','costs','clients','employees','vat_need']
        self.pending_frame=PendingSlotFrame('TAX_DECISION',slots,req,self.turn_no,raw)
        return self._render_pending()

    def _start_business_frame(self,raw:str)->ChatResult:
        slots={'form':None,'region':None,'activity':None,'price':None,'volume':None,'variable_costs':None,'fixed_costs':None,'payment_terms':None,'clients':None,'employees':None,'vat_need':None,'capital':None}
        self._fill_slots(slots,raw)
        req=['form','region','activity','price','volume','variable_costs','fixed_costs','payment_terms','clients','employees','vat_need','capital']
        self.pending_frame=PendingSlotFrame('BUSINESS_PROFILE',slots,req,self.turn_no,raw)
        return self._render_pending()

    def _fill_slots(self,slots:Dict[str,Optional[str]],raw:str):
        t=self._norm(raw)
        if re.search(r'\bооо\b',t):slots['form']='ООО'
        elif re.search(r'\bип\b',t):slots['form']='ИП'
        regions=['москва','санкт-петербург','костанай','татарстан','башкортостан','новосибирск','екатеринбург','краснодар','самара','пермь']
        for r in regions:
            if r in t:slots['region']=r.title();break
        if 'b2b' in t or 'юрлиц' in t or 'компани' in t or 'корпоративн' in t:slots['clients']='B2B'
        elif 'b2c' in t or 'физлиц' in t or 'населени' in t:slots['clients']='B2C'
        if re.search(r'(нужен|нужно|выставля|счет.фактур).*ндс|ндс.*(нужен|нужно|обязател)',t):slots['vat_need']='да'
        if re.search(r'без\s+ндс|ндс\s+не\s+нужен',t):slots['vat_need']='нет'
        m=re.search(r'(\d+(?:[.,]\d+)?)\s*(млн|тыс)\s*(?:₽|руб\w*)?',t)
        if m:
            val=m.group(1).replace(',','.')+' '+m.group(2)+' ₽'
            if any(x in t for x in ['выручк','оборот','доход']):slots['revenue']=val
            if any(x in t for x in ['капитал','стартов','вложен']):slots['capital']=val
        if any(x in t for x in ['расход','затрат','себестоим']):slots['costs']='указаны'
        if any(x in t for x in ['входн','закупк с ндс','поставщик с ндс']):slots['input_vat']='есть/описан'
        if any(x in t for x in ['без сотрудник','работаю один','без штата']):slots['employees']='нет'
        else:
            m=re.search(r'(\d+)\s*(?:сотрудник|работник|человек)',t)
            if m:slots['employees']=m.group(1)
        # Generic activity phrases.
        act_patterns=['b2b-услуг','b2c-услуг','консалтинг','разработка','магазин','кафе','производств','торговл','сервис','агентств']
        for a in act_patterns:
            if a in t:slots['activity']=a;break
        if any(x in t for x in ['цена','чек']):slots['price']='указана'
        if any(x in t for x in ['объем продаж','объём продаж','продаж в месяц','клиентов в месяц']):slots['volume']='указан'
        if any(x in t for x in ['переменн']):slots['variable_costs']='указаны'
        if any(x in t for x in ['постоянн']):slots['fixed_costs']='указаны'
        if any(x in t for x in ['отсроч','предоплат','срок оплаты','платят через']):slots['payment_terms']='указаны'

    def _render_pending(self)->ChatResult:
        f=self.pending_frame
        missing=f.missing()
        labels={
            'form':'форма ИП/ООО','region':'регион','activity':'вид деятельности','revenue':'ожидаемая выручка',
            'costs':'расходы','clients':'B2B/B2C-клиенты','employees':'сотрудники','vat_need':'нужно ли выставлять НДС',
            'price':'цена/средний чек','volume':'объём продаж','variable_costs':'переменные расходы','fixed_costs':'постоянные расходы',
            'payment_terms':'сроки оплаты клиентов и поставщиков','capital':'стартовый капитал/ликвидный резерв'
        }
        if not missing:
            f.validated=True
            if f.task_type=='TAX_DECISION':
                txt='Минимальный профиль собран. Теперь налоговые варианты можно сравнивать по полной нагрузке: режим, НДС и вычеты, подтверждённые расходы, страховые взносы и денежный поток. Я не буду выбирать режим по одной номинальной ставке.'
                self._commit('TAX_DECISION',txt,'Потому что все обязательные слоты налогового профиля заполнены и решение больше не опирается на догадку.',{'налоги','бизнес'})
            else:
                txt='Минимальный профиль бизнеса собран. Теперь можно рассчитывать unit economics, точку безубыточности, оборотный капитал, кассовый цикл и налоговую нагрузку как одну связанную модель.'
                self._commit('BUSINESS_PROFILE',txt,'Потому что заполнены ключевые слоты спроса, цены, затрат, платёжного цикла, налогов и капитала.',{'бизнес','ликвидность','налоги'})
            self.pending_frame=None
            return ChatResult(txt,'R744_PENDING_SLOT_COMPLETE',{'status':'ANSWER','provenance':'DERIVED','context_committed':True})
        human=', '.join(labels.get(x,x) for x in missing)
        txt=('Я сохранил уже сообщённые параметры. Пока не хватает: '+human+'. Добавьте их — и я продолжу именно эту задачу, не начиная налоговый/бизнес-анализ заново.')
        hidden={'status':'NEED_INFO','provenance':'ACTIVE_INQUIRY','task_type':f.task_type,'missing':missing,'slots':dict(f.slots),'context_committed':False}
        self.last_route='ACTIVE_INQUIRY';self.last_inquiry=hidden
        return ChatResult(txt,'R744_PENDING_SLOT_FRAME',hidden)

    def _looks_like_slot_continuation(self,raw:str)->bool:
        if not self.pending_frame:return False
        t=self._norm(raw)
        if self._is_hard_boundary(t):return False
        # Explicit continuation language or presence of an expected slot value.
        if any(x in t for x in ['уточняю','добавлю','еще данные','ещё данные','чего еще не хватает','чего ещё не хватает','вот данные','по параметрам']):return True
        before=dict(self.pending_frame.slots)
        probe=dict(before);self._fill_slots(probe,raw)
        return any(probe.get(k)!=before.get(k) for k in probe)

    # ---------------- typed temporal execution ----------------
    @staticmethod
    def _month_after(month_text:str,year:int=2026):
        m=R744ContextBinder._norm(month_text)
        order=[('январ',2,'февраля',year),('феврал',3,'марта',year),('март',4,'апреля',year),('апрел',5,'мая',year),('май',6,'июня',year),('мая',6,'июня',year),('июн',7,'июля',year),('июл',8,'августа',year),('август',9,'сентября',year),('сентябр',10,'октября',year),('октябр',11,'ноября',year),('ноябр',12,'декабря',year),('декабр',1,'января',year+1)]
        for stem,_,name,y in order:
            if stem in m:return name,y
        return None,None

    def _usn_temporal(self,raw:str)->Optional[ChatResult]:
        t=self._norm(raw)
        if 'усн' not in t or '2025' not in t:return None
        # Amount closest to token 2025.
        amounts=[]
        for m in re.finditer(r'(\d+(?:[.,]\d+)?)\s*(?:млн|миллион)',t):
            amounts.append((float(m.group(1).replace(',','.')),m.start()))
        yidx=t.find('2025')
        if not amounts:return None
        y25=min(amounts,key=lambda x:abs(x[1]-yidx))[0]
        threshold=float(self.facts['usn_vat_exemption_2026']['value'])/1_000_000
        month_match=re.search(r'(январ\w*|феврал\w*|март\w*|апрел\w*|ма[йя]\w*|июн\w*|июл\w*|август\w*|сентябр\w*|октябр\w*|ноябр\w*|декабр\w*)\s*(?:2026\s*г\w*)?',t)
        crossing=any(x in t for x in ['превыс','перешаг','перешел границ','перешёл границ','вышел за','вышли выше','оказалс выше','перешел через','перешёл через'])
        if y25<=threshold and month_match and crossing:
            nxt,ny=self._month_after(month_match.group(1),2026)
            txt=f'При доходе за 2025 год {y25:g} млн ₽ на старте 2026 года действует освобождение от НДС. Если порог 20 млн ₽ превышен в {month_match.group(1)}, обязанность по НДС начинается с 1 {nxt} {ny} года.'
            self._commit('USN_TEMPORAL',txt,'Потому что temporal graph связывает событие превышения порога с правилом перехода на первое число следующего месяца.',{'налоги'})
            return ChatResult(txt,'R744_TEMPORAL_EXECUTION',{'status':'ANSWER','provenance':'EXTERNAL_VERIFIED_2026+DERIVED','context_committed':True,'income_2025_mrub':y25,'crossing_month':month_match.group(1),'effective':f'1 {nxt} {ny}'})
        return None

    # ---------------- public chat ----------------
    def chat(self,text:str)->ChatResult:
        self.turn_no+=1
        raw=text.strip();t=self._norm(raw)

        # 0. Explicit boundary is sovereign and clears both executive and legacy V8 history.
        if self._is_hard_boundary(t):
            self._hard_reset('explicit-user-boundary')
            cleaned=raw
            for x in self.HARD_BOUNDARY:
                cleaned=re.sub(re.escape(x), '', cleaned, flags=re.I).strip(' .,:;-')
            if not cleaned:
                return ChatResult('Контекст предыдущей задачи очищен. Можно начинать новую тему.','R744_HARD_CONTEXT_BOUNDARY',{'status':'ACK','context_committed':False})
            raw=cleaned;t=self._norm(raw)

        # 1. A pending inquiry owns only compatible slot-fill turns; unrelated questions break it.
        # Explicit resumption can restore the last quarantined frame.
        if not self.pending_frame and self.suspended_frames and any(x in t for x in ['вернемся к налог','вернёмся к налог','продолжим выбор налог','вернемся к бизнес','вернёмся к бизнес','продолжим финансовую модель']):
            self.pending_frame=self.suspended_frames.pop()
            self.context_log.append({'turn':self.turn_no,'event':'PENDING_FRAME_RESUMED','task_type':self.pending_frame.task_type})
            self._fill_slots(self.pending_frame.slots,raw)
            return self._render_pending()

        if self.pending_frame:
            if self._looks_like_slot_continuation(raw):
                self._fill_slots(self.pending_frame.slots,raw)
                return self._render_pending()
            # New substantive task => pending frame is suspended, never contaminates it.
            self.context_log.append({'turn':self.turn_no,'event':'PENDING_FRAME_SUSPENDED','task_type':self.pending_frame.task_type})
            self.suspended_frames.append(self.pending_frame)
            self.pending_frame=None

        # 2. Follow-up binding requires anaphora. "Почему" alone is never sufficient.
        if self._anaphoric_followup_allowed(raw):
            return self._followup_answer()

        # 3. Exact verified facts / temporal execution before decision inquiry.
        tmp=self._usn_temporal(raw)
        if tmp:return tmp
        if 'усн' in t and '2026' in t and any(x in t for x in ['лимит','предельн','максимальн']) and any(x in t for x in ['доход','выручк']):
            lim=self.facts['usn_limit_2026']['value']
            ans=f'Предельный доход для применения УСН в 2026 году — {self._mrub(lim)}.'
            self._commit('VERIFIED_FACT',ans,'Это прямой параметр из зафиксированного verified fact pack 2026.',{'налоги'})
            return self._verified(ans,['usn_limit_2026'])
        if ('псн' in t or 'патент' in t) and '2026' in t and any(x in t for x in ['лимит','доход','предельн']):
            lim=self.facts['psn_limit_2026']['value'];ans=f'Лимит дохода для применения ПСН в 2026 году — {self._mrub(lim)}.'
            self._commit('VERIFIED_FACT',ans,'Это прямой параметр из зафиксированного verified fact pack 2026.',{'налоги'})
            return self._verified(ans,['psn_limit_2026'])
        if 'усн' in t and 'ндс' in t and ('освобожд' in t or 'порог' in t) and '2025' in t:
            lim=self.facts['usn_vat_exemption_2026']['value'];ans=f'Для стартового освобождения от НДС на УСН в 2026 году доход за 2025 год должен быть не более {self._mrub(lim)}. При превышении порога уже в 2026 году НДС возникает с первого числа следующего месяца.'
            self._commit('VERIFIED_FACT',ans,'Это verified threshold плюс правило временного перехода.',{'налоги'})
            return self._verified(ans,['usn_vat_exemption_2026'])

        # 4. Start typed pending frames.
        if any(x in t for x in ['налоговый режим','система налогообложения','выбрать налоги','подобрать налоги']) or (('ооо' in t or 'ип' in t or 'бизнес' in t) and any(x in t for x in ['что выбрать по налог','какие данные для налог','сравнить налог'])):
            return self._start_tax_frame(raw)
        if any(x in t for x in ['точка безубыточ','точку безубыточ','финансовая модель бизнеса','финансовую модель бизнеса','экономика проекта','оборотный капитал бизнеса']):
            return self._start_business_frame(raw)

        # 5. Executive invariants with validated context commit.
        if 'марж' in t and 'нацен' in t:
            ans='Маржа считается от цены продажи, а наценка — от себестоимости. Поэтому наценка 25% не означает маржу 25%: базы расчёта разные.'
            self._commit('MARGIN_MARKUP',ans,'Потому что в знаменателе двух показателей стоят разные величины: у маржи — выручка, у наценки — себестоимость.',{'маржа'})
            return ChatResult(ans,'R744_TYPED_EXECUTION',{'status':'ANSWER','provenance':'LOGIC_INVARIANT','context_committed':True})
        if any(x in t for x in ['запас','дебитор']) and any(x in t for x in ['денежн','оборотн','ликвид']):
            ans='Рост запасов и дебиторской задолженности связывает деньги в оборотном капитале: бухгалтерская прибыль может расти, а свободных денег для платежей становиться меньше.'
            self._commit('WORKING_CAPITAL',ans,'Потому что прибыль и движение денежных средств различаются по времени: деньги могут быть уже признаны в выручке или вложены в запасы, но ещё не находиться на счёте.',{'оборотный_капитал','ликвидность'})
            return ChatResult(ans,'R744_TYPED_EXECUTION',{'status':'ANSWER','provenance':'LOGIC_INVARIANT','context_committed':True})
        if ('кредит' in t or 'долг' in t) and re.search(r'\b(?:3\d|4\d|5\d|6\d)\s*%',t):
            ans='При очень высокой процентной ставке дорогой долг обычно приоритетнее рискованных инвестиций: его погашение даёт гарантированную экономию процентов. Но минимальный ликвидный резерв нужно сохранить, чтобы не занимать снова при первом непредвиденном расходе.'
            self._commit('HIGH_DEBT',ans,'Потому что гарантированная стоимость долга сравнивается с негарантированной инвестиционной доходностью; сначала защищается ликвидность, затем сокращается самый дорогой долг.',{'долг','резерв'})
            return ChatResult(ans,'R744_TYPED_EXECUTION',{'status':'ANSWER','provenance':'LOGIC_INVARIANT','context_committed':True})
        if ('акци' in t or 'портфел' in t) and any(x in t for x in ['одного сектор','одной отрасл','нефтегаз','одного эмитент']):
            ans='Количество бумаг само по себе не создаёт диверсификацию. Если большинство позиций зависит от одного сектора, общий отраслевой шок может ударить по ним одновременно; нужны разные источники риска.'
            self._commit('DIVERSIFICATION',ans,'Потому что диверсификация определяется независимостью факторов риска, а не числом тикеров.',{'портфель'})
            return ChatResult(ans,'R744_TYPED_EXECUTION',{'status':'ANSWER','provenance':'LOGIC_INVARIANT','context_committed':True})
        if any(x in t for x in ['кассовый разрыв','кассового разрыва']) and any(x in t for x in ['почему','как','причин','рост']):
            ans='Кассовый разрыв возникает, когда обязательные платежи наступают раньше денежных поступлений. Рост продаж может даже усилить проблему, если деньги зависают в дебиторке или запасах быстрее, чем поступают от клиентов.'
            self._commit('CASH_GAP',ans,'Потому что срок признания прибыли и срок фактического поступления денег не совпадают.',{'ликвидность','бизнес'})
            return ChatResult(ans,'R744_TYPED_EXECUTION',{'status':'ANSWER','provenance':'LOGIC_INVARIANT','context_committed':True})

        # 6. Use inherited R7.38.3 semantics. Commit only validated ANSWER, never NEED_INFO.
        res=super().chat(raw)
        if res.hidden.get('status')=='ANSWER':
            ents=self._new_semantic_entities(raw)
            explanation='Предыдущий ответ прошёл через унаследованный русский Semantic/Cyber/Logic контур и был принят как валидированный ответ текущей задачи.'
            self._commit(res.route,res.text,explanation,ents)
        elif res.hidden.get('status')=='NEED_INFO':
            # Convert inherited free-form inquiry into a conservative pending frame when possible.
            if res.route=='ACTIVE_INQUIRY' and ('налог' in t or 'режим' in t):
                return self._start_tax_frame(raw)
        return res


def sha256(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()
