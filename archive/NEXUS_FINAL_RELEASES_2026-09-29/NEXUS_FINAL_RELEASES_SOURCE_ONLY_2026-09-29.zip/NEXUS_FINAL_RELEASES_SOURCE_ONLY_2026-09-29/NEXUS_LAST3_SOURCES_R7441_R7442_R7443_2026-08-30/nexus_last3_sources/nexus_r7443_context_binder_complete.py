from __future__ import annotations
import re
from nexus_r7442_context_binder_final import R7442ContextBinderFinal

class R7443ContextBinderComplete(R7442ContextBinderFinal):
    """R7.44.3 COMPLETE.
    Final pending-frame interrupt precedence:
      verified fact query > pending slot continuation.
    Also broadens VAT slot morphology. No model/semantic/X2 weights changed.
    """
    VERSION='NEXUS R7.44.3 CONTEXT BINDER COMPLETE'

    def _fill_slots(self,slots,raw):
        super()._fill_slots(slots,raw)
        t=self._norm(raw)
        if 'ндс' in t:
            if re.search(r'(не\s+нуж|без\s+ндс|не\s+треб)',t):
                slots['vat_need']='нет'
            elif any(x in t for x in ['требуется ндс','требуют ндс','ндс обязател','работаем с ндс','работать с ндс','нужен ндс','нужно ндс','выставлять ндс']):
                slots['vat_need']='да'

    def _independent_verified_fact_query(self,t:str)->bool:
        if ('ключев' in t and 'ставк' in t) and ('цб' in t or 'банк россии' in t):return True
        if 'ндс' in t and any(x in t for x in ['основная ставка','ставка ндс']) and ('2026' in t or 'сейчас' in t):return True
        if 'усн' in t and '2026' in t and any(x in t for x in ['лимит','предельн','максимальн']) and any(x in t for x in ['доход','выручк']):return True
        if ('псн' in t or 'патент' in t) and ('2026' in t or 'лимит' in t) and any(x in t for x in ['лимит','доход','предельн']):return True
        if ('самозан' in t or 'нпд' in t) and any(x in t for x in ['ставк','лимит','сколько']):return True
        if re.search(r'налог[а-я]*\s+на\s+прибыл',t) and any(x in t for x in ['ставк','сколько','2026']):return True
        return False

    def chat(self,text:str):
        raw=text.strip();t=self._norm(raw)
        # A factual lookup is an independent interrupt, never slot-filling evidence.
        if self.pending_frame and self._independent_verified_fact_query(t):
            self.suspended_frames.append(self.pending_frame)
            self.context_log.append({'turn':self.turn_no+1,'event':'PENDING_FRAME_SUSPENDED_FOR_VERIFIED_FACT','task_type':self.pending_frame.task_type})
            self.pending_frame=None
        return super().chat(raw)
