from __future__ import annotations
from nexus_r744_context_binder import R744ContextBinder

class R7441ContextBinderFinal(R744ContextBinder):
    """R7.44.1 FINAL minimal context patch after disclosed Dialogue-62.
    No neural/X2/semantic weights changed.
    - broadens explicit resume language for suspended BUSINESS_PROFILE/TAX_DECISION
    - broadens temporal/data anaphora without allowing bare 'почему' to bind
    """
    VERSION='NEXUS R7.44.1 CONTEXT BINDER FINAL'
    ANAPHORA=R744ContextBinder.ANAPHORA + (
        'этого момента','с этого момента','этой даты','с этой даты','со следующего месяца',
        'этих данных','эти данные','этого порога','этот порог','этого лимита','этот лимит'
    )

    def chat(self,text:str):
        raw=text.strip();t=self._norm(raw)
        # Resume a suspended typed frame only on explicit resume language + compatible domain.
        if not self.pending_frame and self.suspended_frames:
            resume=any(x in t for x in ['вернемся','вернёмся','продолжим','возобновим'])
            if resume:
                top=self.suspended_frames[-1]
                tax_compatible=top.task_type=='TAX_DECISION' and any(x in t for x in ['налог','режим','усн','ндс','псн','нпд'])
                biz_compatible=top.task_type=='BUSINESS_PROFILE' and any(x in t for x in ['финансов','модел','бизнес','безубыточ','оборотн'])
                if tax_compatible or biz_compatible:
                    self.turn_no+=1
                    self.pending_frame=self.suspended_frames.pop()
                    self.context_log.append({'turn':self.turn_no,'event':'PENDING_FRAME_RESUMED_V2','task_type':self.pending_frame.task_type})
                    self._fill_slots(self.pending_frame.slots,raw)
                    return self._render_pending()
        return super().chat(raw)
