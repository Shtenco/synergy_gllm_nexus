from __future__ import annotations
from nexus_r7441_context_binder_final import R7441ContextBinderFinal

class R7442ContextBinderFinal(R7441ContextBinderFinal):
    """R7.44.2 FINAL discourse closure.
    Strong explicit anaphora binds to the last validated context unless a hard/new-topic boundary exists.
    Bare interrogatives such as 'Почему маржа...' remain new tasks because they contain no anaphoric anchor.
    No neural/X2/semantic weights changed.
    """
    VERSION='NEXUS R7.44.2 CONTEXT BINDER FINAL'
    STRONG_ANAPHORA=(
        'это','это решение','этот вывод','эта логика','эти данные','этих данных','эти три','эти контуры',
        'с этого момента','этого момента','с этой даты','этой даты','со следующего месяца',
        'этот лимит','этого лимита','этот порог','этого порога','предыдущий вывод','предыдущий ответ','объясни это'
    )
    NEW_TOPIC_MARKERS=('отдельный вопрос','другая тема','новая тема','теперь о другом','сменим тему')

    def _anaphoric_followup_allowed(self,raw:str)->bool:
        if not self.validated_context:return False
        t=self._norm(raw)
        if any(x in t for x in self.NEW_TOPIC_MARKERS):return False
        if not self._has_anaphora(t):return False
        # Strong anaphora is itself a discourse pointer to the last validated answer.
        if any(x in t for x in self.STRONG_ANAPHORA):return True
        # Fallback to entity compatibility for weaker connectors such as 'вместе'.
        current=self._new_semantic_entities(raw)
        if not current:return True
        return bool(current & self.validated_context.entities)
