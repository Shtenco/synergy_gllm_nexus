from __future__ import annotations
import re
from nexus_r742_domain_guard import R742DomainGuard
from nexus_r737_unified import ChatResult

class R743Precedence(R742DomainGuard):
    """R7.43 PRECEDENCE + BUSINESS PROFILE.
    Dialogue-60 is disclosed development evidence. No neural/model weights changed.
    Precedence: exact/verified fact -> executive follow-up -> task graph -> legacy fallback.
    """
    VERSION='NEXUS R7.43 PRECEDENCE'

    def chat(self,text):
        raw=text.strip();t=raw.lower().replace('ё','е')
        # 1) Executive follow-up has priority over re-routing a short/semantic continuation.
        if self.last_executive_explanation and 'почему' in t and (any(x in t for x in ['контур','вместе','три','одновременно']) or len(re.findall(r'[а-яa-z0-9]+',t))<=10):
            return ChatResult(self.last_executive_explanation,'R743_EXECUTIVE_FOLLOWUP',{'status':'ANSWER','provenance':'DERIVED','context_committed':True})

        # 2) Verified fact lookup has priority over decision/inquiry classifiers.
        if 'усн' in t and 'ндс' in t and '2025' in t and '2026' in t and ('освобожд' in t or 'порог доход' in t) and not re.search(r'в\s+(?:январ|феврал|март|апрел|ма[йяе]|июн|июл|август|сентябр|октябр|ноябр|декабр)\w*\s+2026',t):
            lim=self.facts['usn_vat_exemption_2026']['value']
            return self._verified(f'Для стартового освобождения от НДС на УСН в 2026 году доход за 2025 год должен быть не более {self._mrub(lim)}. Если порог превышается уже в течение 2026 года, обязанность по НДС начинается с 1-го числа следующего месяца.',['usn_vat_exemption_2026'])
        if 'усн' in t and '2026' in t and any(x in t for x in ['лимит','предельн','максимальн']) and any(x in t for x in ['доход','выручк']):
            lim=self.facts['usn_limit_2026']['value']
            return self._verified(f'Предельный доход для применения УСН в 2026 году — {self._mrub(lim)}.',['usn_limit_2026'])
        if ('псн' in t or 'патент' in t) and '2026' in t and any(x in t for x in ['лимит','доход','предельн']):
            lim=self.facts['psn_limit_2026']['value']
            return self._verified(f'Лимит дохода для применения ПСН в 2026 году — {self._mrub(lim)}.',['psn_limit_2026'])

        # 3) Business-model inquiry before generic V8 categories.
        if any(x in t for x in ['точк безубыточ','точку безубыточ','финансовой модели','финансовую модель','оборотного капитал','оборотный капитал']) and any(x in t for x in ['бизнес','проект','сервис','магазин','идея','компан']):
            missing=['форма ИП/ООО','регион и вид деятельности','цена и объём продаж','переменные расходы','постоянные расходы','условия оплаты клиентов/поставщиков','сотрудники','НДС','стартовый капитал и резерв']
            return self._inquire('Для расчёта точки безубыточности и оборотного капитала нужны: форма ИП/ООО, регион и деятельность, цена и объём продаж, переменные и постоянные расходы, сроки оплаты клиентов и поставщиков, сотрудники, НДС, стартовый капитал и резерв. После этого можно построить unit economics, break-even и денежный цикл.',missing)
        return super().chat(raw)
