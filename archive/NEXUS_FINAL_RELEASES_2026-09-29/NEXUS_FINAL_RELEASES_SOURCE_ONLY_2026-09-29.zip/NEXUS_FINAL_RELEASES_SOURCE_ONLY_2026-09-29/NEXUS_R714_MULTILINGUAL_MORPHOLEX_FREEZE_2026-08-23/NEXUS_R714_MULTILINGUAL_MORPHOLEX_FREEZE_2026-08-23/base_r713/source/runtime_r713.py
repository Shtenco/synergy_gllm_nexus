from __future__ import annotations
from pathlib import Path
import sys,joblib,numpy as np,pandas as pd
from catboost import CatBoostClassifier,Pool
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
import graphboost_training as g
import bip39_cyber_layer as bip
import pairwise_cyber_training as pc
ROUTER=joblib.load(ROOT/'models/domain_router.joblib')
REL=np.load(ROOT/'models/reliability.npy');INDEP=np.load(ROOT/'models/independence.npy');CENTRAL=np.load(ROOT/'models/centrality.npy');A=np.load(ROOT/'models/adjacency.npy')
BASEMODEL=CatBoostClassifier();BASEMODEL.load_model(str(ROOT/'models/r713_base_graphboost.cbm'))
PAIRMODEL=CatBoostClassifier();PAIRMODEL.load_model(str(ROOT/'models/r713_pairwise_test.cbm'))
SWITCH_PROB=.57; EPSILON=.04; MAX_CYCLES=3; BASE_GATE=.25

def required_teachers(question):
    dp=g.domain_post(ROUTER,[question]); comp=dp@REL
    route=(np.clip(comp,1e-4,1)**.80)*(np.clip(CENTRAL[None,:],1e-4,1)**.20)
    idx=np.argsort(-route[0])[:2]
    return [g.TEACHERS[i] for i in idx],{g.TEACHERS[i]:float(route[0,i]) for i in range(len(g.TEACHERS))}

def _rec(item,teacher_rows,fp):
    rec={'block':'LIVE','id':item.get('id','LIVE'),'q':item['q'],'domain_true':item.get('domain','math'),'gold':'A',
         'formal_status':fp['status'],'formal_answer':fp.get('answer'),'formal_kind':((fp.get('ir') or {}).get('kind') if fp.get('ir') else 'NONE'),
         'formal_rule':((fp.get('ir') or {}).get('compiler_rule') if fp.get('ir') else 'NONE')}
    for t in g.TEACHERS:
        rr=teacher_rows.get(t) or {}; rec[t+'_pred']=rr.get('pred')
        pr=g.probs_from_lp(rr.get('option_logprobs') or {}) if rr else np.ones(4)/4
        for j,a in enumerate(g.LABELS):rec[f'{t}_p{a}']=float(pr[j])
    return pd.DataFrame([rec])

def decide(item,teacher_rows=None):
    teacher_rows=teacher_rows or {}
    fp=g.formal_pass(item)
    initial=bip.route_pack(item['q'],0,None,'INIT',0.0)
    symbolic={'sha256':initial['sha256'],'base58':initial['base58'],'bip39_indices':initial['indices'],'rows_4x6':initial['rows'],'cols_6x4':initial['cols']}
    if fp['status']=='VERIFIED' and fp.get('answer') in g.L2I:
        return {'answer':fp['answer'],'stage':'FORMAL_VERIFIED','calls':0,'used':[],'formal':fp,'symbolic_layer':symbolic,'cyber_chain':[]}
    top2,scores=required_teachers(item['q'])
    missing=[t for t in top2 if t not in teacher_rows]
    if missing:
        return {'answer':None,'stage':'NEED_TEACHERS','calls_needed':len(missing),'required':top2,'missing':missing,'route_scores':scores,'formal':fp,'symbolic_layer':symbolic}
    d=_rec(item,teacher_rows,fp); X,B,aux=g.make_features(d,ROUTER,REL,INDEP,CENTRAL,A)
    F=np.asarray(BASEMODEL.predict(Pool(X,baseline=B),prediction_type='RawFormulaVal'))
    base=int(np.argmax(B[0])); sug=int(np.argmax(F[0])); start=base
    if sug==base or F[0,sug]-B[0,base]>=BASE_GATE:start=sug
    startarr=np.array([start],int)
    final,trace=pc.tournament(PAIRMODEL,d,X,F,startarr,True,SWITCH_PROB,MAX_CYCLES,EPSILON)
    ans=g.LABELS[int(final[0])]
    return {'answer':ans,'stage':'CYBER_HYPOTHESIS_TEST','calls':2,'used':top2,'route_scores':scores,
            'base_graph':g.LABELS[base],'base_graphboost':g.LABELS[start],'formal':fp,'symbolic_layer':symbolic,'cyber_chain':trace[0]}
