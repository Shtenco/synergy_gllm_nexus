from __future__ import annotations
import hashlib, math
import numpy as np

LABELS='ABCD'

# Computational core of BIP39 for 256-bit entropy.  We intentionally use the
# canonical 11-bit word *indices* so this layer has zero runtime dependency on a
# word list.  If a UI wants words, the indices can be rendered through the
# standard 2048-word English list without changing any computation.
def sha256_bytes(text: str) -> bytes:
    return hashlib.sha256(text.encode('utf-8')).digest()

def base58_encode(data: bytes) -> str:
    alphabet=b'123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz'
    n=int.from_bytes(data,'big')
    out=bytearray()
    while n:
        n,r=divmod(n,58); out.append(alphabet[r])
    pad=0
    for b in data:
        if b==0: pad+=1
        else: break
    return (alphabet[:1]*pad + bytes(reversed(out or b'1'))).decode('ascii')

def entropy_to_bip39_indices(entropy: bytes) -> list[int]:
    ent=len(entropy)*8
    if ent not in (128,160,192,224,256):
        raise ValueError('BIP39 entropy must be 128/160/192/224/256 bits')
    cs=ent//32
    e_bits=''.join(f'{b:08b}' for b in entropy)
    h=hashlib.sha256(entropy).digest()
    c_bits=''.join(f'{b:08b}' for b in h)[:cs]
    bits=e_bits+c_bits
    return [int(bits[i:i+11],2) for i in range(0,len(bits),11)]

def rows_4x6(indices: list[int]) -> list[list[int]]:
    if len(indices)!=24: raise ValueError('24 BIP39 indices required')
    return [indices[i:i+6] for i in range(0,24,6)]

def cols_6x4(rows: list[list[int]]) -> list[list[int]]:
    return [[rows[r][c] for r in range(4)] for c in range(6)]

def feedback_text(question: str, cycle: int, hypothesis: str|None,
                  verdict: str|None, margin: float|None) -> str:
    if cycle==0:
        return question
    mb='NA' if margin is None else str(int(np.clip(math.floor((margin+4.0)*8),0,63)))
    return f'{question}\n<CYCLE={cycle};H={hypothesis};T={verdict};M={mb}>'

def route_pack(question: str, cycle: int=0, hypothesis: str|None=None,
               verdict: str|None=None, margin: float|None=None) -> dict:
    seed=feedback_text(question,cycle,hypothesis,verdict,margin)
    entropy=sha256_bytes(seed)
    idx=entropy_to_bip39_indices(entropy)
    rows=rows_4x6(idx); cols=cols_6x4(rows); routes=rows+cols
    # Route ID is itself feedback-sensitive.  It chooses one of 4 row probes or
    # 6 column probes but never encodes a truth label.
    hidx=LABELS.index(hypothesis) if (hypothesis is not None and hypothesis in LABELS) else 0
    vcode={'INIT':0,'CONFIRM':1,'ACCEPT':2,'REJECT':3,None:0}.get(verdict,0)
    rid=(sum(idx[::3]) + 17*cycle + 29*hidx + 31*vcode) % 10
    route=routes[rid]
    return {
        'seed_text':seed,
        'sha256':entropy.hex(),
        'base58':base58_encode(entropy),
        'indices':idx,
        'rows':rows,
        'cols':cols,
        'route_id':int(rid),
        'route_kind':'ROW' if rid<4 else 'COL',
        'route':route,
    }

def _stats(v: np.ndarray) -> list[float]:
    x=v.astype(float)/2047.0
    if len(x)>1: d=np.diff(x)
    else: d=np.array([0.0])
    # Circular phase gives a smooth representation of arbitrary 11-bit index.
    ang=2*np.pi*x
    return [
        float(x.mean()), float(x.std()), float(x.min()), float(x.max()),
        float(np.median(x)), float(np.mean(np.abs(d))), float(d.mean()),
        float(np.sin(ang).mean()), float(np.cos(ang).mean()),
        float(np.mean((v%2)==0)), float(np.mean((v%3)==0)), float(np.mean((v%5)==0)),
    ]

def probe_features(question: str, cycle: int=0, hypothesis: str|None=None,
                   verdict: str|None=None, margin: float|None=None) -> tuple[np.ndarray,dict]:
    p=route_pack(question,cycle,hypothesis,verdict,margin)
    idx=np.asarray(p['indices'],dtype=float)
    route=np.asarray(p['route'],dtype=float)
    # 24 canonical word-index features + whole-seed summary + selected route
    # summary + route/cycle/hypothesis/verdict one-hots.
    feats=list(idx/2047.0)
    feats += _stats(idx)
    feats += _stats(route)
    feats += [len(route)/6.0]
    kind=[1.0,0.0] if p['route_kind']=='ROW' else [0.0,1.0]
    feats += kind
    feats += [1.0 if p['route_id']==j else 0.0 for j in range(10)]
    feats += [1.0 if cycle==j else 0.0 for j in range(4)]
    feats += [1.0 if hypothesis==a else 0.0 for a in LABELS]
    feats += [1.0 if verdict==v else 0.0 for v in ('INIT','CONFIRM','ACCEPT','REJECT')]
    feats += [0.0 if margin is None else float(np.tanh(margin/3.0))]
    return np.asarray(feats,dtype=np.float32),p

FEATURE_DIM=len(probe_features('dimension check')[0])

if __name__=='__main__':
    x,p=probe_features('Гипотеза — тест — гипотеза — тест')
    print('feature_dim',len(x),'route',p['route_id'],p['route_kind'])
    print('sha256',p['sha256'])
    print('indices',p['indices'])
    print('rows',p['rows'])
    print('cols',p['cols'])
