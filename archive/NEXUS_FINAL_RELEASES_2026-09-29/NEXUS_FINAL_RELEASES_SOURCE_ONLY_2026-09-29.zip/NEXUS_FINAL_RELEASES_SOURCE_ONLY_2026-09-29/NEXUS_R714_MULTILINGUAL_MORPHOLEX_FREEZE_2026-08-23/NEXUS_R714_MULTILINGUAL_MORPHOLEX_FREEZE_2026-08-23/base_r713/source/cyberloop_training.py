from __future__ import annotations
import json, sys, math
from pathlib import Path
import numpy as np, pandas as pd
from catboost import CatBoostClassifier, Pool

BASE=Path('/mnt/data')
R712=BASE/'NEXUS_R712_GRAPHBOOST_FREEZE_2026-08-23'
sys.path.insert(0,str(R712/'source'))
import graphboost_training as g
sys.path.insert(0,str(BASE/'r713_dev'))
import bip39_cyber_layer as bip

LABELS=g.LABELS; L2I=g.L2I; TEACHERS=g.TEACHERS

def load_all_disclosed():
    df=g.load_data().copy()
    # Blind-28, now disclosed development data for R7.13.
    bench=json.loads((BASE/'BLIND28_FROZEN.json').read_text(encoding='utf-8'))
    raws={}
    for t in TEACHERS:
        obj=json.loads((BASE/f'NEXUS_R712_GRAPHBOOST_REAL_BLIND28_2026-08-23/RAW_TEACHERS/blind28_{t}.json').read_text(encoding='utf-8'))
        raws[t]={r['id']:r for r in obj['rows']}
    rows=[]
    for it in bench['items']:
        fp=g.formal_pass(it)
        rec={'block':'B28','id':it['id'],'q':it['q'],'domain_true':it['domain'],'gold':it['answer'],
             'formal_status':fp['status'],'formal_answer':fp.get('answer'),
             'formal_kind':((fp.get('ir') or {}).get('kind') if fp.get('ir') else 'NONE'),
             'formal_rule':((fp.get('ir') or {}).get('compiler_rule') if fp.get('ir') else 'NONE')}
        for t in TEACHERS:
            rr=raws[t][it['id']]; rec[t+'_pred']=rr.get('pred')
            p=g.probs_from_lp(rr.get('option_logprobs') or {})
            for j,a in enumerate(LABELS): rec[f'{t}_p{a}']=float(p[j])
        rows.append(rec)
    return pd.concat([df,pd.DataFrame(rows)],ignore_index=True)

def softmax(z):
    z=np.asarray(z,float); z=z-z.max(axis=1,keepdims=True)
    e=np.exp(np.clip(z,-50,50)); return e/(e.sum(axis=1,keepdims=True)+1e-12)

def state_features(F, prev_verdicts, cycle):
    P=softmax(F); order=np.argsort(-P,axis=1)
    top=P[np.arange(len(P)),order[:,0]]; second=P[np.arange(len(P)),order[:,1]]
    margin=top-second
    ent=-(P*np.log(np.clip(P,1e-9,1))).sum(1)/math.log(4)
    out=[P, F-np.mean(F,axis=1,keepdims=True), margin[:,None], ent[:,None]]
    hyp=np.argmax(F,axis=1)
    h1=np.zeros((len(F),4),np.float32); h1[np.arange(len(F)),hyp]=1
    out.append(h1)
    vnames=['INIT','CONFIRM','ACCEPT','REJECT']
    vv=np.zeros((len(F),4),np.float32)
    for i,v in enumerate(prev_verdicts):
        if v in vnames: vv[i,vnames.index(v)]=1
    out.append(vv)
    c=np.zeros((len(F),3),np.float32); c[:,min(cycle,2)]=1; out.append(c)
    return np.concatenate(out,axis=1).astype(np.float32)

def cyber_features(qs,F,prev_verdicts,prev_margins,cycle,use_bip=True):
    hyp=np.argmax(F,axis=1)
    feats=[]; packs=[]
    for i,q in enumerate(qs):
        h=LABELS[hyp[i]]
        if use_bip:
            x,p=bip.probe_features(q,cycle,h,prev_verdicts[i],prev_margins[i])
        else:
            x=np.zeros(bip.FEATURE_DIM,dtype=np.float32); p={'route_id':-1,'route_kind':'NONE','sha256':None,'indices':[]}
        feats.append(x); packs.append(p)
    return np.stack(feats),packs

def raw_pred(model,X,B):
    return np.asarray(model.predict(Pool(X,baseline=B),prediction_type='RawFormulaVal'))

def formal_override(df,pred):
    out=pred.copy(); fa=np.array([L2I.get(x,-1) for x in df.formal_answer])
    z=(df.formal_status.values=='VERIFIED')&(fa>=0); out[z]=fa[z]
    return out

def apply_test(F,raw,gate=.25):
    cur=np.argmax(F,1); sug=np.argmax(raw,1)
    verdict=[]; margins=[]; new=F.copy(); changed=[]
    for i in range(len(F)):
        if sug[i]==cur[i]:
            # hypothesis confirmed: let the test sharpen/reshape internal state.
            new[i]=raw[i]; verdict.append('CONFIRM');
            m=float(raw[i,sug[i]]-np.partition(raw[i],-2)[-2]); margins.append(m); changed.append(False)
        else:
            adv=float(raw[i,sug[i]]-F[i,cur[i]])
            if adv>=gate:
                new[i]=raw[i]; verdict.append('ACCEPT'); changed.append(True)
            else:
                verdict.append('REJECT'); changed.append(False)
            margins.append(adv)
    return new,np.array(verdict,dtype=object),np.array(margins,float),np.array(changed,bool)

def fit_one_shot(train,test,router,rel,indep,central,A,params,gate=.25):
    Xtr,Btr,_=g.make_features(train,router,rel,indep,central,A)
    Xte,Bte,_=g.make_features(test,router,rel,indep,central,A)
    ytr=np.array([L2I[x] for x in train.gold]); unk=train.formal_status.values!='VERIFIED'
    m=CatBoostClassifier(loss_function='MultiClass',verbose=False,random_seed=713,**params)
    m.fit(Pool(Xtr[unk],label=ytr[unk],baseline=Btr[unk]))
    raw=raw_pred(m,Xte,Bte); base=np.argmax(Bte,1); sug=np.argmax(raw,1)
    final=base.copy()
    for i in range(len(test)):
        if sug[i]==base[i]: final[i]=sug[i]
        elif raw[i,sug[i]]-Bte[i,base[i]]>=gate: final[i]=sug[i]
    return formal_override(test,final)

def fit_cyclic(train,test,router,rel,indep,central,A,use_bip=True,cycles=3,trees_per=40,gate=.25):
    Xtr0,Btr,_=g.make_features(train,router,rel,indep,central,A)
    Xte0,Bte,_=g.make_features(test,router,rel,indep,central,A)
    ytr=np.array([L2I[x] for x in train.gold]); unk=train.formal_status.values!='VERIFIED'
    Ftr=Btr.copy(); Fte=Bte.copy()
    vtr=np.array(['INIT']*len(train),dtype=object); vte=np.array(['INIT']*len(test),dtype=object)
    mtr=np.zeros(len(train)); mte=np.zeros(len(test))
    models=[]; trace=[[] for _ in range(len(test))]
    for c in range(cycles):
        ctr,ptr=cyber_features(train.q.values,Ftr,vtr,mtr,c,use_bip)
        cte,pte=cyber_features(test.q.values,Fte,vte,mte,c,use_bip)
        strf=state_features(Ftr,vtr,c); stef=state_features(Fte,vte,c)
        Xtr=np.concatenate([Xtr0,strf,ctr],axis=1)
        Xte=np.concatenate([Xte0,stef,cte],axis=1)
        model=CatBoostClassifier(loss_function='MultiClass',verbose=False,random_seed=713+c,
            iterations=trees_per,depth=4,learning_rate=.055,l2_leaf_reg=6,random_strength=.4,border_count=48)
        model.fit(Pool(Xtr[unk],label=ytr[unk],baseline=Ftr[unk]))
        rawtr=raw_pred(model,Xtr,Ftr); rawte=raw_pred(model,Xte,Fte)
        oldtr=Ftr.copy(); oldte=Fte.copy()
        Ftr,vtr,mtr,chtr=apply_test(Ftr,rawtr,gate)
        Fte,vte,mte,chte=apply_test(Fte,rawte,gate)
        for i in range(len(test)):
            h0=LABELS[int(np.argmax(oldte[i]))]; h1=LABELS[int(np.argmax(Fte[i]))]
            trace[i].append({'cycle':c,'hypothesis_before':h0,'route_id':pte[i]['route_id'],'route_kind':pte[i]['route_kind'],
                             'test_suggestion':LABELS[int(np.argmax(rawte[i]))],'verdict':str(vte[i]),
                             'test_margin':float(mte[i]),'hypothesis_after':h1,'state_changed':bool(chte[i]),
                             'probe_sha256':pte[i]['sha256']})
        models.append(model)
    pred=formal_override(test,np.argmax(Fte,1))
    return pred,models,trace

def evaluate_fold(train,test):
    router=g.fit_router(train); rel,indep,central,A=g.hist_stats(train)
    params={'iterations':120,'depth':4,'learning_rate':.055,'l2_leaf_reg':6,'random_strength':.4,'border_count':48}
    y=np.array([L2I[x] for x in test.gold])
    Xte,Bte,_=g.make_features(test,router,rel,indep,central,A)
    base=formal_override(test,np.argmax(Bte,1))
    one=fit_one_shot(train,test,router,rel,indep,central,A,params)
    nob,_,_=fit_cyclic(train,test,router,rel,indep,central,A,use_bip=False)
    bipred,_,_=fit_cyclic(train,test,router,rel,indep,central,A,use_bip=True)
    return {
      'n':len(test),'formal':int((test.formal_status=='VERIFIED').sum()),
      'graph':float((base==y).mean()),'oneshot120':float((one==y).mean()),
      'cyclic3x40_no_bip':float((nob==y).mean()),'cyclic3x40_bip':float((bipred==y).mean())
    }

def main():
    df=load_all_disclosed(); print('DATA',len(df),df.block.value_counts().sort_index().to_dict())
    folds=[]
    for hold in sorted(df.block.unique()):
        tr=df[df.block!=hold].reset_index(drop=True); te=df[df.block==hold].reset_index(drop=True)
        m=evaluate_fold(tr,te); m['holdout']=hold; folds.append(m); print(hold,m,flush=True)
    total=sum(x['n'] for x in folds)
    weighted={k:sum(x[k]*x['n'] for x in folds)/total for k in ['graph','oneshot120','cyclic3x40_no_bip','cyclic3x40_bip']}
    out={'n':len(df),'folds':folds,'weighted':weighted,'bip_feature_dim':bip.FEATURE_DIM,'cycles':3,'trees_per_cycle':40,'gate':.25}
    (BASE/'R713_DEV_CV.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print('WEIGHTED',json.dumps(weighted,indent=2))
if __name__=='__main__': main()
