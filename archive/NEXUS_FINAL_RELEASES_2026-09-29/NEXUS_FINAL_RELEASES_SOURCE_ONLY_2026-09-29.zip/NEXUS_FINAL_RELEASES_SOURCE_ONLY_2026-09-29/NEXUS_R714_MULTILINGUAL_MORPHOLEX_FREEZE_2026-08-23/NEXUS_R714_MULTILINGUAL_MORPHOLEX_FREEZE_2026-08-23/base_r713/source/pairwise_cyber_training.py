from __future__ import annotations
import sys, math, json
from pathlib import Path
import numpy as np, pandas as pd
from catboost import CatBoostClassifier, Pool

BASE=Path('/mnt/data'); R712=BASE/'NEXUS_R712_GRAPHBOOST_FREEZE_2026-08-23'
sys.path.insert(0,str(R712/'source')); import graphboost_training as g
sys.path.insert(0,str(BASE/'r713_dev')); import bip39_cyber_layer as bip
from cyberloop_training import load_all_disclosed, raw_pred, formal_override, softmax

LABELS=g.LABELS; L2I=g.L2I
PAIRS=[(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)]
PAIR2I={p:i for i,p in enumerate(PAIRS)}

def one_shot_models(train,test,router,rel,indep,central,A,gate=.25):
    Xtr,Btr,atr=g.make_features(train,router,rel,indep,central,A)
    Xte,Bte,ate=g.make_features(test,router,rel,indep,central,A)
    ytr=np.array([L2I[x] for x in train.gold]); unk=train.formal_status.values!='VERIFIED'
    m=CatBoostClassifier(loss_function='MultiClass',verbose=False,random_seed=713,
        iterations=120,depth=4,learning_rate=.055,l2_leaf_reg=6,random_strength=.4,border_count=48)
    m.fit(Pool(Xtr[unk],label=ytr[unk],baseline=Btr[unk]))
    Ftr=raw_pred(m,Xtr,Btr); Fte=raw_pred(m,Xte,Bte)
    def gated(B,F):
        base=np.argmax(B,1); sug=np.argmax(F,1); out=base.copy()
        for i in range(len(B)):
            if sug[i]==base[i] or F[i,sug[i]]-B[i,base[i]]>=gate: out[i]=sug[i]
        return out
    return Xtr,Btr,Ftr,gated(Btr,Ftr),Xte,Bte,Fte,gated(Bte,Fte),m

def original_bip(q):
    # Exact question-only layer. 4 rows=4 hypotheses, 6 cols=6 pair tests.
    p=bip.route_pack(q,0,None,'INIT',0.0)
    return p

def vector_stats(vals):
    x=np.asarray(vals,float)/2047.; d=np.diff(x) if len(x)>1 else np.array([0.])
    return np.array([x.mean(),x.std(),x.min(),x.max(),np.median(x),np.mean(abs(d)),d.mean(),
                     np.sin(2*np.pi*x).mean(),np.cos(2*np.pi*x).mean()],dtype=np.float32)

def pair_extra(q,F,a,b,use_bip=True):
    P=softmax(np.asarray(F)[None,:])[0]
    pidx=PAIR2I[tuple(sorted((a,b)))]
    one=np.zeros(6,np.float32); one[pidx]=1
    cand=np.zeros(8,np.float32); cand[a]=1; cand[4+b]=1
    state=np.concatenate([P.astype(np.float32),(F-F.mean()).astype(np.float32),
                          np.array([P[a],P[b],P[a]-P[b],F[a]-F[b]],np.float32)])
    if not use_bip:
        return np.concatenate([one,cand,state,np.zeros(36,np.float32)])
    pack=original_bip(q); rows=pack['rows']; cols=pack['cols']
    # Hypothesis rows and the corresponding pair-test column.
    ra=np.asarray(rows[a],float); rb=np.asarray(rows[b],float); col=np.asarray(cols[pidx],float)
    # 6+6+4 raw normalized + 3x compact stats(9)=43; compress to 36 by stats + means/diffs.
    bx=np.concatenate([
        ra.astype(np.float32)/2047.,rb.astype(np.float32)/2047.,col.astype(np.float32)/2047.,
        vector_stats(ra),vector_stats(rb),vector_stats(col),
        np.array([(ra.mean()-rb.mean())/2047.,(ra.std()-rb.std())/2047.],np.float32)
    ])
    # bx is 45; deterministic projection down to 36 via fixed adjacent averages for compactness.
    if len(bx)>36:
        head=bx[:27]; tail=bx[27:]
        # 18 -> 9 averages
        tail=tail[:18].reshape(9,2).mean(1)
        bx=np.concatenate([head,tail])
    assert len(bx)==36,len(bx)
    return np.concatenate([one,cand,state,bx.astype(np.float32)])

def make_pair_train(df,X,F,use_bip=True):
    rows=[]; yy=[]
    for i,r in df.iterrows():
        if r.formal_status=='VERIFIED': continue
        gold=L2I[r.gold]
        for opp in range(4):
            if opp==gold: continue
            a,b=sorted((gold,opp)); target=1 if gold==b else 0
            rows.append(np.concatenate([X[i],pair_extra(r.q,F[i],a,b,use_bip)])); yy.append(target)
    return np.stack(rows).astype(np.float32),np.asarray(yy,int)

def pair_score(model,xbase,q,F,a,b,use_bip=True):
    aa,bb=sorted((a,b)); x=np.concatenate([xbase,pair_extra(q,F,aa,bb,use_bip)])[None,:]
    p=model.predict_proba(x)[0]
    # p[1]=probability the higher-index endpoint bb is the true member of the pair.
    winprob_b=float(p[1]);
    if winprob_b>=.5:
        return bb,winprob_b
    return aa,1-winprob_b

def exploration_bonus(q,cycle,hyp,verdict,margin):
    # Feedback-dependent BIP39 state ranks challengers only; bounded amplitude.
    pack=bip.route_pack(q,cycle,LABELS[hyp],verdict,margin)
    rows=pack['rows']
    bonus=np.array([(np.mean(row)/2047.-.5) for row in rows],float)
    return bonus,pack

def tournament(model,df,X,F,start,use_bip=True,switch_prob=.57,max_cycles=3,epsilon=.04):
    out=start.copy(); traces=[]
    for i,r in df.iterrows():
        if r.formal_status=='VERIFIED': traces.append([]); continue
        cur=int(out[i]); tested=set(); verdict='INIT'; margin=0.0; tr=[]
        for c in range(max_cycles):
            # Feedback BIP39 chooses exploration order, but evidence logits dominate.
            if use_bip:
                bonus,pack=exploration_bonus(r.q,c,cur,verdict,margin)
            else:
                bonus=np.zeros(4); pack={'route_id':-1,'route_kind':'NONE','sha256':None}
            candidates=[]
            for j in range(4):
                if j==cur: continue
                pair=tuple(sorted((cur,j)))
                if pair in tested: continue
                candidates.append(j)
            if not candidates: break
            challenger=max(candidates,key=lambda j: float(F[i,j] + epsilon*bonus[j]))
            pair=tuple(sorted((cur,challenger))); tested.add(pair)
            winner,winprob=pair_score(model,X[i],r.q,F[i],cur,challenger,use_bip)
            # pair_score returns the probability assigned to the predicted winner.
            before=cur
            if winner!=cur and winprob>=switch_prob:
                cur=winner; verdict='ACCEPT'; margin=winprob-switch_prob
            elif winner==cur:
                verdict='CONFIRM'; margin=winprob-.5
            else:
                verdict='REJECT'; margin=switch_prob-winprob
            tr.append({'cycle':c,'hypothesis_before':LABELS[before],'challenger':LABELS[challenger],
                       'test_pair':LABELS[pair[0]]+LABELS[pair[1]],'test_winner':LABELS[winner],
                       'winner_probability':float(winprob),'verdict':verdict,'hypothesis_after':LABELS[cur],
                       'feedback_sha256':pack.get('sha256'),'feedback_route_id':pack.get('route_id')})
        out[i]=cur; traces.append(tr)
    return out,traces

def eval_fold(train,test,use_bip=True,switch_prob=.57):
    router=g.fit_router(train); rel,indep,central,A=g.hist_stats(train)
    Xtr,Btr,Ftr,starttr,Xte,Bte,Fte,startte,base_model=one_shot_models(train,test,router,rel,indep,central,A)
    Ptr,ytr=make_pair_train(train,Xtr,Ftr,use_bip)
    pair=CatBoostClassifier(loss_function='Logloss',verbose=False,random_seed=731,
        iterations=140,depth=4,learning_rate=.045,l2_leaf_reg=8,random_strength=.5,border_count=48,
        class_weights=[1,1])
    pair.fit(Ptr,ytr)
    final,trace=tournament(pair,test,Xte,Fte,startte,use_bip,switch_prob)
    final=formal_override(test,final)
    y=np.array([L2I[x] for x in test.gold]); start=formal_override(test,startte)
    return float((start==y).mean()),float((final==y).mean()),int(np.sum((start!=y)&(final==y))),int(np.sum((start==y)&(final!=y)))

def run_cv():
    df=load_all_disclosed(); folds=[]
    for hold in sorted(df.block.unique()):
        tr=df[df.block!=hold].reset_index(drop=True); te=df[df.block==hold].reset_index(drop=True)
        no=eval_fold(tr,te,False); bp=eval_fold(tr,te,True)
        rec={'holdout':hold,'n':len(te),'r712_start':bp[0],'pair_no_bip':no[1],'pair_bip':bp[1],
             'bip_corrections':bp[2],'bip_regressions':bp[3]}; folds.append(rec); print(rec,flush=True)
    n=sum(x['n'] for x in folds)
    keys=['r712_start','pair_no_bip','pair_bip']
    weighted={k:sum(x[k]*x['n'] for x in folds)/n for k in keys}
    out={'folds':folds,'weighted':weighted,'switch_prob':.57,'pair_trees':140,'max_cycles':3,'epsilon':.04}
    (BASE/'R713_PAIRWISE_DEV_CV.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print('WEIGHTED',weighted)
if __name__=='__main__': run_cv()
