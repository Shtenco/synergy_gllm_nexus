from __future__ import annotations
import json, zipfile, io, os, sys, math, hashlib, random
from pathlib import Path
from collections import Counter, defaultdict
import numpy as np, pandas as pd
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from catboost import CatBoostClassifier, Pool
import torch
import torch.nn as nn

BASE=Path('/mnt/data')
TEACHERS=['ministral3_3b','phi4mini_3_8b','granite33_2b','qwen3_1_7b','gemma3_1b']
DOMAINS=['math','logic','cyber_causal','code','russian','mixed_reasoning','science','knowledge']
LABELS=list('ABCD')
L2I={x:i for i,x in enumerate(LABELS)}

R710SRC=BASE/'r710_src/NEXUS_R710_REAL_BLIND27_PROOF_FIRST_2026-08-21/FREEZE/source'
sys.path.insert(0,str(R710SRC))
from runtime_v2 import formal_pass

BLOCKS={
 'B22': BASE/'NEXUS_R75_REAL_MULTITEACHER_BLIND22_2026-08-20.zip',
 'B24': BASE/'NEXUS_R77_METATEACHER_REAL_BLIND24_2026-08-20.zip',
 'B25': BASE/'NEXUS_R78_TOP2_ARBITRATION_REAL_BLIND25_2026-08-20.zip',
 'B26': BASE/'NEXUS_R79_REAL_BLIND26_DUALNODE_2026-08-20.zip',
 'B27': BASE/'NEXUS_R710_REAL_BLIND27_PROOF_FIRST_2026-08-21.zip',
}
BENCH_PAT={
 'B22':'00_BLIND22_FROZEN.json','B24':'01_BLIND24_FROZEN_PRETTY.json','B25':'03_BLIND25_FROZEN.json',
 'B26':'BENCHMARKS/BLIND26_FROZEN.json','B27':'BENCHMARKS/BLIND27_FROZEN.json'}
RAW_PAT={b:{t:f'RAW_TEACHERS/blind{b[1:]}_{t}.json' for t in TEACHERS} for b in BLOCKS}

def find_member(z, suffix):
    ms=[n for n in z.namelist() if n.endswith(suffix)]
    if not ms: raise KeyError((suffix,z.namelist()[:10]))
    return ms[0]

def probs_from_lp(lp):
    vals=np.array([lp.get(a) if lp.get(a) is not None else -50. for a in LABELS],float)
    vals-=vals.max(); e=np.exp(vals); e/=max(e.sum(),1e-12)
    return e

def load_data():
    rows=[]
    for block,zp in BLOCKS.items():
        with zipfile.ZipFile(zp) as z:
            bench=json.loads(z.read(find_member(z,BENCH_PAT[block])))
            raw={}
            for t in TEACHERS:
                obj=json.loads(z.read(find_member(z,RAW_PAT[block][t])))
                raw[t]={r['id']:r for r in obj['rows']}
            for it in bench['items']:
                fp=formal_pass(it)
                rec={'block':block,'id':it['id'],'q':it['q'],'domain_true':it['domain'],'gold':it['answer'],
                     'formal_status':fp['status'],'formal_answer':fp['answer'],
                     'formal_kind':((fp.get('ir') or {}).get('kind') if fp.get('ir') else 'NONE'),
                     'formal_rule':((fp.get('ir') or {}).get('compiler_rule') if fp.get('ir') else 'NONE')}
                for t in TEACHERS:
                    rr=raw[t][it['id']]; rec[t+'_pred']=rr.get('pred')
                    p=probs_from_lp(rr.get('option_logprobs') or {})
                    for j,a in enumerate(LABELS): rec[f'{t}_p{a}']=float(p[j])
                rows.append(rec)
    return pd.DataFrame(rows)

HV=HashingVectorizer(analyzer='char_wb',ngram_range=(2,5),n_features=192,alternate_sign=False,norm='l2')

def fit_router(train):
    X=HV.transform(train.q)
    clf=LogisticRegression(max_iter=800,C=.75,class_weight='balanced',random_state=712)
    clf.fit(X,train.domain_true)
    return clf

def domain_post(clf, qseries):
    p=clf.predict_proba(HV.transform(qseries)); out=np.zeros((len(qseries),len(DOMAINS)))
    for j,c in enumerate(clf.classes_): out[:,DOMAINS.index(c)]=p[:,j]
    return out

def hist_stats(train):
    rel=np.zeros((len(DOMAINS),len(TEACHERS)))
    err=np.zeros((len(train),len(TEACHERS)))
    for ti,t in enumerate(TEACHERS):
        pred=train[t+'_pred'].values; gold=train.gold.values
        err[:,ti]=(pred!=gold).astype(float)
        for di,d in enumerate(DOMAINS):
            z=train.domain_true.values==d
            # beta shrink to global
            k=((pred[z]==gold[z])).sum(); n=z.sum(); rel[di,ti]=(k+2)/(n+4) if n else .5
    corr=np.corrcoef(err,rowvar=False); corr=np.nan_to_num(corr, nan=0.)
    indep=1-np.clip(corr,0,1); np.fill_diagonal(indep,1.)
    central=indep.mean(1)
    # normalized adjacency for diffusion: independence edges + self
    A=indep.copy(); A=A/(A.sum(1,keepdims=True)+1e-12)
    return rel,indep,central,A

def make_features(df, router, rel, indep, central, A):
    n=len(df); dp=domain_post(router,df.q)
    # lexical hashing dense, stable/no fit
    H=HV.transform(df.q).toarray().astype(np.float32)
    tprob=np.zeros((n,len(TEACHERS),4)); conf=np.zeros((n,len(TEACHERS)))
    for ti,t in enumerate(TEACHERS):
        for j,a in enumerate(LABELS): tprob[:,ti,j]=df[f'{t}_p{a}'].values
        conf[:,ti]=tprob[:,ti,:].max(1)
    # expected competence under predicted domain posterior; route is pre-response and confidence-free
    comp=dp@rel
    route=(np.clip(comp,1e-4,1)**.80)*(np.clip(central[None,:],1e-4,1)**.20)
    top2=np.argsort(-route,axis=1)[:,:2]
    mask=np.zeros_like(route)
    for i in range(n): mask[i,top2[i]]=1.0
    called=tprob*mask[:,:,None]
    w=route*mask*(np.clip(conf,1e-4,1)**.10)
    support=np.einsum('nt,ntc->nc',w,called)/(w.sum(1,keepdims=True)+1e-12)
    B=np.log(np.clip(support,1e-8,1))
    # graph diffusion features use only called organs; uncalled teacher evidence is exactly zero
    diff=[]
    for c in range(4):
        s=called[:,:,c]
        p1=s@A.T; p2=p1@A.T
        diff += [s,p1,p2]
    G=np.concatenate(diff,axis=1)
    agree=[]
    preds=np.argmax(tprob,2)
    for i in range(len(TEACHERS)):
        for j in range(i+1,len(TEACHERS)): agree.append((preds[:,i]==preds[:,j]).astype(float)[:,None])
    agree=np.concatenate(agree,axis=1)
    formal_verified=(df.formal_status.values=='VERIFIED').astype(float)[:,None]
    fa=np.zeros((n,4))
    for i,a in enumerate(df.formal_answer.values):
        if a in L2I: fa[i,L2I[a]]=1
    # lightweight structured lexical scalars
    qlen=np.array([len(x) for x in df.q],float)[:,None]/200
    numcnt=np.array([sum(ch.isdigit() for ch in x) for x in df.q],float)[:,None]/20
    X=np.concatenate([H,dp,called.reshape(n,-1),mask,comp,conf*mask,support,G,agree,formal_verified,fa,qlen,numcnt],axis=1).astype(np.float32)
    return X,B,{'domain_post':dp,'support':support,'weights':w,'mask':mask,'top2':top2}

class Absorber(nn.Module):
    def __init__(self,din,dh=64):
        super().__init__(); self.net=nn.Sequential(nn.Linear(din,dh),nn.GELU(),nn.LayerNorm(dh),nn.Linear(dh,4))
    def forward(self,x): return self.net(x)

def train_absorber(X,target,seed=712,epochs=180):
    torch.manual_seed(seed); m=Absorber(X.shape[1]); opt=torch.optim.AdamW(m.parameters(),lr=2e-3,weight_decay=1e-4)
    xx=torch.tensor(X); yy=torch.tensor(target,dtype=torch.float32)
    for _ in range(epochs):
        opt.zero_grad(); pred=m(xx); loss=((pred-yy)**2).mean(); loss.backward(); opt.step()
    return m.eval()

def raw_pred(model,X,B):
    pool=Pool(X,baseline=B)
    raw=np.asarray(model.predict(pool,prediction_type='RawFormulaVal'))
    return raw

def fit_eval(train,test,params,absorb_alpha=.55):
    router=fit_router(train); rel,indep,central,A=hist_stats(train)
    Xtr,Btr,_=make_features(train,router,rel,indep,central,A); Xte,Bte,_=make_features(test,router,rel,indep,central,A)
    ytr=np.array([L2I[x] for x in train.gold]); yte=np.array([L2I[x] for x in test.gold])
    unk_tr=train.formal_status.values!='VERIFIED'; unk_te=test.formal_status.values!='VERIFIED'
    # NEXUS graph baseline
    base=np.argmax(Bte,1)
    # plain boost control
    plain=CatBoostClassifier(loss_function='MultiClass',verbose=False,random_seed=712,**params)
    plain.fit(Xtr[unk_tr],ytr[unk_tr]); plain_pred=np.argmax(plain.predict_proba(Xte),1)
    # one-stage residual boost from NEXUS baseline
    cb1=CatBoostClassifier(loss_function='MultiClass',verbose=False,random_seed=713,**params)
    cb1.fit(Pool(Xtr[unk_tr],label=ytr[unk_tr],baseline=Btr[unk_tr]))
    raw1tr=raw_pred(cb1,Xtr[unk_tr],Btr[unk_tr]); delta1=raw1tr-Btr[unk_tr]
    raw1te=raw_pred(cb1,Xte,Bte); hyb1=np.argmax(raw1te,1)
    # absorb booster residual into a small NEXUS organ; next booster starts from absorbed state
    absorber=train_absorber(Xtr[unk_tr],delta1,seed=714)
    with torch.no_grad():
        atr=absorber(torch.tensor(Xtr)).numpy(); ate=absorber(torch.tensor(Xte)).numpy()
    B1tr=Btr+absorb_alpha*atr; B1te=Bte+absorb_alpha*ate
    cb2=CatBoostClassifier(loss_function='MultiClass',verbose=False,random_seed=715,**params)
    cb2.fit(Pool(Xtr[unk_tr],label=ytr[unk_tr],baseline=B1tr[unk_tr]))
    raw2te=raw_pred(cb2,Xte,B1te); bga=np.argmax(raw2te,1)
    # proof override for all systems using boosting
    formal_ans=np.array([L2I.get(x,-1) for x in test.formal_answer])
    def override(pred):
        out=pred.copy(); z=(test.formal_status.values=='VERIFIED')&(formal_ans>=0); out[z]=formal_ans[z]; return out
    base_o=override(base);plain_o=override(plain_pred);h1_o=override(hyb1);bga_o=override(bga)
    return {
      'n':len(test), 'formal':int((test.formal_status=='VERIFIED').sum()),
      'nexus_graph':float((base_o==yte).mean()), 'plain_catboost':float((plain_o==yte).mean()),
      'nexus_plus_gbdt':float((h1_o==yte).mean()), 'r712_bga':float((bga_o==yte).mean()),
      'unknown_r712':float((bga_o[unk_te]==yte[unk_te]).mean()) if unk_te.sum() else 1.0,
      'router_acc':float((router.predict(HV.transform(test.q))==test.domain_true).mean()),
    }, {'router':router,'rel':rel,'indep':indep,'central':central,'A':A,'cb1':cb1,'absorber':absorber,'cb2':cb2}

def main():
    df=load_data(); print('loaded',len(df),df.block.value_counts().to_dict(),'formal',df.formal_status.value_counts().to_dict())
    params={'iterations':120,'depth':4,'learning_rate':.055,'l2_leaf_reg':6,'random_strength':.4,'border_count':48}
    folds=[]
    for hold in sorted(df.block.unique()):
        train=df[df.block!=hold].reset_index(drop=True); test=df[df.block==hold].reset_index(drop=True)
        m,_=fit_eval(train,test,params)
        m['holdout']=hold; folds.append(m); print(hold,m)
    out={'params':params,'folds':folds,'mean':{k:float(np.mean([x[k] for x in folds])) for k in ['nexus_graph','plain_catboost','nexus_plus_gbdt','r712_bga','unknown_r712','router_acc']}}
    Path('/mnt/data/R712_DEV_CV.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    df.to_pickle('/mnt/data/R712_TRAIN_DATA.pkl')
    print(json.dumps(out['mean'],indent=2))
if __name__=='__main__': main()
