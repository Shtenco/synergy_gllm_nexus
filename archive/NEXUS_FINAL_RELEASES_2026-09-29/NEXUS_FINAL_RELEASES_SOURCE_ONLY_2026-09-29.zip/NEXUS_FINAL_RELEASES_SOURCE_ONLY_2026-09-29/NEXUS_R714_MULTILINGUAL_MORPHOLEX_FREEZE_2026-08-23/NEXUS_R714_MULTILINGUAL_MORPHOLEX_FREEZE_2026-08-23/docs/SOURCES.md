# SOURCES / DESIGN BASIS

1. Ethnologue, 28th Edition FAQ: top 10 most spoken languages by total speakers:
   English, Chinese (Mandarin), Hindi, Spanish, French, Arabic, Bengali, Portuguese, Russian, Urdu.
2. Universal Dependencies v2 universal feature ontology:
   PronType, NumType, Gender, Number, Case, Definite, Degree, VerbForm, Mood, Tense, Aspect, Voice, Polarity, Person, etc.
3. Unicode CLDR plural/grammatical feature model is used as a compatibility reference for language-sensitive number/plural behavior.

These sources define language selection and the shared grammatical coordinate system.
The concrete compact affix/operator rules in this release are an engineering layer and are intentionally precision-first rather than linguistically exhaustive.
