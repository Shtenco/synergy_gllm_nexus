import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'source'))
import morpholex_engine as m
T=json.loads((ROOT/'tests/gold_tests.json').read_text(encoding='utf-8'))
res={}; total=correct=0
for lang,items in T.items():
    c=0
    for text,kind,target in items:
        ir=m.analyze(text,lang)
        ok=False
        if kind=='op': ok=ir.operators.get(target,0)>0
        else:
            k,v=target; ok=any(tok.features.get(k)==v for tok in ir.tokens)
        c+=int(ok);correct+=int(ok);total+=1
    res[lang]={'correct':c,'n':len(items),'accuracy':c/len(items)}
print(json.dumps({'by_language':res,'correct':correct,'n':total,'accuracy':correct/total},ensure_ascii=False,indent=2))
