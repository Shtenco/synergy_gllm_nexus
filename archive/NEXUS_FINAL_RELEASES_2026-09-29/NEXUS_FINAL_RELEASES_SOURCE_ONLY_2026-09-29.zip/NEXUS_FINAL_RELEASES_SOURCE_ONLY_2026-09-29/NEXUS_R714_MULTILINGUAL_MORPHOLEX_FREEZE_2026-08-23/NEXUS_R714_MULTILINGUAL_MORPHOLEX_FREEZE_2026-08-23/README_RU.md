# NEXUS R7.14 — MULTILINGUAL MORPHOLEX RULE ENGINE

## Цель
Добавить к R7.13 отдельный нейро-символический языковой слой для 10 крупнейших языков по общему числу говорящих:
English, Mandarin Chinese, Hindi, Spanish, French, Arabic, Bengali, Portuguese, Russian, Urdu.

## Архитектура

Question
→ Language Detector
→ Morphological Rule Engine
→ Lexical Operator Engine
→ MorphoLexIR
→ canonical form
→ test constraints
→ Δ_language
→ R7.13 Hypothesis → Test → Hypothesis loop

R7.14 НЕ разрешает языковому слою напрямую голосовать за A/B/C/D.

## MorphoLexIR
Детерминированный state: 56 признаков:
- 16 lexical/logical operators: NEG, COND, CAUSE, EFFECT, AND, OR, quantifiers, modality, temporal order, comparison, contrast, evidence;
- 10 semantic fields;
- 12 UD-compatible grammatical axes: Gender, Number, Case, Tense, Aspect, Mood, Voice, Person, Polarity, Degree, Definite, VerbForm;
- surface/script statistics;
- language one-hot.

Дополнительно 16 вероятностей rule-distiller → total 72-d state.

## Rule distillation
Char-ngram logistic learner обучен воспроизводить lexical operator rules.
Samples: 3493
5-fold consistency CV: 96.450%.

Это НЕ внешний языковой benchmark. Это проверка того, что правила можно сжать в обучаемый statistical fallback.

## Deterministic tests
Rule-unit tests: 150/150 = 100.00%.
По 15 проверок на каждый из 10 языков.

Curated language detection: 10/10.

## Downstream ablation
Прямое добавление MorphoLex-features в старый pairwise answer classifier оказалось вредным:

R7.13: 93.750%
Direct MorphoLex: 93.429%
Corrections: 0
Regressions: 2

Поэтому до нового Blind-30 direct answer override отключён.

## Safe cybernetic role
MorphoLex анализирует вопрос до гипотезы и выдаёт типы тестов:
- NEG → POLARITY_TEST
- COND → CONDITIONAL_IMPLICATION_TEST
- CAUSE/EFFECT → CAUSAL_DIRECTION_TEST
- AND/OR → BOOLEAN_COMPOSITION_TEST
- quantifier → QUANTIFIER_SCOPE_TEST
- MUST/CAN → NECESSITY/POSSIBILITY_TEST
- BEFORE/AFTER → TEMPORAL_ORDER_TEST
- comparison → COMPARISON_TEST
- evidence → EVIDENCE_PROVENANCE_TEST

Каждый H→T step получает:
`language`, `canonical`, `morpholex_constraints`, `delta_language`.

## Научная граница
Это precision-first rule system, не полный морфологический анализатор десяти языков.
Китайский обрабатывается прежде всего через частицы/lexical operators.
Arabic root extraction — эвристический root candidate, не авторитетный лемматизатор.
Новые языковые правила должны проверяться на независимом corpus/Blind-30 до получения права менять финальный ответ.

Blind-30 НЕ существует на момент freeze.
