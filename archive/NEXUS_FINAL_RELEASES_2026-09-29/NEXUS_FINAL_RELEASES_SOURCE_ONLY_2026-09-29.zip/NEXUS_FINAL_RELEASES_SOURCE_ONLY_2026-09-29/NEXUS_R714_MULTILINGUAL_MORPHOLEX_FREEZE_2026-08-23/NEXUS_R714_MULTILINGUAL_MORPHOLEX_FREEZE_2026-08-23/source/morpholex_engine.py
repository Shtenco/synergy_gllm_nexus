from __future__ import annotations
import re, unicodedata, hashlib, json, math
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Tuple, Any
import numpy as np

TOP10 = [
    ('en','English','Latin'),('zh','Mandarin Chinese','Han'),('hi','Hindi','Devanagari'),
    ('es','Spanish','Latin'),('fr','French','Latin'),('ar','Standard Arabic','Arabic'),
    ('bn','Bengali','Bengali'),('pt','Portuguese','Latin'),('ru','Russian','Cyrillic'),('ur','Urdu','Arabic')
]
UD_KEYS=['Gender','Number','Case','Tense','Aspect','Mood','Voice','Person','Polarity','Degree','Definite','VerbForm']
OP_KEYS=['NEG','COND','CAUSE','EFFECT','AND','OR','QUANT_ALL','QUANT_SOME','MODAL_MUST','MODAL_CAN','TEMP_BEFORE','TEMP_AFTER','COMPARE_MORE','COMPARE_LESS','CONTRAST','EVIDENCE']
FIELD_KEYS=['CONTROL','CHANGE','RISK','SUPPORT','CONFLICT','RESOURCE','MOTION','STATE','UNCERTAINTY','PROOF']

LEX = {
'en':{
'NEG':['not','no','never','without'], 'COND':['if','unless','provided'], 'CAUSE':['because','since','causes','cause'], 'EFFECT':['therefore','thus','hence','so'], 'AND':['and','both'], 'OR':['or','either'], 'QUANT_ALL':['all','every','each'], 'QUANT_SOME':['some','any','several'], 'MODAL_MUST':['must','should','need'], 'MODAL_CAN':['can','could','may'], 'TEMP_BEFORE':['before','earlier','prior'], 'TEMP_AFTER':['after','later','then'], 'COMPARE_MORE':['more','greater','higher'], 'COMPARE_LESS':['less','lower','fewer'], 'CONTRAST':['but','however','although'], 'EVIDENCE':['evidence','proof','verify','test']},
'zh':{
'NEG':['不','没','没有','无'], 'COND':['如果','若','除非'], 'CAUSE':['因为','由于','导致'], 'EFFECT':['所以','因此','于是'], 'AND':['和','与','并且'], 'OR':['或','或者'], 'QUANT_ALL':['所有','每','全部'], 'QUANT_SOME':['一些','有些'], 'MODAL_MUST':['必须','应该','需要'], 'MODAL_CAN':['可以','能','可能'], 'TEMP_BEFORE':['之前','以前'], 'TEMP_AFTER':['之后','以后','然后'], 'COMPARE_MORE':['更多','更高','更大'], 'COMPARE_LESS':['更少','更低','更小'], 'CONTRAST':['但是','然而','虽然'], 'EVIDENCE':['证据','证明','验证','测试']},
'hi':{
'NEG':['नहीं','न','मत','बिना'], 'COND':['अगर','यदि','जबकि'], 'CAUSE':['क्योंकि','कारण','से'], 'EFFECT':['इसलिए','अतः','तो'], 'AND':['और','तथा'], 'OR':['या','अथवा'], 'QUANT_ALL':['सभी','हर','प्रत्येक'], 'QUANT_SOME':['कुछ','कई'], 'MODAL_MUST':['चाहिए','ज़रूरी','अवश्य'], 'MODAL_CAN':['सकता','सकती','सकते','संभव'], 'TEMP_BEFORE':['पहले','पूर्व'], 'TEMP_AFTER':['बाद','फिर'], 'COMPARE_MORE':['अधिक','ज्यादा','ऊँचा'], 'COMPARE_LESS':['कम','नीचा'], 'CONTRAST':['लेकिन','परंतु','हालाँकि'], 'EVIDENCE':['सबूत','प्रमाण','जाँच','परीक्षण']},
'es':{
'NEG':['no','nunca','sin'], 'COND':['si','salvo','a menos'], 'CAUSE':['porque','causa','debido'], 'EFFECT':['por tanto','entonces','así'], 'AND':['y','ambos'], 'OR':['o','sea'], 'QUANT_ALL':['todo','todos','cada'], 'QUANT_SOME':['algunos','algún','varios'], 'MODAL_MUST':['debe','deber','necesita'], 'MODAL_CAN':['puede','podría','posible'], 'TEMP_BEFORE':['antes','previo'], 'TEMP_AFTER':['después','luego'], 'COMPARE_MORE':['más','mayor','superior'], 'COMPARE_LESS':['menos','menor','inferior'], 'CONTRAST':['pero','sin embargo','aunque'], 'EVIDENCE':['evidencia','prueba','verificar','test']},
'fr':{
'NEG':['ne','pas','jamais','sans'], 'COND':['si','sauf','à moins'], 'CAUSE':['parce','car','cause','puisque'], 'EFFECT':['donc','ainsi','alors'], 'AND':['et','tous deux'], 'OR':['ou','soit'], 'QUANT_ALL':['tout','tous','chaque'], 'QUANT_SOME':['quelques','certains','plusieurs'], 'MODAL_MUST':['doit','devoir','nécessaire'], 'MODAL_CAN':['peut','pourrait','possible'], 'TEMP_BEFORE':['avant','précédent'], 'TEMP_AFTER':['après','ensuite'], 'COMPARE_MORE':['plus','supérieur','davantage'], 'COMPARE_LESS':['moins','inférieur'], 'CONTRAST':['mais','cependant','bien que'], 'EVIDENCE':['preuve','évidence','vérifier','test']},
'ar':{
'NEG':['لا','ليس','لم','لن','بدون'], 'COND':['إذا','إن','لو','إلا'], 'CAUSE':['لأن','بسبب','سبب'], 'EFFECT':['لذلك','إذن','وبالتالي'], 'AND':['و','كذلك'], 'OR':['أو','إما'], 'QUANT_ALL':['كل','جميع'], 'QUANT_SOME':['بعض','عدة'], 'MODAL_MUST':['يجب','لازم','ينبغي'], 'MODAL_CAN':['يمكن','قد','ممكن'], 'TEMP_BEFORE':['قبل','سابقا'], 'TEMP_AFTER':['بعد','ثم'], 'COMPARE_MORE':['أكثر','أكبر','أعلى'], 'COMPARE_LESS':['أقل','أصغر','أدنى'], 'CONTRAST':['لكن','ومع ذلك','رغم'], 'EVIDENCE':['دليل','إثبات','تحقق','اختبار']},
'bn':{
'NEG':['না','নয়','নেই','ছাড়া'], 'COND':['যদি','যতক্ষণ','ছাড়া'], 'CAUSE':['কারণ','কারণে','যেহেতু'], 'EFFECT':['তাই','সুতরাং','ফলে'], 'AND':['এবং','ও'], 'OR':['অথবা','বা'], 'QUANT_ALL':['সব','সকল','প্রত্যেক'], 'QUANT_SOME':['কিছু','কয়েক'], 'MODAL_MUST':['অবশ্যই','উচিত','দরকার'], 'MODAL_CAN':['পারে','সম্ভব'], 'TEMP_BEFORE':['আগে','পূর্বে'], 'TEMP_AFTER':['পরে','তারপর'], 'COMPARE_MORE':['বেশি','উচ্চতর'], 'COMPARE_LESS':['কম','নিম্নতর'], 'CONTRAST':['কিন্তু','তবে','যদিও'], 'EVIDENCE':['প্রমাণ','যাচাই','পরীক্ষা']},
'pt':{
'NEG':['não','nunca','sem'], 'COND':['se','salvo','a menos'], 'CAUSE':['porque','causa','devido'], 'EFFECT':['portanto','então','assim'], 'AND':['e','ambos'], 'OR':['ou'], 'QUANT_ALL':['todo','todos','cada'], 'QUANT_SOME':['alguns','algum','vários'], 'MODAL_MUST':['deve','dever','precisa'], 'MODAL_CAN':['pode','poderia','possível'], 'TEMP_BEFORE':['antes','prévio'], 'TEMP_AFTER':['depois','então'], 'COMPARE_MORE':['mais','maior','superior'], 'COMPARE_LESS':['menos','menor','inferior'], 'CONTRAST':['mas','porém','embora'], 'EVIDENCE':['evidência','prova','verificar','teste']},
'ru':{
'NEG':['не','нет','никогда','без'], 'COND':['если','если бы','кроме'], 'CAUSE':['потому','поскольку','причина','из-за'], 'EFFECT':['поэтому','следовательно','значит'], 'AND':['и','также'], 'OR':['или','либо'], 'QUANT_ALL':['все','каждый','любой'], 'QUANT_SOME':['некоторые','несколько','часть'], 'MODAL_MUST':['должен','должна','нужно','необходимо'], 'MODAL_CAN':['может','можно','возможно'], 'TEMP_BEFORE':['до','раньше','перед'], 'TEMP_AFTER':['после','потом','затем'], 'COMPARE_MORE':['больше','выше','сильнее'], 'COMPARE_LESS':['меньше','ниже','слабее'], 'CONTRAST':['но','однако','хотя'], 'EVIDENCE':['доказательство','свидетельство','проверить','тест']},
'ur':{
'NEG':['نہیں','نہ','مت','بغیر'], 'COND':['اگر','جب','سوائے'], 'CAUSE':['کیونکہ','وجہ','سبب'], 'EFFECT':['اس لیے','لہذا','تو'], 'AND':['اور','نیز'], 'OR':['یا'], 'QUANT_ALL':['سب','ہر','تمام'], 'QUANT_SOME':['کچھ','کئی'], 'MODAL_MUST':['چاہیے','ضروری','لازم'], 'MODAL_CAN':['سکتا','سکتی','سکتے','ممکن'], 'TEMP_BEFORE':['پہلے','قبل'], 'TEMP_AFTER':['بعد','پھر'], 'COMPARE_MORE':['زیادہ','اونچا','بڑا'], 'COMPARE_LESS':['کم','نیچا','چھوٹا'], 'CONTRAST':['لیکن','مگر','اگرچہ'], 'EVIDENCE':['ثبوت','دلیل','جانچ','ٹیسٹ']}
}

FIELDS={
'en':{'CONTROL':['control','govern','manage'],'CHANGE':['change','transform','shift'],'RISK':['risk','danger','threat'],'SUPPORT':['support','help','assist'],'CONFLICT':['conflict','fight','oppose'],'RESOURCE':['resource','capital','energy'],'MOTION':['move','transfer','route'],'STATE':['state','status','condition'],'UNCERTAINTY':['uncertain','maybe','unknown'],'PROOF':['proof','verify','evidence']},
'ru':{'CONTROL':['контроль','управление','управлять'],'CHANGE':['изменение','менять','переход'],'RISK':['риск','опасность','угроза'],'SUPPORT':['поддержка','помощь','помочь'],'CONFLICT':['конфликт','борьба','против'],'RESOURCE':['ресурс','капитал','энергия'],'MOTION':['движение','перевод','маршрут'],'STATE':['состояние','статус','условие'],'UNCERTAINTY':['неизвестно','возможно','неопределенность'],'PROOF':['доказательство','проверка','свидетельство']}
}
# Other languages inherit translated high-value operator lexicon but field semantics default to zeros.

EN_NO_SUFFIX={'is','was','has','does','this','his','yes','us','as','news'}

IRREG_EN={'went':('go',{'Tense':'Past'}),'gone':('go',{'Tense':'Past','VerbForm':'Part'}),'better':('good',{'Degree':'Cmp'}),'best':('good',{'Degree':'Sup'}),'children':('child',{'Number':'Plur'}),'men':('man',{'Number':'Plur'}),'women':('woman',{'Number':'Plur'})}

SUFFIX={
'en':[('ies',{'Number':'Plur'}),('s',{'Number':'Plur'}),('ed',{'Tense':'Past'}),('ing',{'Aspect':'Prog','VerbForm':'Part'}),('er',{'Degree':'Cmp'}),('est',{'Degree':'Sup'})],
'es':[('mente',{'VerbForm':'Adv'}),('ando',{'Aspect':'Prog','VerbForm':'Ger'}),('iendo',{'Aspect':'Prog','VerbForm':'Ger'}),('aron',{'Tense':'Past','Number':'Plur'}),('aba',{'Tense':'Past'}),('as',{'Number':'Plur'}),('os',{'Number':'Plur','Gender':'Masc'}),('es',{'Number':'Plur'}),('a',{'Gender':'Fem'}),('o',{'Gender':'Masc'})],
'fr':[('aient',{'Tense':'Past','Number':'Plur'}),('ant',{'VerbForm':'Part'}),('ées',{'Number':'Plur','Gender':'Fem'}),('és',{'Number':'Plur','Gender':'Masc'}),('es',{'Number':'Plur'}),('s',{'Number':'Plur'}),('e',{'Gender':'Fem'})],
'pt':[('mente',{'VerbForm':'Adv'}),('ando',{'Aspect':'Prog','VerbForm':'Ger'}),('endo',{'Aspect':'Prog','VerbForm':'Ger'}),('aram',{'Tense':'Past','Number':'Plur'}),('as',{'Number':'Plur','Gender':'Fem'}),('os',{'Number':'Plur','Gender':'Masc'}),('es',{'Number':'Plur'}),('a',{'Gender':'Fem'}),('o',{'Gender':'Masc'})],
'ru':[('иями',{'Number':'Plur','Case':'Ins'}),('ами',{'Number':'Plur','Case':'Ins'}),('ями',{'Number':'Plur','Case':'Ins'}),('ого',{'Case':'Gen','Gender':'Masc'}),('ему',{'Case':'Dat','Gender':'Masc'}),('ами',{'Number':'Plur','Case':'Ins'}),('ах',{'Number':'Plur','Case':'Loc'}),('ях',{'Number':'Plur','Case':'Loc'}),('ов',{'Number':'Plur','Case':'Gen'}),('ей',{'Case':'Gen'}),('ом',{'Case':'Ins'}),('ет',{'Tense':'Pres','Person':'3'}),('ют',{'Tense':'Pres','Person':'3','Number':'Plur'}),('л',{'Tense':'Past'})],
'hi':[('ों',{'Number':'Plur','Case':'Obl'}),('ें',{'Number':'Plur'}),('ा',{'Gender':'Masc'}),('ी',{'Gender':'Fem'}),('ता',{'Aspect':'Hab','Gender':'Masc'}),('ती',{'Aspect':'Hab','Gender':'Fem'}),('ते',{'Aspect':'Hab','Number':'Plur'})],
'bn':[('গুলো',{'Number':'Plur'}),('গুলি',{'Number':'Plur'}),('দের',{'Number':'Plur','Case':'Gen'}),('কে',{'Case':'Acc'}),('তে',{'Case':'Loc'}),('ের',{'Case':'Gen'}),('ছিল',{'Tense':'Past'}),('বে',{'Tense':'Fut'})],
'ur':[('وں',{'Number':'Plur','Case':'Obl'}),('یں',{'Number':'Plur'}),('ا',{'Gender':'Masc'}),('ی',{'Gender':'Fem'}),('تا',{'Aspect':'Hab','Gender':'Masc'}),('تی',{'Aspect':'Hab','Gender':'Fem'}),('تے',{'Aspect':'Hab','Number':'Plur'})],
'ar':[('ون',{'Number':'Plur','Gender':'Masc'}),('ين',{'Number':'Plur','Gender':'Masc'}),('ات',{'Number':'Plur','Gender':'Fem'}),('ان',{'Number':'Dual'}),('ين',{'Number':'Dual'}),('ة',{'Gender':'Fem'})]
}
PREFIX={'ar':[('ال',{'Definite':'Def'}),('و',{}),('ف',{}),('ب',{}),('ك',{}),('ل',{})], 'en':[('un',{'Polarity':'Neg'}),('non',{'Polarity':'Neg'})], 'ru':[('не',{'Polarity':'Neg'})]}

ZH_PARTICLES={'了':{'Aspect':'Perf'},'过':{'Aspect':'Perf'},'着':{'Aspect':'Prog'},'们':{'Number':'Plur'},'更':{'Degree':'Cmp'},'最':{'Degree':'Sup'},'被':{'Voice':'Pass'},'会':{'Mood':'Pot'}}

def strip_diacritics(s:str)->str:
    # Preserve Arabic/Indic base characters, remove combining marks only.
    return ''.join(c for c in unicodedata.normalize('NFKD',s) if unicodedata.category(c)!='Mn')

def normalize(s:str)->str:
    return unicodedata.normalize('NFKC',s).casefold().strip()

def tokenize(text:str)->List[str]:
    # Unicode word tokenizer plus Han runs.
    return re.findall(r"[\w\u0600-\u06FF\u0900-\u097F\u0980-\u09FF\u4E00-\u9FFFÀ-ÖØ-öø-ÿ]+(?:['’][\w]+)?", normalize(text), flags=re.UNICODE)

def script_counts(text:str)->Dict[str,int]:
    out={'Latin':0,'Cyrillic':0,'Arabic':0,'Devanagari':0,'Bengali':0,'Han':0}
    for ch in text:
        o=ord(ch)
        if 0x4E00<=o<=0x9FFF: out['Han']+=1
        elif 0x0400<=o<=0x052F: out['Cyrillic']+=1
        elif 0x0600<=o<=0x06FF: out['Arabic']+=1
        elif 0x0900<=o<=0x097F: out['Devanagari']+=1
        elif 0x0980<=o<=0x09FF: out['Bengali']+=1
        elif ('LATIN' in unicodedata.name(ch,'')): out['Latin']+=1
    return out

def _lex_hits(text:str,lang:str)->Dict[str,int]:
    n=normalize(text); toks=set(tokenize(n)); hits={k:0 for k in OP_KEYS}
    for op,words in LEX[lang].items():
        for w in words:
            if (' ' in w and w in n) or (w in toks) or (lang=='zh' and w in n): hits[op]+=1
    return hits

def detect_language(text:str)->Tuple[str,Dict[str,float]]:
    sc=script_counts(text); scores={c:0.0 for c,_,_ in TOP10}
    # script priors
    scores['zh']+=4*sc['Han']; scores['ru']+=4*sc['Cyrillic']; scores['hi']+=4*sc['Devanagari']; scores['bn']+=4*sc['Bengali']
    scores['ar']+=2.3*sc['Arabic']; scores['ur']+=2.3*sc['Arabic']
    for c in ['en','es','fr','pt']: scores[c]+=0.35*sc['Latin']
    for lang in scores:
        hits=_lex_hits(text,lang); scores[lang]+=5*sum(hits.values())
    # tie breakers for Arabic vs Urdu and Romance vs English.
    n=normalize(text)
    if any(x in n for x in ['ہے','ہیں','کا','کی','کے','اور','نہیں']): scores['ur']+=18
    if any(x in n for x in ['ال','لأن','ليس','هذا','هذه','يجب']): scores['ar']+=12
    if any(x in n for x in [' que ',' los ',' las ',' porque ',' más ']): scores['es']+=8
    if any(x in n for x in [' le ',' les ',' des ',' parce ',' plus ']): scores['fr']+=8
    if any(x in n for x in [' não ',' porque ',' mais ',' os ',' uma ']): scores['pt']+=8
    if any(x in n for x in [' the ',' and ',' if ',' because ',' not ']): scores['en']+=8
    lang=max(scores,key=scores.get)
    total=sum(max(0,v) for v in scores.values()) or 1.0
    return lang,{k:float(v/total) for k,v in scores.items()}

@dataclass
class TokenIR:
    surface:str
    lemma:str
    features:Dict[str,str]=field(default_factory=dict)
    operators:List[str]=field(default_factory=list)
    root:str|None=None
    confidence:float=0.6

@dataclass
class MorphoLexIR:
    language:str
    language_scores:Dict[str,float]
    tokens:List[TokenIR]
    operators:Dict[str,int]
    fields:Dict[str,int]
    canonical:str
    feature_vector:List[float]

class RuleEngine:
    def __init__(self,lang:str): self.lang=lang
    def analyze_token(self,tok:str)->TokenIR:
        w=normalize(tok); feats={}; lemma=w; root=None; conf=.60
        if self.lang=='en' and w in IRREG_EN:
            lemma,ff=IRREG_EN[w]; feats.update(ff); conf=.98
        if self.lang=='zh':
            for p,ff in ZH_PARTICLES.items():
                if p in w: feats.update(ff); conf=max(conf,.9)
        ops=[]
        for op,words in LEX[self.lang].items():
            if w in words or (self.lang=='zh' and any(x in w for x in words)): ops.append(op)
        # prefixes
        for pre,ff in sorted(PREFIX.get(self.lang,[]),key=lambda x:-len(x[0])):
            if len(w)>len(pre)+2 and w.startswith(pre):
                feats.update(ff); lemma=w[len(pre):] if ff else lemma; conf=max(conf,.72); break
        # suffixes: longest first; conservative and precision-first.
        # Function/operator tokens are not inflected by naive suffix rules.
        allow_suffix = not ops and not (self.lang=='en' and w in EN_NO_SUFFIX)
        for suf,ff in sorted(SUFFIX.get(self.lang,[]),key=lambda x:-len(x[0])):
            if allow_suffix and len(w)>len(suf)+1 and w.endswith(suf):
                feats.update(ff); conf=max(conf,.78)
                if self.lang in ['en','es','fr','pt'] and len(suf)>=1:
                    stem=w[:-len(suf)]
                    if len(stem)>=2: lemma=stem
                elif self.lang in ['ru','hi','bn','ur']:
                    stem=w[:-len(suf)]
                    if len(stem)>=2: lemma=stem
                break
        if self.lang=='ar':
            # Approximate consonantal root candidate, never treated as authoritative lemma.
            bare=strip_diacritics(w)
            for pre in ['وال','فال','بال','كال','لل','ال']:
                if bare.startswith(pre) and len(bare)>len(pre)+2: bare=bare[len(pre):]; break
            for suf in ['ون','ين','ات','ان','ة','ه','ها','هم','كم','نا']:
                if bare.endswith(suf) and len(bare)>len(suf)+2: bare=bare[:-len(suf)]; break
            consonants=[c for c in bare if '\u0621'<=c<='\u064A']
            if len(consonants)>=3: root=''.join(consonants[:3]); conf=max(conf,.68)
        return TokenIR(tok,lemma,feats,ops,root,conf)

    def analyze(self,text:str)->MorphoLexIR:
        lang_scores={}
        tokens=tokenize(text)
        tir=[self.analyze_token(t) for t in tokens]
        hits=_lex_hits(text,self.lang)
        fields={k:0 for k in FIELD_KEYS}
        for field,words in FIELDS.get(self.lang,{}).items():
            n=normalize(text); ts=set(tokenize(n))
            fields[field]=sum(1 for w in words if w in ts or w in n)
        # Canonical form is stable under many inflections and makes reasoning traces explicit.
        canon=[]
        for x in tir:
            tag='|'.join(f'{k}={v}' for k,v in sorted(x.features.items()))
            op='|'.join(x.operators)
            canon.append(x.lemma + (f'<{tag}>' if tag else '') + (f'[{op}]' if op else ''))
        vec=[]
        # 16 lexical operators
        vec.extend([float(hits[k]) for k in OP_KEYS])
        # 10 semantic fields
        vec.extend([float(fields[k]) for k in FIELD_KEYS])
        # 12 UD feature presence rates
        den=max(1,len(tir))
        for k in UD_KEYS: vec.append(sum(k in x.features for x in tir)/den)
        # surface statistics and script mixture
        vec.extend([len(tir)/32.0, sum(len(x.surface) for x in tir)/max(1,len(tir))/16.0])
        for s in ['Latin','Cyrillic','Arabic','Devanagari','Bengali','Han']:
            vec.append(script_counts(text)[s]/max(1,sum(script_counts(text).values())))
        # language one-hot = 10
        vec.extend([1.0 if c==self.lang else 0.0 for c,_,_ in TOP10])
        assert len(vec)==56,len(vec)
        return MorphoLexIR(self.lang,lang_scores,tir,hits,fields,' '.join(canon),vec)

def analyze(text:str,lang:str|None=None)->MorphoLexIR:
    if lang is None:
        lang,scores=detect_language(' '+text+' ')
    else:
        scores={c:(1.0 if c==lang else 0.0) for c,_,_ in TOP10}
    ir=RuleEngine(lang).analyze(text); ir.language_scores=scores; return ir

def feature_vector(text:str,lang:str|None=None)->np.ndarray:
    return np.asarray(analyze(text,lang).feature_vector,dtype=np.float32)

def canonicalize(text:str,lang:str|None=None)->str:
    return analyze(text,lang).canonical
