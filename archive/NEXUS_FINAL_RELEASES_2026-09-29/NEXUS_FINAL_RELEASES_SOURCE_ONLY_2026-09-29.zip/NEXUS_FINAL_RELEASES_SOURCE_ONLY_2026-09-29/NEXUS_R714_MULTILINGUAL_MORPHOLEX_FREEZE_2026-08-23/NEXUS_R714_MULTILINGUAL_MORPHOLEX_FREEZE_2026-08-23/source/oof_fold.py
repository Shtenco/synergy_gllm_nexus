from __future__ import annotations
import sys,json,argparse
from pathlib import Path
import numpy as np
from catboost import CatBoostClassifier
BASE=Path('/mnt/data')
sys.path.insert(0,str(BASE/'r713_dev'))
import pairwise_cyber_training as pc
import cyberloop_training as cy
import bip39_cyber_layer as bip
sys.path.insert(0,str(BASE/'r714_dev/source'))
import morpholex_layer as ml

g=pc.g; LABELS=g.LABELS; L2I=g.L2I

def mlvec(q): return ml.feature_vector(q)
def canonq(q): return ml.canonicalize(q)

def pair_extra_ml(q,F,a,b,use_bip=True):
    return np.concatenate([pc.pair_extra(q,F,a,b,use_bip),mlvec(q)]).astype(np.float32)

def make_pair_train_ml(df,X,F,use_bip=True):
    rows=[]; yy=[]
    for i,r in df.iterrows():
        if r.formal_status=='VERIFIED': continue
        gold=L2I[r.gold]
        for opp in range(4):
            if opp==gold: continue
            a,b=sorted((gold,opp)); target=1 if gold==b else 0
            rows.append(np.concatenate([X[i],pair_extra_ml(r.q,F[i],a,b,use_bip)])); yy.append(target)
    return np.stack(rows).astype(np.float32),np.asarray(yy,int)

def pair_score_ml(model,xbase,q,F,a,b,use_bip=True):
    aa,bb=sorted((a,b)); x=np.concatenate([xbase,pair_extra_ml(q,F,aa,bb,use_bip)])[None,:]
    p=model.predict_proba(x)[0]; pb=float(p[1])
    return (bb,pb) if pb>=.5 else (aa,1-pb)

def exploration_bonus_ml(q,cycle,hyp,verdict,margin):
    cq=canonq(q)
    pack=bip.route_pack(q+' || MORPHOLEX='+cq,cycle,LABELS[hyp],verdict,margin)
    bonus=np.array([(np.mean(row)/2047.-.5) for row in pack['rows']],float)
    return bonus,pack

def tournament_ml(model,df,X,F,start,use_bip=True,switch_prob=.57,max_cycles=3,epsilon=.04):
    out=start.copy(); traces=[]
    for i,r in df.iterrows():
        if r.formal_status=='VERIFIED': traces.append([]); continue
        cur=int(out[i]); tested=set(); verdict='INIT'; margin=0.0; tr=[]
        for c in range(max_cycles):
            if use_bip: bonus,pack=exploration_bonus_ml(r.q,c,cur,verdict,margin)
            else: bonus=np.zeros(4);pack={'route_id':-1,'sha256':None}
            candidates=[j for j in range(4) if j!=cur and tuple(sorted((cur,j))) not in tested]
            if not candidates: break
            challenger=max(candidates,key=lambda j:float(F[i,j]+epsilon*bonus[j]))
            pair=tuple(sorted((cur,challenger)));tested.add(pair)
            winner,winprob=pair_score_ml(model,X[i],r.q,F[i],cur,challenger,use_bip)
            before=cur
            if winner!=cur and winprob>=switch_prob:
                cur=winner;verdict='ACCEPT';margin=winprob-switch_prob
            elif winner==cur:
                verdict='CONFIRM';margin=winprob-.5
            else:
                verdict='REJECT';margin=switch_prob-winprob
            tr.append({'cycle':c,'before':LABELS[before],'challenger':LABELS[challenger],'winner':LABELS[winner],'p':float(winprob),'verdict':verdict,'after':LABELS[cur],'morph_language':ml.analyze(r.q)[0].language,'canonical':canonq(r.q)[:240],'feedback_sha256':pack.get('sha256')})
        out[i]=cur;traces.append(tr)
    return out,traces

def main(hold):
    df=cy.load_all_disclosed();tr=df[df.block!=hold].reset_index(drop=True);te=df[df.block==hold].reset_index(drop=True)
    router=g.fit_router(tr);rel,indep,central,A=g.hist_stats(tr)
    Xtr,Btr,Ftr,starttr,Xte,Bte,Fte,startte,base=pc.one_shot_models(tr,te,router,rel,indep,central,A)
    # baseline R7.13 exact mechanism
    P0,y0=pc.make_pair_train(tr,Xtr,Ftr,True)
    m0=CatBoostClassifier(loss_function='Logloss',verbose=False,random_seed=731,iterations=140,depth=4,learning_rate=.045,l2_leaf_reg=8,random_strength=.5,border_count=48,class_weights=[1,1]);m0.fit(P0,y0)
    p0,_=pc.tournament(m0,te,Xte,Fte,startte,True,.57,3,.04);p0=cy.formal_override(te,p0)
    # morpholex R7.14 candidate
    P1,y1=make_pair_train_ml(tr,Xtr,Ftr,True)
    m1=CatBoostClassifier(loss_function='Logloss',verbose=False,random_seed=714,iterations=140,depth=4,learning_rate=.045,l2_leaf_reg=8,random_strength=.5,border_count=48,class_weights=[1,1]);m1.fit(P1,y1)
    p1,trace=tournament_ml(m1,te,Xte,Fte,startte,True,.57,3,.04);p1=cy.formal_override(te,p1)
    y=np.array([L2I[x] for x in te.gold])
    rec={'holdout':hold,'n':len(te),'r713':float((p0==y).mean()),'r714':float((p1==y).mean()),
         'r714_corrections':int(np.sum((p0!=y)&(p1==y))),'r714_regressions':int(np.sum((p0==y)&(p1!=y)))}
    out=BASE/'r714_dev/oof';out.mkdir(exist_ok=True)
    (out/f'{hold}.json').write_text(json.dumps(rec,indent=2),encoding='utf-8')
    print(json.dumps(rec,indent=2))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('hold');a=ap.parse_args();main(a.hold)
