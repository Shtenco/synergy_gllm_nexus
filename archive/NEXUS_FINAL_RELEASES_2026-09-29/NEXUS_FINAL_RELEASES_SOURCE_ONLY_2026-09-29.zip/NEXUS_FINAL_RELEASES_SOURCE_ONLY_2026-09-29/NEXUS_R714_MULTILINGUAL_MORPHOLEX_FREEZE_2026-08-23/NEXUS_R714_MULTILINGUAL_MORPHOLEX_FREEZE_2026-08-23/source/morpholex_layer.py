from pathlib import Path
import sys,joblib,numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'source'))
import morpholex_engine as rules
MODEL=joblib.load(ROOT/'models_morpholex_distiller.joblib')
CLASSES=list(MODEL.named_steps['clf'].classes_)

def analyze(text,lang=None):
    ir=rules.analyze(text,lang)
    prefix=f'[{ir.language}] '
    p=MODEL.predict_proba([prefix+text])[0]
    learned={c:float(v) for c,v in zip(CLASSES,p) if c!='NONE'}
    # Rules are authoritative; distiller is only a probabilistic additional state.
    return ir,learned

def feature_vector(text,lang=None):
    ir,learned=analyze(text,lang)
    lp=np.array([learned.get(k,0.0) for k in rules.OP_KEYS],dtype=np.float32)
    return np.concatenate([np.asarray(ir.feature_vector,dtype=np.float32),lp])

def canonicalize(text,lang=None):
    ir,_=analyze(text,lang); return ir.canonical
