from __future__ import annotations
from pathlib import Path
import sys, math, numpy as np
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'base_r713'
sys.path.insert(0,str(BASE/'source'))
import runtime_r713 as r713
sys.path.insert(0,str(ROOT/'source'))
import morpholex_layer as ml
import morpholex_engine as rules

R714_POLICY={
 'answer_authority':'R7.13 sovereign answer remains authoritative',
 'morpholex_role':['language detection','canonicalization','morphological IR','lexical logical operators','test constraints','delta_language'],
 'direct_answer_override':False,
 'reason':'OOF direct integration on disclosed B22-B28 caused 0 corrections and 2 regressions; unsafe override disabled before freeze'
}

def _constraints(ir):
    o=ir.operators; c=[]
    if o.get('NEG',0): c.append('POLARITY_TEST')
    if o.get('COND',0): c.append('CONDITIONAL_IMPLICATION_TEST')
    if o.get('CAUSE',0) or o.get('EFFECT',0): c.append('CAUSAL_DIRECTION_TEST')
    if o.get('AND',0) or o.get('OR',0): c.append('BOOLEAN_COMPOSITION_TEST')
    if o.get('QUANT_ALL',0) or o.get('QUANT_SOME',0): c.append('QUANTIFIER_SCOPE_TEST')
    if o.get('MODAL_MUST',0): c.append('NECESSITY_TEST')
    if o.get('MODAL_CAN',0): c.append('POSSIBILITY_TEST')
    if o.get('TEMP_BEFORE',0) or o.get('TEMP_AFTER',0): c.append('TEMPORAL_ORDER_TEST')
    if o.get('COMPARE_MORE',0) or o.get('COMPARE_LESS',0): c.append('COMPARISON_TEST')
    if o.get('CONTRAST',0): c.append('CONTRAST_SCOPE_TEST')
    if o.get('EVIDENCE',0): c.append('EVIDENCE_PROVENANCE_TEST')
    return c

def _delta_language(ir,learned):
    scores=ir.language_scores or {}; vals=sorted(scores.values(),reverse=True)
    top=vals[0] if vals else 0.; second=vals[1] if len(vals)>1 else 0.
    n=max(1,len(ir.tokens)); morph=sum(len(t.features) for t in ir.tokens)/n
    rule_ops={k:v for k,v in ir.operators.items() if v>0}
    learned_top=max(learned.items(),key=lambda kv:kv[1]) if learned else ('NONE',0.)
    disagreement=(learned_top[0] not in rule_ops and learned_top[1]>=.55)
    return {
      'language_uncertainty':float(1-top),
      'language_margin':float(top-second),
      'morph_feature_density':float(morph),
      'rule_operator_count':int(sum(rule_ops.values())),
      'learned_top_operator':learned_top[0],
      'learned_top_probability':float(learned_top[1]),
      'rule_learner_disagreement':bool(disagreement)
    }

def language_state(question):
    ir,learned=ml.analyze(question)
    return {
      'language':ir.language,
      'language_scores':ir.language_scores,
      'canonical':ir.canonical,
      'operators':ir.operators,
      'semantic_fields':ir.fields,
      'constraints':_constraints(ir),
      'delta_language':_delta_language(ir,learned),
      'tokens':[{'surface':t.surface,'lemma':t.lemma,'features':t.features,'operators':t.operators,'root':t.root,'confidence':t.confidence} for t in ir.tokens],
      'distilled_operator_probs':learned
    }

def required_teachers(question):
    # R7.13 route stays frozen. Language layer annotates but cannot silently change teacher route.
    top2,scores=r713.required_teachers(question)
    return top2,scores,language_state(question)

def decide(item,teacher_rows=None):
    q=item['q']; ls=language_state(q)
    out=r713.decide(item,teacher_rows)
    out['r714_policy']=R714_POLICY
    out['morpholex']=ls
    # Enrich every H->T step with the same linguistic state and explicit language-error channel.
    for step in out.get('cyber_chain') or []:
        step['language']=ls['language']
        step['morpholex_constraints']=ls['constraints']
        step['delta_language']=ls['delta_language']
    return out
