from pathlib import Path
import sys, json, joblib, random
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.model_selection import StratifiedKFold, cross_val_score
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'source'))
import morpholex_engine as m
samples=[]; labels=[]
# Templates deliberately preserve the operator token but vary context/position/punctuation.
templates=['{w}','x {w} y','({w})','q: {w}?','a—{w}—b','{w}!','pre {w} post']
for lang in m.LEX:
    for op,words in m.LEX[lang].items():
        for w in words:
            for tpl in templates:
                samples.append(f'[{lang}] '+tpl.format(w=w));labels.append(op)
# neutral non-operator examples
neutral={'en':['system','model','data','value'],'zh':['系统','模型','数据','值'],'hi':['प्रणाली','मॉडल','डेटा','मान'],
'es':['sistema','modelo','datos','valor'],'fr':['système','modèle','données','valeur'],'ar':['نظام','نموذج','بيانات','قيمة'],
'bn':['সিস্টেম','মডেল','ডেটা','মান'],'pt':['sistema','modelo','dados','valor'],'ru':['система','модель','данные','значение'],'ur':['نظام','ماڈل','ڈیٹا','قدر']}
for lang,words in neutral.items():
    for w in words:
        for tpl in templates: samples.append(f'[{lang}] '+tpl.format(w=w));labels.append('NONE')
pipe=Pipeline([
 ('tfidf',TfidfVectorizer(analyzer='char_wb',ngram_range=(2,5),min_df=1,sublinear_tf=True,max_features=12000)),
 ('clf',LogisticRegression(max_iter=2500,C=7.0,class_weight='balanced',random_state=714))])
# CV here is only a consistency check over templated rule-distillation examples, not an external linguistic benchmark.
cv=StratifiedKFold(5,shuffle=True,random_state=714)
score=float(cross_val_score(pipe,samples,labels,cv=cv,scoring='accuracy').mean())
pipe.fit(samples,labels)
joblib.dump(pipe,ROOT/'models_morpholex_distiller.joblib')
meta={'n_samples':len(samples),'classes':list(pipe.named_steps['clf'].classes_),'cv5_accuracy':score,'boundary':'templated rule-distillation consistency only'}
(ROOT/'distiller_meta.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(meta,ensure_ascii=False,indent=2))
