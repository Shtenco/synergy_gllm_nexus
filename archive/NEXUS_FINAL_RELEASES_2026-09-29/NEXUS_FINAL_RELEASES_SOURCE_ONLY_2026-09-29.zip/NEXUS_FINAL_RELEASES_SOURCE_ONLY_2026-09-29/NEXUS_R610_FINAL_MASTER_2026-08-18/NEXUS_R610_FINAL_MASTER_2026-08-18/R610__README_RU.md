# NEXUS R6.10 — Blind-17

The R6.10 authority file was frozen before Blind-17. 25 unseen shells per query type, 2400 total queries. Whole-mechanism exact requires 75/75.

## Frozen neural collective R6.7
Intent 86.00%; causal 99.94%; cyber 100.00%; strict25 0.00%; mechanism75 0.00%.

## Compound R6.10
Intent 100.00%; causal 100.00%; cyber 100.00%; strict25 100.00%; mechanism75 100.00%; balanced 100.00%.
Authority intent coverage 100.00% / accuracy 100.00%; mechanism coverage 100.00% / accuracy 100.00%.

Boundary: closed-world 32 known mechanisms. Exact associative lookup is system authority, not unseen-rule neural reasoning.
