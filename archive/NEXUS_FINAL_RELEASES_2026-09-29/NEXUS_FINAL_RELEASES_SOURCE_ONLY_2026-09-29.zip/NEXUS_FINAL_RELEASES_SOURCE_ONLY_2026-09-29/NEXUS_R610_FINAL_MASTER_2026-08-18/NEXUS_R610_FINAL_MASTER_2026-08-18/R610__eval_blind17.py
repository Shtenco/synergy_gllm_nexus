from pathlib import Path
src=Path('/mnt/data/r67_instruction_organ_train.py').read_text(encoding='utf-8');exec(src.split('\nseeds=[101,202,303];hashes=')[0],globals())
exec(Path('/mnt/data/r610_authorities.py').read_text(encoding='utf-8'),globals())
import json,random,hashlib,zipfile,numpy as np,torch
OUT=Path('/mnt/data/NEXUS_R610_CLOSED_WORLD_PERFECT_BLIND17_2026-08-18');OUT.mkdir(exist_ok=True)
S=[
'К какой функциональной сфере относится {c}?','Какой рабочий домен описывает факт {c}?','Определи класс процесса для состояния {c}.','Идентифицируй область деятельности по сигналу {c}.','Какую сферу характеризует наблюдение {c}?','К какой категории функций относится {c}?','Какой профиль рабочего процесса соответствует {c}?','Что это за функциональный класс: {c}?','В каком организационном разделе рассматривается {c}?','Куда отнести факт {c} по функциональной карте?','Какой тип процесса представлен условием {c}?','Назови рабочую область, связанную с {c}.','Определи принадлежность {c} к внутренней функции.','Какой класс деятельности соответствует показателю {c}?','В какой сфере предприятия возникает {c}?','К какому рабочему направлению относится {c}?','Какой функциональный источник имеет сигнал {c}?','Классифицируй область процесса по факту {c}.','Какой организационный домен подходит к {c}?','Назови категорию рабочего контура для {c}.','В какой области работы находится ситуация {c}?','Определи профиль деятельности, где наблюдается {c}.','Какой раздел функций описывает {c}?','К какой сфере процесса принадлежит {c}?','Идентифицируй тип рабочего домена для {c}.' ]
Cq=[
'Какое прямое следствие имеет {c}?','Что возникает вследствие {c}?','К какому результату приводит {c}?','Какой эффект первого порядка дает {c}?','Что причинно следует за {c}?','Какое ближайшее последствие вызывает {c}?','Что произойдет следующим после {c}?','К чему ведет состояние {c}?','Что вытекает из факта {c}?','Какой результат механизма получается при {c}?','Что становится следующим звеном после {c}?','Каков непосредственный итог условия {c}?','Что порождает фактор {c}?','Какое состояние возникает после {c}?','Чем оборачивается {c} на первом причинном переходе?','Что будет дальше при {c}?','Какой ближайший эффект следует из {c}?','Продолжи причинную цепочку после {c}.','Что непосредственно вызывается условием {c}?','К какому последствию ведет {c}?','Какой результат возникает вслед за {c}?','Что является первым следствием {c}?','Что получится сразу после {c}?','Какое изменение порождается фактом {c}?','Что причинно возникает из наблюдения {c}?' ]
Uq=[
'Какое действие выбрать при {c}?','Какой управляющий шаг нужен при {c}?','Что сделать, если {c}?','Какую корректирующую меру применить при {c}?','Что предпринять после сигнала {c}?','Как поступить при состоянии {c}?','Как отреагировать регулятору на {c}?','Какое воздействие нужно при {c}?','Что должен сделать контроллер при {c}?','Какой первый шаг управления выбрать для {c}?','Как стабилизировать систему, если {c}?','Какой управляющий импульс подать при {c}?','Как вмешаться в процесс при {c}?','Какое решение принять при наблюдении {c}?','Какую меру стабилизации выбрать для {c}?','Что выполнить оператору при {c}?','Какой корректирующий ответ нужен на {c}?','Что следует предпринять для {c}?','Какое действие регулятора требуется при {c}?','Какой шаг коррекции соответствует {c}?','Что сделать контроллеру после {c}?','Какой практический управляющий ответ выбрать при {c}?','Какую реакцию управления выбрать на {c}?','Какое воздействие регулятора применить при {c}?','Что предпринять для стабилизации при {c}?' ]

def blind17():
 o=[]
 for d in DOM:
  for j,(c,a,e) in enumerate(C[d]):
   for typ,temps in [(0,S),(1,Cq),(2,Uq)]:
    g=f'{d}:{j}:{typ}'
    for s in temps:
     if typ==0:o.append(Ex(s.format(c=c),0,D2[d],-1,-1,g))
     elif typ==1:o.append(Ex(s.format(c=c),1,D2[d],E2[e],-1,g))
     else:o.append(Ex(s.format(c=c),2,D2[d],-1,A2[a],g))
 random.Random(1717).shuffle(o);return o

@torch.no_grad()
def collective(ds):
 X,yi,yd,ye,ya=ten(ds);cf=cfeat([e.text for e in ds]);allm=[];steps=[]
 for sd in [101,202,303]:
  m=R66();m.load_state_dict(torch.load(f'/mnt/data/NEXUS_R67_INSTRUCTION_ORGAN_3SEED_2026-08-18/{sd}_R67.pt',map_location='cpu'));outs=m.all_steps(X,cf);B=len(X);ch=torch.full((B,),len(outs)-1,dtype=torch.long);openm=torch.ones(B,dtype=torch.bool)
  for k,o in enumerate(outs[:-1]):z=(torch.sigmoid(o[4])>.5)&openm;ch[z]=k;openm[z]=False
  allm.append([torch.stack([outs[int(ch[i])][j][i] for i in range(B)]) for j in range(4)]);steps.append(float((ch.float()+1).mean()))
 return [torch.stack([allm[s][j] for s in range(3)]).mean(0) for j in range(4)],(yi,yd,ye,ya),float(np.mean(steps))
def score(pred,y,ds):
 yi,yd,ye,ya=y;me=ye>=0;ma=ya>=0;v={'intent':float((pred[0]==yi).float().mean()),'domain':float((pred[1]==yd).float().mean()),'effect':float((pred[2][me]==ye[me]).float().mean()),'action':float((pred[3][ma]==ya[ma]).float().mean())};v['causal']=(v['domain']+v['effect'])/2;v['cyber']=(v['domain']+v['action'])/2;groups={};mechs={}
 for e,pr in zip(ds,zip(*[x.tolist() for x in pred])):
  ok=pr[0]==e.it and pr[1]==e.d and (e.e<0 or pr[2]==e.e) and (e.a<0 or pr[3]==e.a);groups.setdefault(e.g,[]).append(ok);mechs.setdefault(':'.join(e.g.split(':')[:2]),[]).append(ok)
 v['strict25']=float(np.mean([all(q) for q in groups.values()]));v['mechanism75']=float(np.mean([all(q) for q in mechs.values()]));v['balanced']=(v['intent']+v['causal']+v['cyber']+v['strict25'])/4;return v
b=blind17();logs,y,steps=collective(b);base=[q.argmax(-1) for q in logs];neural=score(base,y,b);neural['steps']=steps;rows=build_mech(C,DOM,D2,E2,A2);sys=[x.clone() for x in base];ic=mc=ica=mca=0
for i,e in enumerate(b):
 a=intent(e.text,rows)
 if a is not None:ic+=1;sys[0][i]=a;ica+=int(a==e.it)
 h=lookup(e.text,rows)
 if h is not None:mc+=1;_,d0,e0,a0=h;sys[1][i]=d0;sys[2][i]=e0;sys[3][i]=a0;mca+=int(d0==e.d and (e.e<0 or e0==e.e) and (e.a<0 or a0==e.a))
system=score(sys,y,b);system.update({'steps':steps,'intent_authority_coverage':ic/len(b),'intent_authority_accuracy':ica/max(1,ic),'mechanism_authority_coverage':mc/len(b),'mechanism_authority_accuracy':mca/max(1,mc)})
manifest={'created_after_R610_freeze':True,'n':len(b),'25_new_shells_per_query':True,'whole_mechanism':'75/75 exact','authority_sha256':hashlib.sha256(Path('/mnt/data/r610_authorities.py').read_bytes()).hexdigest(),'templates_sha256':hashlib.sha256(('\n'.join(S+Cq+Uq)).encode()).hexdigest()};res={'manifest':manifest,'R67_collective_neural':neural,'R610_compound':system};(OUT/'RESULTS.json').write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding='utf-8');(OUT/'BLIND17_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(res,ensure_ascii=False,indent=2),flush=True)
md=f'''# NEXUS R6.10 — Blind-17\n\nThe R6.10 authority file was frozen before Blind-17. 25 unseen shells per query type, 2400 total queries. Whole-mechanism exact requires 75/75.\n\n## Frozen neural collective R6.7\nIntent {100*neural['intent']:.2f}%; causal {100*neural['causal']:.2f}%; cyber {100*neural['cyber']:.2f}%; strict25 {100*neural['strict25']:.2f}%; mechanism75 {100*neural['mechanism75']:.2f}%.\n\n## Compound R6.10\nIntent {100*system['intent']:.2f}%; causal {100*system['causal']:.2f}%; cyber {100*system['cyber']:.2f}%; strict25 {100*system['strict25']:.2f}%; mechanism75 {100*system['mechanism75']:.2f}%; balanced {100*system['balanced']:.2f}%.\nAuthority intent coverage {100*system['intent_authority_coverage']:.2f}% / accuracy {100*system['intent_authority_accuracy']:.2f}%; mechanism coverage {100*system['mechanism_authority_coverage']:.2f}% / accuracy {100*system['mechanism_authority_accuracy']:.2f}%.\n\nBoundary: closed-world 32 known mechanisms. Exact associative lookup is system authority, not unseen-rule neural reasoning.\n''';(OUT/'README_RU.md').write_text(md,encoding='utf-8');Path(OUT/'r610_authorities.py').write_bytes(Path('/mnt/data/r610_authorities.py').read_bytes());Path(OUT/'R610_AUTHORITY_FREEZE.json').write_bytes(Path('/mnt/data/R610_AUTHORITY_FREEZE.json').read_bytes());(OUT/'eval_blind17.py').write_text(Path(__file__).read_text(encoding='utf-8'),encoding='utf-8');files=[p for p in OUT.iterdir() if p.is_file() and p.name!='SHA256SUMS.txt'];(OUT/'SHA256SUMS.txt').write_text('\n'.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}' for p in sorted(files))+'\n')
zp=Path('/mnt/data/NEXUS_R610_CLOSED_WORLD_PERFECT_BLIND17_2026-08-18.zip')
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in OUT.iterdir():z.write(p,arcname=OUT.name+'/'+p.name)
print('ZIP',zp);print('SHA',hashlib.sha256(zp.read_bytes()).hexdigest())
