from pathlib import Path
src=Path('/mnt/data/r66_dual_channel_train.py').read_text(encoding='utf-8');exec(src.split('\nseeds=[101,202,303];hashes=')[0],globals())
import random,time,json,hashlib,numpy as np,torch,torch.nn.functional as F
OUT=Path('/mnt/data/NEXUS_R67_INSTRUCTION_ORGAN_3SEED_2026-08-18');OUT.mkdir(exist_ok=True)
# Compositional instruction grammar, created before Blind-14. Content is balanced across all intents.
PRE=['По имеющимся данным','В этой задаче','Для указанного наблюдения','Рассматривая сообщение','Используя только приведенный факт','Не зная названия подразделения','В рабочем контуре','Для данного состояния','По телеметрии системы','В рамках анализа']
SEM_VERB=['определи','классифицируй','установи','распознай','назови','идентифицируй']
SEM_OBJ=['функциональный домен','рабочую область','тип подразделения','сферу процесса','организационный класс','категорию деятельности']
CAU_VERB=['укажи','назови','выведи','определи','найди','предскажи']
CAU_OBJ=['прямое следствие','непосредственный эффект','ближайший результат','последствие первого порядка','следующее звено причинной цепи','результат механизма']
ACT_VERB=['выбери','назови','определи','предложи','укажи','сформулируй']
ACT_OBJ=['первое корректирующее действие','управляющий шаг','меру стабилизации','воздействие регулятора','первый управленческий импульс','действие контроллера']
TAIL=['.','; ответь только по требуемому типу.','; не подменяй тип ответа другим.','; используй смысл факта.']

def synth(seed=6701,n=9000):
 r=random.Random(seed);texts=[];ys=[];causes=[c for d in DOM for c,a,e in C[d]]
 for i in range(n):
  y=i%3;c=r.choice(causes);pre=r.choice(PRE);tail=r.choice(TAIL)
  if y==0:s=f'{pre}, {r.choice(SEM_VERB)} {r.choice(SEM_OBJ)} для факта «{c}»{tail}'
  elif y==1:s=f'{pre}, {r.choice(CAU_VERB)} {r.choice(CAU_OBJ)} для условия «{c}»{tail}'
  else:s=f'{pre}, {r.choice(ACT_VERB)} {r.choice(ACT_OBJ)} при состоянии «{c}»{tail}'
  texts.append(s);ys.append(y)
 idx=list(range(n));r.shuffle(idx);return [texts[i] for i in idx],torch.tensor([ys[i] for i in idx])
texts,y=synth();cut=7800;trt,try_=texts[:cut],y[:cut];dvt,dvy=texts[cut:],y[cut:];trf=cfeat(trt);dvf=cfeat(dvt)

# Update ONLY instruction organ and scalar mixture; content/operator/reasoning remains bitwise frozen.
seeds=[101,202,303];hashes={};devs=[]
for sd in seeds:
 m=R66();m.load_state_dict(torch.load(f'/mnt/data/NEXUS_R66_DUAL_CHANNEL_3SEED_2026-08-18/{sd}_R66.pt',map_location='cpu'))
 for p in m.parameters():p.requires_grad=False
 for p in m.instr.parameters():p.requires_grad=True
 m.intent_mix.requires_grad=True
 opt=torch.optim.AdamW(list(m.instr.parameters())+[m.intent_mix],lr=.0018,weight_decay=.008);g=torch.Generator().manual_seed(sd+77);bs=192;t0=time.perf_counter()
 for ep in range(22):
  order=torch.randperm(len(trf),generator=g)
  for st in range(0,len(trf),bs):
   ix=order[st:st+bs];log=m.instr(trf[ix]);L=F.cross_entropy(log,try_[ix])+.002*(torch.sigmoid(m.intent_mix)-.06).pow(2);opt.zero_grad();L.backward();opt.step()
 # Force system blend to mostly instruction organ; retain a small neural-cortex vote.
 with torch.no_grad():m.intent_mix.clamp_(-3.2,-1.8)
 with torch.no_grad():acc=float((m.instr(dvf).argmax(-1)==dvy).float().mean());mix=float(torch.sigmoid(m.intent_mix))
 p=OUT/f'{sd}_R67.pt';torch.save(m.state_dict(),p);hashes[p.name]=hashlib.sha256(p.read_bytes()).hexdigest();devs.append({'seed':sd,'synthetic_instruction_dev_acc':acc,'neural_intent_mix':mix,'train_sec':time.perf_counter()-t0});print('trained',sd,devs[-1],flush=True)
freeze={'protocol':'NEXUS Ω-R6.7 Specialized Instruction Organ','date':'2026-08-18','parent':'R6.6','seeds':seeds,'checkpoint_sha256':hashes,'blind14_not_defined_in_this_training_program':True,'content_reasoning_weights_changed':False,'instruction_training':{'n':len(texts),'train':cut,'heldout':len(texts)-cut,'balanced_content_across_intents':True},'boundary':'Instruction robustness stage; content/operator reasoning frozen. Same 32 content mechanisms remain. Blind-14 will be created only after this freeze.'};(OUT/'00_FREEZE_MANIFEST.json').write_text(json.dumps(freeze,ensure_ascii=False,indent=2),encoding='utf-8');(OUT/'01_INSTRUCTION_DEV.json').write_text(json.dumps(devs,ensure_ascii=False,indent=2),encoding='utf-8');(OUT/'train_r67_instruction.py').write_text(Path(__file__).read_text(encoding='utf-8'),encoding='utf-8');print('FREEZE',json.dumps(freeze,ensure_ascii=False,indent=2),flush=True)
