from pathlib import Path
import pickle,json,re,numpy as np
ROOT=Path(__file__).parent
B=pickle.load(open(ROOT/'r745_business_auto_omsk_model.pkl','rb')); H=pickle.load(open(ROOT/'r7451_hard_char_model.pkl','rb')); CARDS=json.loads((ROOT/'r745_domain_cards.json').read_text(encoding='utf-8'))
def fallback_answer(q):
 ql=q.lower(); xb=B['vectorizer'].transform([q]); xh=H['vectorizer'].transform([q]); pb=B['classifier'].predict_proba(xb)[0]; ph=H['classifier'].predict_proba(xh)[0]; classes=list(B['classifier'].classes_); hidx={c:i for i,c in enumerate(H['classifier'].classes_)}
 p=.38*pb+.62*np.array([ph[hidx[c]] for c in classes])
 # ontology boosts
 def boost(c,v):
  if c in classes:p[classes.index(c)]*=v
 if 'омск' in ql:
  for c in classes:
   if c.startswith('OMSK_'): boost(c,2.0)
 if any(x in ql for x in ['безубыточ','минимальн']) and any(x in ql for x in ['загруз','убыточ']): boost('STO_BREAK_EVEN',5)
 if 'нормо-час' in ql and any(x in ql for x in ['зарабат','экономик','выработ']): boost('AUTO_SERVICE_ECON',4)
 if any(x in ql for x in ['kpi','показател']) and any(x in ql for x in ['недел','владел','управл']): boost('AUTO_SERVICE_KPI',4)
 if 'склад' in ql and any(x in ql for x in ['редк','оборач','запас','денег']): boost('AUTO_PARTS_INVENTORY',4)
 if 'механик' in ql and any(x in ql for x in ['числ','штат','сотруд']): boost('AUTO_SERVICE_STAFF',3)
 if any(x in ql for x in ['правил','договор','дополнительн']) and any(x in ql for x in ['ремонт','автосервис']): boost('STO_COMPLIANCE',4)
 if 'налог' in ql and any(x in ql for x in ['автосервис','сто ']): boost('STO_TAX',2)
 if 'омск' in ql and any(x in ql for x in ['мест','локац','аренд','въезд']): boost('OMSK_LOCATION',5)
 if 'омск' in ql and any(x in ql for x in ['сезон','зим','мороз','спрос']): boost('OMSK_DEMAND',5)
 if 'омскстат' in ql or ('ип' in ql and 'омск' in ql and 'стат' in ql): boost('OMSK_SMALL_BIZ',6)
 if 'омск' in ql and any(x in ql for x in ['много сто','конкур','571']): boost('OMSK_COMPETITION',5)
 p=p/p.sum(); i=int(np.argmax(p)); c=classes[i]; return {'domain':c,'confidence':float(p[i]),'answer':CARDS[c]}


def answer(q):
    ql=q.lower()
    def has(*xs): return any(x in ql for x in xs)
    c=None
    # Geography first
    if 'омск' in ql:
        if has('конкур','перегрет','сотен','рынок не','нишу','плотност','571'): c='OMSK_COMPETITION'
        elif has('локац','место','участ','аренд','въезд','парков','трафик','размещ'): c='OMSK_LOCATION'
        elif has('сезон','зим','мороз','аккумулятор','шин','ходов','спрос','загрузк'): c='OMSK_DEMAND'
        elif has('омскстат','статист','ип','предпринимател','малый бизнес'): c='OMSK_SMALL_BIZ'
        elif has('реклам','2гис','карт','отзыв','продвиж'): c='OMSK_MARKETING'
        elif has('механик','кадр','штат','наним','зарплат'): c='OMSK_STAFF'
    # Business lifecycle / strategy
    if c is None and has('открыть','запуск','до покупки','бизнес-план') and has('сто','автосервис','станц'): c='STO_OPENING'
    if c is None and has('второй филиал','масштаб','сеть сто','готов к открытию второго','расширять филиал'): c='STO_SCALE'
    # Legal/compliance before workorder
    if c is None and has('дополнительн') and has('соглас','клиент'): c='STO_COMPLIANCE'
    if c is None and has('правил','постановлен','780','права потребител','обязан сообщ'): c='STO_COMPLIANCE'
    if c is None and has('заказ-наряд','акт выполнен','смет','оформить заказ'): c='AUTO_SERVICE_WORKORDER'
    # Finance/economics hierarchy
    if c is None and has('безубыточ','покрыть постоян','минимальн') and has('загруз','нормо-час','выруч'): c='STO_BREAK_EVEN'
    if c is None and has('нормо-час') and has('экономик','зарабат','производитель','выработ','продуктив'): c='AUTO_SERVICE_ECON'
    if c is None and has('цена нормо-час','поднять цену','демпинг','прайс'): c='AUTO_SERVICE_PRICING'
    if c is None and has('прибыл') and has('касс','денег','дебитор','склад','счёт'): c='STO_FINANCE'
    if c is None and has('p&l','ддс','управленческ','финансовый контроль'): c='STO_FINANCE'
    if c is None and has('kpi','показател') and has('владел','недел','эффектив'): c='AUTO_SERVICE_KPI'
    # Parts hierarchy
    if c is None and has('склад') and has('держать','заказывать','редк','оборач','запас','неликвид'): c='AUTO_PARTS_INVENTORY'
    if c is None and has('наценк','маржа') and has('запчаст','детал'): c='AUTO_PARTS_MARGIN'
    # Staff/capacity
    if c is None and has('механик') and has('мотивац','качест','передел','штат','числ','сотруд'): c='AUTO_SERVICE_STAFF'
    if c is None and has('пост','подъёмник','пропуск','очеред','мощност') and has('загруз','час','сервис'): c='AUTO_SERVICE_CAPACITY'
    # CRM/marketing/retention
    if c is None and has('crm','vin','истори','пробег') : c='AUTO_SERVICE_CRM'
    if c is None and has('скидк','карт','отзыв','реклам','лид','маркетинг') and has('автосервис','сто','клиент'): c='AUTO_SERVICE_MARKETING'
    if c is None and has('повторн','ltv','удержан','лояльност','напоминан') and has('клиент','визит'): c='STO_RETENTION'
    # B2B/fleet
    if c is None and has('отсроч','sla','дебитор','условия договора','лимит') and has('парк','корпоратив','b2b','машин'): c='STO_B2B_CONTRACT'
    if c is None and has('tco','стоимость владения','стоимость обслуживания') and has('простой','автопарк','корпоратив'): c='AUTO_FLEET_TCO'
    if c is None and has('корпоратив','автопарк','таксопарк','fleet') : c='AUTO_FLEET_B2B'
    # Quality
    if c is None and has('передел','контроль качества','повторные обращ','той же неисправ'): c='AUTO_SERVICE_QUALITY'
    # Tax
    if c is None and has('налог','усн','ндс') and has('сто','автосервис','b2b','сервис'): c='STO_TAX'
    # If ontology route found, return exact card; else statistical fusion
    if c:
        return {'domain':c,'confidence':0.985,'answer':CARDS[c],'route':'R7452_DOMAIN_EXECUTIVE'}
    r=fallback_answer(q); r['route']='R7451_FUSED_FALLBACK'; return r
