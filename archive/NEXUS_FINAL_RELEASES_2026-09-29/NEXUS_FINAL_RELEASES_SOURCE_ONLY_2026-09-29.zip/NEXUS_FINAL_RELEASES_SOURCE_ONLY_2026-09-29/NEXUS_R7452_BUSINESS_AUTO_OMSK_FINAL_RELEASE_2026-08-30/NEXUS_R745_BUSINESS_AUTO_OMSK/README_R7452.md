# NEXUS R7.45.2 BUSINESS / AUTO / OMSK

Дата: 2026-08-30

## Назначение
Специализированный business-domain organ поверх линии NEXUS: российский бизнес, автобизнес, экономика СТО/автосервисов, запчасти, персонал, CRM, B2B/fleet и Омск.

## Корпус
- 240 000 materialized train utterances (`r745_full_corpus_240k.jsonl.gz`)
- 30 000 disjoint holdout utterances
- 62 домена
- базовый word 1–2 gram semantic model
- 50 000 hard-negative char-ngram train + 12 000 hard holdout
- factual cards отделены от синтетического учебного корпуса

## Метрики
- Base holdout accuracy: 99.5433%
- Base macro-F1: 99.5407%
- Hard-negative holdout accuracy: 99.6167%
- Hard-negative macro-F1: 99.6054%
- Первый свободный 20Q post-freeze: 7/20 (disclosed dev)
- После hardening второй свободный 20Q: 11/20 (disclosed dev)
- После Domain Executive replay обоих disclosed sets: 19/20 + 19/20
- Финальный новый post-freeze 20Q: 15/20 = 75%

## Научная граница
Высокий synthetic holdout не равен unrestricted free-form routing. Финальный 20Q показывает пять соседних-domain ошибок. Не заявлять 99.5% как live business-dialogue accuracy.

## Основные фактические источники
- ФНС России: налоги 2026
- Роспотребнадзор / Правительство РФ: Правила ТО и ремонта №780
- Омскстат: предпринимательство и отраслевые данные Омской области
- АВТОСТАТ: парк и рынок автосервиса
- 2ГИС: открытая рубрика автосервисов Омска (динамический показатель)

## Файлы
- `train_r745_business_auto_omsk.py` — generator + training
- `r745_full_corpus_240k.jsonl.gz` — materialized corpus
- `r745_business_auto_omsk_model.pkl` — base model
- `r7451_hard_char_model.pkl` — hard-negative organ
- `nexus_r7452_business_domain_executive.py` — final runtime
- `R7452_FREEZE_MANIFEST.json` — freeze evidence
- `NEXUS_R7452_FINAL_20Q_DIALOGUE.md` — final post-freeze 20Q transcript
