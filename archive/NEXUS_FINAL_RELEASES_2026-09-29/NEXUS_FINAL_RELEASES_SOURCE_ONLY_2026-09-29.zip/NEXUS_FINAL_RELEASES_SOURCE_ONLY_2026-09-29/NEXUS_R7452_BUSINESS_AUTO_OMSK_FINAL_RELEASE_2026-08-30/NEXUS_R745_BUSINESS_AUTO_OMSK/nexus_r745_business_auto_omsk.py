from pathlib import Path
import pickle,json
ROOT=Path(__file__).parent
with open(ROOT/"r745_business_auto_omsk_model.pkl","rb") as f: M=pickle.load(f)
CARDS=json.loads((ROOT/"r745_domain_cards.json").read_text(encoding="utf-8"))
def answer(q):
    X=M["vectorizer"].transform([q]); c=M["classifier"].predict(X)[0]
    p=max(M["classifier"].predict_proba(X)[0])
    return {"domain":c,"confidence":float(p),"answer":CARDS[c]}
if __name__=="__main__":
 import sys; print(json.dumps(answer(" ".join(sys.argv[1:])),ensure_ascii=False))
