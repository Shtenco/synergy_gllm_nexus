from pathlib import Path
import pickle,json,re,numpy as np
ROOT=Path(__file__).parent
B=pickle.load(open(ROOT/'r745_business_auto_omsk_model.pkl','rb')); H=pickle.load(open(ROOT/'r7451_hard_char_model.pkl','rb')); CARDS=json.loads((ROOT/'r745_domain_cards.json').read_text(encoding='utf-8'))
def answer(q):
 ql=q.lower(); xb=B['vectorizer'].transform([q]); xh=H['vectorizer'].transform([q]); pb=B['classifier'].predict_proba(xb)[0]; ph=H['classifier'].predict_proba(xh)[0]; classes=list(B['classifier'].classes_); hidx={c:i for i,c in enumerate(H['classifier'].classes_)}
 p=.38*pb+.62*np.array([ph[hidx[c]] for c in classes])
 # ontology boosts
 def boost(c,v):
  if c in classes:p[classes.index(c)]*=v
 if 'омск' in ql:
  for c in classes:
   if c.startswith('OMSK_'): boost(c,2.0)
 if any(x in ql for x in ['безубыточ','минимальн']) and any(x in ql for x in ['загруз','убыточ']): boost('STO_BREAK_EVEN',5)
 if 'нормо-час' in ql and any(x in ql for x in ['зарабат','экономик','выработ']): boost('AUTO_SERVICE_ECON',4)
 if any(x in ql for x in ['kpi','показател']) and any(x in ql for x in ['недел','владел','управл']): boost('AUTO_SERVICE_KPI',4)
 if 'склад' in ql and any(x in ql for x in ['редк','оборач','запас','денег']): boost('AUTO_PARTS_INVENTORY',4)
 if 'механик' in ql and any(x in ql for x in ['числ','штат','сотруд']): boost('AUTO_SERVICE_STAFF',3)
 if any(x in ql for x in ['правил','договор','дополнительн']) and any(x in ql for x in ['ремонт','автосервис']): boost('STO_COMPLIANCE',4)
 if 'налог' in ql and any(x in ql for x in ['автосервис','сто ']): boost('STO_TAX',2)
 if 'омск' in ql and any(x in ql for x in ['мест','локац','аренд','въезд']): boost('OMSK_LOCATION',5)
 if 'омск' in ql and any(x in ql for x in ['сезон','зим','мороз','спрос']): boost('OMSK_DEMAND',5)
 if 'омскстат' in ql or ('ип' in ql and 'омск' in ql and 'стат' in ql): boost('OMSK_SMALL_BIZ',6)
 if 'омск' in ql and any(x in ql for x in ['много сто','конкур','571']): boost('OMSK_COMPETITION',5)
 p=p/p.sum(); i=int(np.argmax(p)); c=classes[i]; return {'domain':c,'confidence':float(p[i]),'answer':CARDS[c]}
