from __future__ import annotations
import argparse, json, time, urllib.request
from pathlib import Path

def call(url:str,model:str,prompt:str)->dict:
    body=json.dumps({"model":model,"messages":[{"role":"user","content":prompt}],"temperature":0,"max_tokens":512}).encode()
    req=urllib.request.Request(url,data=body,headers={"Content-Type":"application/json","Authorization":"Bearer none"})
    start=time.perf_counter()
    with urllib.request.urlopen(req,timeout=1800) as r: data=json.loads(r.read())
    return {"text":data['choices'][0]['message']['content'],"latency_s":time.perf_counter()-start,"raw":data}

def main()->int:
    p=argparse.ArgumentParser(); p.add_argument('--cases',required=True); p.add_argument('--cortex-url',required=True); p.add_argument('--nexus-url',required=True); p.add_argument('--output',required=True); p.add_argument('--model',default='Qwen3-14B-Q4_K_M'); a=p.parse_args()
    cases=json.loads(Path(a.cases).read_text()); rows=[]
    for case in cases:
        bare=call(a.cortex_url,a.model,case['prompt']); nexus=call(a.nexus_url,'NEXUS-R2.1-Qwen3-14B',case['prompt'])
        nmeta=nexus['raw'].get('nexus',{})
        rows.append({"id":case['id'],"category":case.get('category'),"prompt":case['prompt'],"bare":bare,"nexus":nexus,
          "nexus_verified":bool(nmeta.get('verified')),"nexus_engine":nmeta.get('engine')})
    report={"format":"nexus-r21-qwen3-ab/1","cases":len(rows),"rows":rows,
      "verified_rate":sum(r['nexus_verified'] for r in rows)/max(1,len(rows)),
      "claim_boundary":"No correctness score is inferred without sealed expected answers or external graders."}
    Path(a.output).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8'); print(json.dumps({"cases":len(rows),"verified_rate":report['verified_rate']},indent=2)); return 0
if __name__=='__main__': raise SystemExit(main())
