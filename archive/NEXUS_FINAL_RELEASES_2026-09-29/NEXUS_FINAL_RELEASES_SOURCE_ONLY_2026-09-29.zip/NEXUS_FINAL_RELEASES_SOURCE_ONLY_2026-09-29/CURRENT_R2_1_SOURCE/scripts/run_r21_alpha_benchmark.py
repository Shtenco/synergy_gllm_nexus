from __future__ import annotations

import argparse
import hashlib
import json
import tempfile
import time
from collections import Counter, defaultdict
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from nexus_r21.exact_router_v2 import route_exact
from nexus_r21.graphrag import VerifiedGraphRAG
from nexus_r21.multi_rule_parser import MultiRuleParser
from nexus_r21.relation_extractor_v2 import CharNGramNB, RelationExtractorV2
from nexus_r21.spo_memory import MemoryQuery, SPOMemory
from nexus_r21.system import NexusR21System


class MockCortex:
    def __init__(self):
        self.calls = 0

    def generate(self, prompt: str, *, system: str, max_tokens: int = 384, temperature: float = 0.1):
        self.calls += 1
        return {
            "text": "Недостаточно проверенных источников; это только неподтверждённая гипотеза.",
            "latency_s": 0.0,
            "backend": "mock-cortex",
            "returncode": 0,
        }


def contains_expected(actual: str, expected: str) -> bool:
    return str(expected).casefold() in str(actual).casefold()


def run_case(case: dict, model_path: Path) -> tuple[bool, dict]:
    kind = case["kind"]
    expected = case["expected"]
    inp = case["input"]

    if kind == "exact":
        result = route_exact(inp)
        actual = None if result is None else (result.exact_fraction or str(result.value))
        return actual == str(expected), {"actual": actual, "engine": None if result is None else result.engine}

    if kind == "not_exact":
        result = route_exact(inp)
        return result is None, {"actual": None if result is None else result.expression}

    if kind == "memory_session":
        with tempfile.TemporaryDirectory() as td:
            cortex = MockCortex()
            system = NexusR21System(cortex, state_dir=td, relation_model=model_path)
            first = system.answer(inp[0])
            second = system.answer(inp[1])
            ok = first["verified"] and second["verified"] and contains_expected(second["answer"], expected) and cortex.calls == 0
            return ok, {"write": first, "read": second, "cortex_calls": cortex.calls}

    if kind == "memory_direct":
        with tempfile.TemporaryDirectory() as td:
            memory = SPOMemory(Path(td) / "m.sqlite")
            for s, p, o in inp["facts"]:
                memory.add_fact(s, p, o)
            if "query" in inp:
                rows = memory.query(**inp["query"])
            else:
                rows = memory.query(MemoryQuery(text=inp["text_query"]))
            objects = [r.object for r in rows]
            predicates = [r.predicate for r in rows]
            if isinstance(expected, list):
                ok = set(objects) == set(expected)
            else:
                ok = expected in predicates
            return ok, {"objects": objects, "predicates": predicates}

    if kind == "memory_conflict":
        with tempfile.TemporaryDirectory() as td:
            memory = SPOMemory(Path(td) / "m.sqlite")
            for s, p, o in inp:
                memory.add_fact(s, p, o)
            conflicts = memory.count()["conflicts"]
            facts = memory.query(MemoryQuery(status=None, limit=20))
            ok = conflicts >= 1 and sum(f.status == "conflict" for f in facts) == expected
            return ok, {"conflicts": conflicts, "statuses": [f.status for f in facts]}

    if kind == "logic":
        proof = MultiRuleParser().parse_and_prove(inp)
        ok = proof.entailed == expected["entailed"] and proof.contradiction == expected["contradiction"]
        return ok, {"entailed": proof.entailed, "contradiction": proof.contradiction, "derived": proof.derived}

    if kind == "relation":
        ext = RelationExtractorV2(CharNGramNB.load(model_path))
        rows = ext.extract(inp)
        actual = None if not rows else {
            "relation": rows[0].relation,
            "subject": rows[0].subject,
            "object": rows[0].object,
        }
        ok = actual == expected
        return ok, {"actual": actual}

    if kind in {"graphrag", "graphrag_multi"}:
        with tempfile.TemporaryDirectory() as td:
            memory = SPOMemory(Path(td) / "g.sqlite")
            ext = RelationExtractorV2(CharNGramNB.load(model_path))
            rag = VerifiedGraphRAG(memory, ext)
            if kind == "graphrag":
                sid = rag.register_source(**inp["source"])
                rag.ingest_text(sid, inp["text"])
            else:
                for source in inp["sources"]:
                    source = dict(source)
                    text = source.pop("text")
                    sid = rag.register_source(**source)
                    rag.ingest_text(sid, text)
            packet = rag.evidence_packet(inp["query"])
            uris = [x["uri"] for x in packet["evidence"]]
            ok = packet["evidence_available"] == expected["verified"] and packet["source_count"] >= expected["min_sources"]
            if expected.get("uri"):
                ok = ok and expected["uri"] in uris
            return ok, {"evidence_available": packet["evidence_available"], "verified": packet["verified"], "source_count": packet["source_count"], "uris": uris}

    with tempfile.TemporaryDirectory() as td:
        cortex = MockCortex()
        system = NexusR21System(cortex, state_dir=td, relation_model=model_path)
        response = system.answer(inp)
        if kind == "system_engine":
            ok = response["engine"] == expected and response["verified"] and not response["cortex_used"]
        elif kind == "system_unverified":
            ok = response["verified"] is expected and response["cortex_used"]
        elif kind == "system_exact_no_cortex":
            ok = response["verified"] and contains_expected(response["answer"], expected) and cortex.calls == 0
        elif kind == "system_logic_no_cortex":
            ok = response["engine"] == expected and response["verified"] and cortex.calls == 0
        else:
            raise ValueError(f"unknown kind: {kind}")
        return ok, {"response": response, "cortex_calls": cortex.calls}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark", default="benchmarks_r21/NEXUS_R21_ALPHA_CORE_V1.json")
    parser.add_argument("--output", default="evidence_r21/NEXUS_R21_ALPHA_CORE_V1_REPORT.json")
    args = parser.parse_args()

    root = ROOT
    benchmark_path = (root / args.benchmark).resolve()
    output_path = (root / args.output).resolve()
    model_path = root / "nexus_r21" / "relation_model_v2.json"

    benchmark = json.loads(benchmark_path.read_text(encoding="utf-8"))
    rows = []
    category = defaultdict(lambda: {"passed": 0, "total": 0})
    started = time.perf_counter()
    for case in benchmark["cases"]:
        t0 = time.perf_counter()
        try:
            passed, detail = run_case(case, model_path)
            error = None
        except Exception as exc:
            passed, detail, error = False, {}, f"{type(exc).__name__}: {exc}"
        elapsed = time.perf_counter() - t0
        rows.append({
            "id": case["id"],
            "category": case["category"],
            "kind": case["kind"],
            "passed": passed,
            "elapsed_s": elapsed,
            "detail": detail,
            "error": error,
        })
        category[case["category"]]["total"] += 1
        category[case["category"]]["passed"] += int(passed)

    passed = sum(int(x["passed"]) for x in rows)
    report = {
        "format": "nexus-r21-alpha-core-report/1",
        "benchmark_sha256": hashlib.sha256(benchmark_path.read_bytes()).hexdigest(),
        "relation_model_sha256": hashlib.sha256(model_path.read_bytes()).hexdigest(),
        "passed": passed,
        "total": len(rows),
        "accuracy": passed / max(1, len(rows)),
        "elapsed_s": time.perf_counter() - started,
        "per_category": {
            name: values | {"accuracy": values["passed"] / values["total"]}
            for name, values in sorted(category.items())
        },
        "rows": rows,
        "claim_boundary": benchmark["claim_boundary"],
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({
        "passed": report["passed"],
        "total": report["total"],
        "accuracy": report["accuracy"],
        "per_category": report["per_category"],
        "output": str(output_path),
    }, ensure_ascii=False, indent=2))
    return 0 if passed == len(rows) else 1


if __name__ == "__main__":
    raise SystemExit(main())
