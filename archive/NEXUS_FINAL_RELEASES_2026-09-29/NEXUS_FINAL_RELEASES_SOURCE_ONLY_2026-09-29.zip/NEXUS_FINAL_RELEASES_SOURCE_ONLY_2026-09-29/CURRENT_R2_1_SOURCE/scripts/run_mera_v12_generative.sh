#!/usr/bin/env bash
set -Eeuo pipefail

# NEXUS R2.1 -> official MERA v1.2 generative submission harness.
# This script creates submission artifacts. The blind score is calculated only
# after the resulting ZIP is uploaded to the official MERA platform.

MERA_REPO="${MERA_REPO:-https://github.com/MERA-Evaluation/MERA.git}"
MERA_COMMIT="${MERA_COMMIT:-2a537ddd0d1e7b10fadfb0ee193aa1e211cfb169}"
MERA_ROOT="${MERA_ROOT:-$PWD/.cache/MERA}"
MERA_FOLDER="${MERA_FOLDER:-$PWD/mera_results/NEXUS-R2.1-Qwen3-14B}"
LLAMA_HOST="${LLAMA_HOST:-127.0.0.1}"
LLAMA_PORT="${LLAMA_PORT:-8080}"
NEXUS_HOST="${NEXUS_HOST:-127.0.0.1}"
NEXUS_PORT="${NEXUS_PORT:-8081}"
NEXUS_CONTEXT="${NEXUS_CONTEXT:-8192}"
NEXUS_THREADS="${NEXUS_THREADS:-8}"

: "${NEXUS_LLAMA_SERVER:?Set NEXUS_LLAMA_SERVER to llama-server binary}"
: "${NEXUS_QWEN3_14B_GGUF:?Set NEXUS_QWEN3_14B_GGUF to Qwen3-14B-Q4_K_M.gguf}"

EXPECTED_SHA256="500a8806e85ee9c83f3ae08420295592451379b4f8cf2d0f41c15dffeb6b81f0"
ACTUAL_SHA256="$(sha256sum "$NEXUS_QWEN3_14B_GGUF" | awk '{print $1}')"
if [[ "$ACTUAL_SHA256" != "$EXPECTED_SHA256" ]]; then
  echo "FATAL: Qwen3-14B SHA-256 mismatch" >&2
  echo "expected=$EXPECTED_SHA256" >&2
  echo "actual=$ACTUAL_SHA256" >&2
  exit 2
fi

mkdir -p "$MERA_FOLDER" "$(dirname "$MERA_ROOT")"
LLAMA_LOG="$MERA_FOLDER/llama-server.log"
NEXUS_LOG="$MERA_FOLDER/nexus-authority-server.log"

cleanup() {
  [[ -n "${NEXUS_PID:-}" ]] && kill "$NEXUS_PID" 2>/dev/null || true
  [[ -n "${LLAMA_PID:-}" ]] && kill "$LLAMA_PID" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

"$NEXUS_LLAMA_SERVER" \
  -m "$NEXUS_QWEN3_14B_GGUF" \
  --alias Qwen3-14B-Q4_K_M \
  --host "$LLAMA_HOST" \
  --port "$LLAMA_PORT" \
  -c "$NEXUS_CONTEXT" \
  -t "$NEXUS_THREADS" \
  --parallel 1 \
  --jinja \
  >"$LLAMA_LOG" 2>&1 &
LLAMA_PID=$!

for _ in $(seq 1 360); do
  if curl -fsS "http://$LLAMA_HOST:$LLAMA_PORT/health" >/dev/null 2>&1; then
    break
  fi
  if ! kill -0 "$LLAMA_PID" 2>/dev/null; then
    tail -n 200 "$LLAMA_LOG" >&2
    exit 3
  fi
  sleep 2
done
curl -fsS "http://$LLAMA_HOST:$LLAMA_PORT/health" >/dev/null

export NEXUS_CORTEX_URL="http://$LLAMA_HOST:$LLAMA_PORT/v1/chat/completions"
export NEXUS_CORTEX_MODEL="Qwen3-14B-Q4_K_M"
export NEXUS_ISOLATE_REQUESTS=1
export NEXUS_HOST
export NEXUS_PORT
python scripts/nexus_openai_server.py >"$NEXUS_LOG" 2>&1 &
NEXUS_PID=$!

for _ in $(seq 1 120); do
  if curl -fsS "http://$NEXUS_HOST:$NEXUS_PORT/health" >/dev/null 2>&1; then
    break
  fi
  if ! kill -0 "$NEXUS_PID" 2>/dev/null; then
    tail -n 200 "$NEXUS_LOG" >&2
    exit 4
  fi
  sleep 1
done
curl -fsS "http://$NEXUS_HOST:$NEXUS_PORT/health"

if [[ ! -d "$MERA_ROOT/.git" ]]; then
  git clone --recurse-submodules "$MERA_REPO" "$MERA_ROOT"
fi
git -C "$MERA_ROOT" fetch --all --tags
git -C "$MERA_ROOT" checkout --detach "$MERA_COMMIT"
git -C "$MERA_ROOT" submodule update --init --recursive

python -m pip install -e "$MERA_ROOT/lm-evaluation-harness"

export OPENAI_API_KEY="none"
export MERA_FOLDER
export MERA_MODEL_STRING="model=NEXUS-R2.1-Qwen3-14B,num_concurrent=1,base_url=http://$NEXUS_HOST:$NEXUS_PORT/v1/chat/completions,tokenizer_backend=huggingface,tokenizer=Qwen/Qwen3-14B"
export MERA_COMMON_SETUP="--model openai-chat-completions --batch_size=1 --predict_only --log_samples --seed 1234 --verbosity INFO --apply_chat_template --fewshot_as_multiturn"

(
  cd "$MERA_ROOT"
  bash scripts/run_benchmark_gen.sh
)

echo "MERA generative submission artifacts: $MERA_FOLDER"
echo "No blind score is available until the generated ZIP is uploaded to the official MERA platform."
