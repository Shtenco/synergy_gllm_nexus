from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from nexus_r21.graphrag import VerifiedGraphRAG
from nexus_r21.relation_extractor_v2 import CharNGramNB, RelationExtractorV2
from nexus_r21.spo_memory import SPOMemory


REQUIRED_FIELDS = {
    "title", "uri", "publisher", "trust_score", "license", "retrieved_at", "text"
}


def load_documents(path: Path) -> list[dict]:
    documents = []
    seen_uri = set()
    seen_hash = set()
    with path.open(encoding="utf-8") as fh:
        for line_no, line in enumerate(fh, start=1):
            if not line.strip():
                continue
            row = json.loads(line)
            missing = REQUIRED_FIELDS - set(row)
            if missing:
                raise ValueError(f"line {line_no}: missing fields {sorted(missing)}")
            uri = str(row["uri"]).strip()
            text = str(row["text"]).strip()
            if not uri or not text:
                raise ValueError(f"line {line_no}: uri/text is empty")
            trust = float(row["trust_score"])
            if not 0 <= trust <= 1:
                raise ValueError(f"line {line_no}: trust_score outside [0,1]")
            digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
            if uri in seen_uri or digest in seen_hash:
                continue
            seen_uri.add(uri)
            seen_hash.add(digest)
            row["trust_score"] = trust
            row["content_sha256"] = digest
            documents.append(row)
    return documents


def main() -> int:
    parser = argparse.ArgumentParser(description="Build a persistent NEXUS R2.1 verified GraphRAG index.")
    parser.add_argument("--documents", required=True, help="JSONL source ledger with document text and provenance")
    parser.add_argument("--output", required=True, help="Output index directory")
    parser.add_argument("--min-ingest-trust", type=float, default=0.50)
    args = parser.parse_args()

    input_path = Path(args.documents).resolve()
    output_dir = Path(args.output).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    documents = load_documents(input_path)

    memory = SPOMemory(output_dir / "spo_memory.sqlite")
    relation_model = ROOT / "nexus_r21" / "relation_model_v2.json"
    extractor = RelationExtractorV2(CharNGramNB.load(relation_model))
    rag = VerifiedGraphRAG(memory, extractor)

    accepted = []
    rejected = []
    started = time.perf_counter()
    for row in documents:
        if row["trust_score"] < args.min_ingest_trust:
            rejected.append({
                "uri": row["uri"],
                "reason": "below min_ingest_trust",
                "trust_score": row["trust_score"],
            })
            continue
        source_fields = {
            key: row[key]
            for key in ("title", "uri", "publisher", "trust_score", "license", "retrieved_at")
        }
        source_id = rag.register_source(**source_fields)
        chunk_ids = rag.ingest_text(source_id, row["text"])
        accepted.append({
            "source_id": source_id,
            "uri": row["uri"],
            "content_sha256": row["content_sha256"],
            "chunks": len(chunk_ids),
            "trust_score": row["trust_score"],
        })

    rag.save(output_dir / "index")
    memory.export_jsonl(output_dir / "facts.jsonl")
    report = {
        "format": "nexus-r21-graphrag-build-report/1",
        "input": str(input_path),
        "input_sha256": hashlib.sha256(input_path.read_bytes()).hexdigest(),
        "relation_model_sha256": hashlib.sha256(relation_model.read_bytes()).hexdigest(),
        "accepted_sources": len(accepted),
        "rejected_sources": len(rejected),
        "chunks": len(rag.chunks),
        "memory": memory.count(),
        "elapsed_s": time.perf_counter() - started,
        "accepted": accepted,
        "rejected": rejected,
        "verification_policy": {
            "high_trust_single_source": 0.90,
            "medium_trust_source": 0.70,
            "medium_source_quorum": 2,
            "retrieval_alone_is_verification": False,
        },
        "claim_boundary": (
            "The build verifies provenance and source-quorum mechanics. "
            "It does not certify that every ingested statement is true."
        ),
    }
    (output_dir / "BUILD_REPORT.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps({
        "accepted_sources": report["accepted_sources"],
        "rejected_sources": report["rejected_sources"],
        "chunks": report["chunks"],
        "memory": report["memory"],
        "output": str(output_dir),
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
