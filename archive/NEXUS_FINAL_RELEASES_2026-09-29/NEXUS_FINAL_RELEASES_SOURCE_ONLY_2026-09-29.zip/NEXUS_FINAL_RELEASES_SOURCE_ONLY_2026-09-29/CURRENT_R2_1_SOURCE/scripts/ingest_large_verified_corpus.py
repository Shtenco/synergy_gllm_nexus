from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from nexus_r21.relation_extractor_v2 import CharNGramNB, RelationExtractorV2
from nexus_r21.sqlite_graphrag import SQLiteGraphRAG

def main()->int:
    p=argparse.ArgumentParser(description='Streaming disk-backed GraphRAG corpus builder')
    p.add_argument('--documents',required=True)
    p.add_argument('--database',required=True)
    p.add_argument('--report',required=True)
    p.add_argument('--min-trust',type=float,default=.5)
    p.add_argument('--batch-size',type=int,default=100)
    a=p.parse_args()
    docs=Path(a.documents).resolve(); db=Path(a.database).resolve(); report=Path(a.report).resolve()
    model=ROOT/'nexus_r21'/'relation_model_v2.json'
    rag=SQLiteGraphRAG(db,RelationExtractorV2(CharNGramNB.load(model)))
    result=rag.ingest_jsonl(docs,min_trust=a.min_trust,batch_size=a.batch_size)
    result|={"format":"nexus-r21-large-corpus-build/1","input":str(docs),"database":str(db),
             "input_sha256":hashlib.sha256(docs.read_bytes()).hexdigest(),"relation_model_sha256":hashlib.sha256(model.read_bytes()).hexdigest(),
             "claim_boundary":"Pipeline capacity is not a claim that 10M entities or 50M relations have already been ingested."}
    report.parent.mkdir(parents=True,exist_ok=True); report.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    rag.write_manifest(report.with_name('SQLITE_GRAPHRAG_MANIFEST.json'),input_sha256=result['input_sha256'])
    print(json.dumps(result,ensure_ascii=False,indent=2)); return 0
if __name__=='__main__': raise SystemExit(main())
