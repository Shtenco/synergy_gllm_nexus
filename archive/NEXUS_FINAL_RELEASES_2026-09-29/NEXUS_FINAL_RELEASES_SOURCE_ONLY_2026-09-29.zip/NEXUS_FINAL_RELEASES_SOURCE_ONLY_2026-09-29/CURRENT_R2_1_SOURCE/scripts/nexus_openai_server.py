from __future__ import annotations

import json
import os
import sys
import tempfile
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from nexus_r21.system import NexusR21System, Qwen3LlamaCpp, Qwen3OpenAIBackend


def env_flag(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().casefold() in {"1", "true", "yes", "on"}


def build_cortex():
    timeout_s = int(os.environ.get("NEXUS_TIMEOUT_S", "1800"))
    cortex_url = os.environ.get("NEXUS_CORTEX_URL")
    if cortex_url:
        cortex = Qwen3OpenAIBackend(
            base_url=cortex_url,
            model=os.environ.get("NEXUS_CORTEX_MODEL", "Qwen3-14B-Q4_K_M"),
            timeout_s=timeout_s,
            api_key=os.environ.get("NEXUS_CORTEX_API_KEY", "none"),
        )
        if not cortex.available():
            raise RuntimeError(f"Qwen3 cortex server is unavailable: {cortex_url}")
        return cortex

    binary = os.environ.get("NEXUS_LLAMA_COMPLETION")
    model = os.environ.get("NEXUS_QWEN3_14B_GGUF")
    if not binary or not model:
        raise RuntimeError(
            "Set NEXUS_CORTEX_URL for a persistent llama-server, or set both "
            "NEXUS_LLAMA_COMPLETION and NEXUS_QWEN3_14B_GGUF."
        )
    cortex = Qwen3LlamaCpp(
        binary=binary,
        model=model,
        threads=int(os.environ.get("NEXUS_THREADS", "8")),
        context=int(os.environ.get("NEXUS_CONTEXT", "8192")),
        timeout_s=timeout_s,
    )
    if not cortex.available():
        raise RuntimeError("Qwen3-14B GGUF or llama-completion binary is unavailable")
    return cortex


CORTEX = build_cortex()
GRAPHRAG_INDEX = os.environ.get("NEXUS_GRAPHRAG_INDEX")
KNOWLEDGE_DB = os.environ.get("NEXUS_KNOWLEDGE_DB")
CORPUS_DB = os.environ.get("NEXUS_CORPUS_DB")
RELATION_MODEL = Path(
    os.environ.get(
        "NEXUS_RELATION_MODEL",
        str(ROOT / "nexus_r21" / "relation_model_v2.json"),
    )
)
DEFAULT_STATE_DIR = Path(os.environ.get("NEXUS_STATE_DIR", str(ROOT / "state_r21")))
ISOLATE_REQUESTS = env_flag("NEXUS_ISOLATE_REQUESTS", False)


def build_system(state_dir: str | Path | None = None) -> NexusR21System:
    return NexusR21System(
        CORTEX,
        state_dir=Path(state_dir) if state_dir is not None else DEFAULT_STATE_DIR,
        relation_model=RELATION_MODEL,
        graphrag_index=GRAPHRAG_INDEX,
        knowledge_db=KNOWLEDGE_DB,
        corpus_db=CORPUS_DB,
    )


SYSTEM = build_system()


def message_text(message: dict[str, Any]) -> str:
    content = message.get("content", "")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text":
                parts.append(str(item.get("text", "")))
        return "\n".join(parts)
    return str(content)


def split_context(messages: list[dict[str, Any]]) -> tuple[str, str]:
    user_indexes = [i for i, message in enumerate(messages) if message.get("role") == "user"]
    if not user_indexes:
        return "", ""
    final_index = user_indexes[-1]
    question = message_text(messages[final_index]).strip()
    context_lines = []
    for index, message in enumerate(messages):
        if index == final_index:
            continue
        role = str(message.get("role", "unknown")).upper()
        text = message_text(message).strip()
        if text:
            context_lines.append(f"{role}: {text}")
    return question, "\n\n".join(context_lines)


class Handler(BaseHTTPRequestHandler):
    server_version = "NEXUS-R2.1-OpenAI/1.1"

    def log_message(self, fmt: str, *args: Any) -> None:
        sys.stderr.write("%s - %s\n" % (self.log_date_time_string(), fmt % args))

    def send_json(self, status: int, payload: dict[str, Any]) -> None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self) -> None:
        if self.path == "/health":
            self.send_json(
                200,
                {
                    "status": "ok",
                    "model": SYSTEM.VERSION,
                    "isolated_requests": ISOLATE_REQUESTS,
                    "cortex": type(CORTEX).__name__,
                },
            )
            return
        if self.path == "/v1/models":
            self.send_json(
                200,
                {
                    "object": "list",
                    "data": [
                        {
                            "id": "NEXUS-R2.1-Qwen3-14B",
                            "object": "model",
                            "owned_by": "Shtenco",
                        }
                    ],
                },
            )
            return
        self.send_json(404, {"error": {"message": "not found", "type": "not_found"}})

    def _answer(self, question: str, context: str | None) -> dict[str, Any]:
        if not ISOLATE_REQUESTS:
            return SYSTEM.answer(question, context=context)
        # Blind benchmark requests must not inherit arbitrary session facts from
        # previous tasks. The loaded Qwen server and immutable GraphRAG index are
        # shared, while the session SPO database is new for every request.
        with tempfile.TemporaryDirectory(prefix="nexus-r21-request-") as temp_dir:
            request_system = build_system(temp_dir)
            return request_system.answer(question, context=context)

    def do_POST(self) -> None:
        if self.path not in {"/v1/chat/completions", "/chat/completions"}:
            self.send_json(404, {"error": {"message": "not found", "type": "not_found"}})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            payload = json.loads(self.rfile.read(length))
            messages = payload.get("messages") or []
            if not isinstance(messages, list):
                raise ValueError("messages must be a list")
            question, context = split_context(messages)
            if not question:
                raise ValueError("final user message is missing")

            started = time.perf_counter()
            result = self._answer(question, context or None)
            elapsed = time.perf_counter() - started
            answer = result["answer"]
            prompt_chars = sum(len(message_text(message)) for message in messages)
            response = {
                "id": "chatcmpl-" + uuid.uuid4().hex,
                "object": "chat.completion",
                "created": int(time.time()),
                "model": payload.get("model") or "NEXUS-R2.1-Qwen3-14B",
                "choices": [
                    {
                        "index": 0,
                        "message": {"role": "assistant", "content": answer},
                        "finish_reason": "stop",
                    }
                ],
                "usage": {
                    "prompt_tokens": max(1, prompt_chars // 4),
                    "completion_tokens": max(1, len(answer) // 4),
                    "total_tokens": max(2, (prompt_chars + len(answer)) // 4),
                },
                "nexus": {
                    "engine": result["engine"],
                    "verified": result["verified"],
                    "cortex_used": result["cortex_used"],
                    "latency_s": elapsed,
                    "request_isolated": ISOLATE_REQUESTS,
                },
            }
            self.send_json(200, response)
        except Exception as exc:
            self.send_json(
                500,
                {
                    "error": {
                        "message": f"{type(exc).__name__}: {exc}",
                        "type": "nexus_server_error",
                    }
                },
            )


def main() -> None:
    host = os.environ.get("NEXUS_HOST", "127.0.0.1")
    port = int(os.environ.get("NEXUS_PORT", "8081"))
    httpd = ThreadingHTTPServer((host, port), Handler)
    print(
        json.dumps(
            {
                "status": "ready",
                "host": host,
                "port": port,
                "model": SYSTEM.VERSION,
                "isolated_requests": ISOLATE_REQUESTS,
                "cortex": type(CORTEX).__name__,
            },
            ensure_ascii=False,
        ),
        flush=True,
    )
    httpd.serve_forever()


if __name__ == "__main__":
    main()
