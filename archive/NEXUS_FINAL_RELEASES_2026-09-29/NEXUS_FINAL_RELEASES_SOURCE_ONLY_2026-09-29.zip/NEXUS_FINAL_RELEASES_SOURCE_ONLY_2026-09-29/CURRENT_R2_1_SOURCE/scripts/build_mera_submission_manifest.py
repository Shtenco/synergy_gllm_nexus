from __future__ import annotations
import argparse, hashlib, json, os, platform, shutil, subprocess, time, zipfile
from pathlib import Path

def sha(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''): h.update(block)
    return h.hexdigest()

def main()->int:
    p=argparse.ArgumentParser()
    p.add_argument('--results',required=True); p.add_argument('--output',required=True)
    p.add_argument('--model-manifest',required=True); p.add_argument('--protocol',required=True)
    p.add_argument('--git-commit',default=os.environ.get('GITHUB_SHA','unknown'))
    a=p.parse_args(); results=Path(a.results).resolve(); out=Path(a.output).resolve()
    files=[x for x in results.rglob('*') if x.is_file()]
    manifest={"format":"nexus-r21-mera-submission-evidence/1","created_at":time.time(),"git_commit":a.git_commit,
      "python":platform.python_version(),"platform":platform.platform(),"results_root":str(results),
      "files":[{"path":str(f.relative_to(results)),"bytes":f.stat().st_size,"sha256":sha(f)} for f in sorted(files)],
      "model_manifest":json.loads(Path(a.model_manifest).read_text()),"protocol":json.loads(Path(a.protocol).read_text()),
      "claim_boundary":"This package is a reproducibility and submission artifact, not an official MERA score."}
    temp=out.with_suffix(''); temp.mkdir(parents=True,exist_ok=True)
    (temp/'REPRODUCIBILITY_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    for f in files:
        dst=temp/'results'/f.relative_to(results); dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(f,dst)
    out.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for f in sorted(temp.rglob('*')):
            if f.is_file(): z.write(f,f.relative_to(temp))
    print(json.dumps({"output":str(out),"bytes":out.stat().st_size,"sha256":sha(out),"files":len(files)},indent=2)); return 0
if __name__=='__main__': raise SystemExit(main())
