# NEXUS R2.1 — Qwen3-14B Verified Intelligence

R2.1 preserves the authority-first architecture of R2.0 and replaces the
0.5B surface cortex with the official Qwen3-14B Q4_K_M checkpoint.

## Authority order

1. Exact Router v2
2. Formal multi-rule proof
3. Session SPO memory
4. Epistemic/uncertainty gate
5. Source-bound GraphRAG claim verifier
6. Qwen3-14B language proposal

Qwen3 is never allowed to overwrite exact, formal, memory or verified graph
decisions. Its open-world response is unverified unless every structured SPO
claim passes trusted-source verification.

## Implemented in this branch

- Safe AST exact arithmetic: powers, parentheses, unary signs, decimal comma.
- Adversarial-prefix stripping without treating identifiers such as `Зета-404`
  as arithmetic.
- Universal SQLite subject–predicate–object memory with aliases, confidence,
  status, provenance and conflict tracking.
- Multiple implications and facts in one message, forward modus ponens and
  rejection of invalid converse inference.
- Russian rule extraction for `causes`, `requires`, `contradicts`, `supports`,
  `enables`, `inhibits`, `precedes` and `part_of`.
- Hybrid GraphRAG: BM25, deterministic word/character hash vectors and graph
  expansion.
- Claim-level verification: one source with trust >= 0.90 or two independent
  sources with trust >= 0.70, with no contradictory evidence.
- Persistent llama-server backend and OpenAI-compatible NEXUS endpoint.
- Per-request session isolation for blind benchmark execution.

## Current evidence

- Unit/regression: **28/28**
- Preregistered Alpha Core: **49/49**
- Protected authority violations: **0**

These are local architecture tests. They are not a MERA score and not an
open-world assessment of Qwen3-14B.

## Official model

- Repository: `Qwen/Qwen3-14B-GGUF`
- File: `Qwen3-14B-Q4_K_M.gguf`
- Expected SHA-256:
  `500a8806e85ee9c83f3ae08420295592451379b4f8cf2d0f41c15dffeb6b81f0`
- License: Apache-2.0

## MERA protocol

`scripts/run_mera_v12_generative.sh` pins the official
`MERA-Evaluation/MERA` repository to commit
`2a537ddd0d1e7b10fadfb0ee193aa1e211cfb169`, runs the NEXUS authority server
through the OpenAI-compatible interface, and creates a generative submission
ZIP. The external blind score is available only after uploading that ZIP to the
official MERA platform.

## Hardware boundary

The 9 GB Q4_K_M weights cannot be honestly benchmarked in the current ~6 GB RAM
execution environment. Model checksum relay and source integration can run
here; actual 14B inference requires a larger machine, preferably at least
16 GB usable RAM or suitable GPU memory.
