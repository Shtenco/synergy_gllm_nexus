from pathlib import Path
from nexus_r21.relation_extractor_v2 import CharNGramNB, RelationExtractorV2

MODEL=Path(__file__).parents[1]/'nexus_r21/relation_model_v2.json'

def test_rule_extracts_multiple_relations():
    ext=RelationExtractorV2()
    rows=ext.extract("Лог проверки противоречит отчёту. Обучение модели требует данных.")
    assert [(r.relation,r.subject,r.object) for r in rows] == [
        ('contradicts','Лог проверки','отчёту'),
        ('requires','Обучение модели','данных'),
    ]

def test_trained_classifier_loads_and_identifies_classes():
    model=CharNGramNB.load(MODEL)
    pred1,_=model.predict('этот результат несовместим с заявленной гипотезой')
    pred2,_=model.predict('запуск системы невозможен без памяти')
    assert pred1=='contradicts'
    assert pred2=='requires'
