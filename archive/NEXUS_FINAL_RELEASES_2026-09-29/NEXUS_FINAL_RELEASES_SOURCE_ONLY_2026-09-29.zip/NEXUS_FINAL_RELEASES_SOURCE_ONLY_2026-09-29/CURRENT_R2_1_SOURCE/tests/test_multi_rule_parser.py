from nexus_r21.multi_rule_parser import MultiRuleParser


def test_multiple_rules_in_one_message():
    parser = MultiRuleParser()
    result = parser.parse_and_prove(
        "Если А, то Б. Если Б, то В. Если В, то Г. А. Следовательно, Г."
    )
    assert result.entailed
    assert [s.proposition for s in result.path] == ["а", "б", "в", "г"]


def test_multiple_facts_and_rules():
    parser = MultiRuleParser()
    parsed = parser.parse(
        "Если датчик активен, то контроллер получает сигнал. "
        "Если контроллер получает сигнал, то клапан открывается. "
        "Датчик активен. Температура высокая."
    )
    result = parser.prove(parsed, "клапан открывается")
    assert result.entailed
    assert "температура высокая" in result.derived


def test_affirming_consequent_is_blocked():
    parser = MultiRuleParser()
    parsed = parser.parse("Если сервер выключен, то API недоступен. API недоступен.")
    result = parser.prove(parsed, "сервер выключен")
    assert not result.entailed
    assert "не следует" in result.explanation


def test_explicit_negative_contradiction():
    parser = MultiRuleParser()
    parsed = parser.parse("Если А, то Б. А. не Б.")
    result = parser.prove(parsed, "Б")
    assert result.entailed and result.contradiction
