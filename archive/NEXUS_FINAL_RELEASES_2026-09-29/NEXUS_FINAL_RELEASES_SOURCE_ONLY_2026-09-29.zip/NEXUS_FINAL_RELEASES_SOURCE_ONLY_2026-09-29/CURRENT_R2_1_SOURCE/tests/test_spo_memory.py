from nexus_r21.spo_memory import SPOMemory, MemoryQuery


def test_arbitrary_attribute_roundtrip(tmp_path):
    mem = SPOMemory(tmp_path / "memory.sqlite")
    mem.add_fact("проект", "name", "Север", object_type="proper_name", source="session", provenance={"message": 1})
    fact = mem.answer_attribute("проекта", "name")
    assert fact is not None
    assert fact.object == "Север"
    assert fact.provenance["message"] == 1


def test_case_form_recall(tmp_path):
    mem = SPOMemory(tmp_path / "memory.sqlite")
    mem.add_fact("задержка оплаты", "causes", "кассовый разрыв", source="user")
    facts = mem.query(MemoryQuery(text="Что связано с кассовым разрывом?"))
    assert facts and facts[0].predicate == "causes"


def test_multiple_predicates_and_types(tmp_path):
    mem = SPOMemory(tmp_path / "memory.sqlite")
    mem.add_fact("обучение модели", "requires", "данные", subject_type="process", object_type="resource")
    mem.add_fact("обучение модели", "requires", "вычислительные ресурсы", subject_type="process", object_type="resource")
    facts = mem.query(subject="обучение модели", predicate="requires")
    assert {f.object for f in facts} == {"данные", "вычислительные ресурсы"}


def test_functional_conflict(tmp_path):
    mem = SPOMemory(tmp_path / "memory.sqlite")
    first = mem.add_fact("проект", "name", "Север")
    second = mem.add_fact("проект", "name", "Юг")
    assert mem.get_fact(first.id).status == "conflict"
    assert mem.get_fact(second.id).status == "conflict"
    assert mem.count()["conflicts"] == 1
