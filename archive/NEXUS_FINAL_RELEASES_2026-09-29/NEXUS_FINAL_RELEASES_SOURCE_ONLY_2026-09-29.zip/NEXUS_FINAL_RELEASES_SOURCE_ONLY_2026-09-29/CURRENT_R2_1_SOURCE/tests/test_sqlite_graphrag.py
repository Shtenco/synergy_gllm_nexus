import json
from pathlib import Path
from nexus_r21.sqlite_graphrag import SQLiteGraphRAG, simhash64, vector_similarity

def doc(uri,trust,text):
    return {"title":uri,"uri":uri,"publisher":"test","trust_score":trust,"license":"CC0","retrieved_at":"2026-08-04","text":text}

def test_sqlite_ingest_retrieve_and_high_trust_verify(tmp_path:Path):
    rag=SQLiteGraphRAG(tmp_path/'corpus.sqlite')
    rag.ingest_document(doc('https://a',.95,'Вода требует кислород? Нет. Охлаждение требует энергию.'))
    rows=rag.retrieve('Что требует охлаждение?')
    assert rows and rows[0].source_id
    check=rag.verify_claim('Охлаждение','requires','энергию')
    assert check.supported

def test_medium_quorum_and_no_retrieval_as_verification(tmp_path:Path):
    rag=SQLiteGraphRAG(tmp_path/'corpus.sqlite')
    rag.ingest_document(doc('https://a',.75,'Для запуска модели необходима память.'))
    rag.ingest_document(doc('https://b',.75,'Для запуска модели необходима память. Это подтверждено вторым независимым документом.'))
    assert rag.verify_claim('запуска модели','requires','память').supported
    packet=rag.evidence_packet('память')
    assert packet['evidence_available'] and not packet['verified']

def test_simhash():
    a=simhash64('графовая память и причинный вывод')
    b=simhash64('причинный вывод и графовая память')
    c=simhash64('рецепт яблочного пирога')
    assert vector_similarity(a,b)>vector_similarity(a,c)
