from nexus_r21.graphrag import VerifiedGraphRAG
from nexus_r21.spo_memory import SPOMemory


def test_retrieval_keeps_provenance_and_trust(tmp_path):
    mem=SPOMemory(tmp_path/'g.sqlite')
    rag=VerifiedGraphRAG(mem)
    sid=rag.register_source(title='Техническая документация',uri='https://example.org/spec',publisher='Example Standards',trust_score=.95,license='CC-BY',retrieved_at='2026-08-04')
    rag.ingest_text(sid,'Для обучения модели необходимы данные. Обучение модели требует вычислительных ресурсов.')
    packet=rag.evidence_packet('Что требуется для обучения модели?')
    assert packet['evidence_available']
    assert not packet['verified']  # retrieval alone is never verification
    assert packet['evidence'][0]['uri']=='https://example.org/spec'
    assert packet['evidence'][0]['trust_score']==.95
    facts=mem.query(subject='обучение модели',predicate='requires')
    assert {f.object for f in facts}=={'данные','вычислительных ресурсов'}


def test_high_trust_claim_verification(tmp_path):
    mem=SPOMemory(tmp_path/'g.sqlite')
    rag=VerifiedGraphRAG(mem)
    sid=rag.register_source(title='Техническая документация',uri='https://example.org/spec',publisher='Example Standards',trust_score=.95,license='CC-BY',retrieved_at='2026-08-04')
    rag.ingest_text(sid,'Обучение модели требует данных.')
    verdict=rag.verify_claims([{'subject':'обучение модели','predicate':'requires','object':'данных'}])
    assert verdict['verified']
    assert verdict['supported_count']==1


def test_two_medium_sources_form_quorum(tmp_path):
    mem=SPOMemory(tmp_path/'g.sqlite')
    rag=VerifiedGraphRAG(mem)
    for i in (1,2):
        sid=rag.register_source(title=f'Источник {i}',uri=f'https://source{i}.example/spec',publisher=f'Publisher {i}',trust_score=.8,license='CC-BY',retrieved_at='2026-08-04')
        rag.ingest_text(sid,'Нагрузка вызывает нагрев.')
    verdict=rag.verify_claims([{'subject':'нагрузка','predicate':'causes','object':'нагрев'}])
    assert verdict['verified']
    assert len(verdict['checks'][0]['source_ids'])==2


def test_low_trust_source_is_filtered(tmp_path):
    mem=SPOMemory(tmp_path/'g.sqlite')
    rag=VerifiedGraphRAG(mem)
    sid=rag.register_source(title='Слух',uri='https://bad.example/post',publisher='Unknown',trust_score=.2,license='unknown',retrieved_at='2026-08-04')
    rag.ingest_text(sid,'Слух противоречит фактам.')
    assert rag.retrieve('слух факты',min_trust=.5)==[]
    verdict=rag.verify_claims([{'subject':'слух','predicate':'contradicts','object':'факты'}])
    assert not verdict['verified']
