from __future__ import annotations

import json
import random
from collections import defaultdict
from pathlib import Path

from nexus_r21.relation_extractor_v2 import CharNGramNB, RELATIONS

TEMPLATES = {
    "causes": ["{a} вызывает {b}", "{a} приводит к {b}", "из-за {a} возникает {b}", "{a} становится причиной {b}"],
    "enables": ["{a} позволяет {b}", "{a} обеспечивает {b}", "{a} дает возможность {b}", "{a} усиливает {b}"],
    "inhibits": ["{a} снижает {b}", "{a} подавляет {b}", "{a} блокирует {b}", "{a} предотвращает {b}"],
    "supports": ["{a} подтверждает {b}", "{a} поддерживает {b}", "{a} согласуется с {b}", "{a} свидетельствует в пользу {b}"],
    "contradicts": ["{a} противоречит {b}", "{a} опровергает {b}", "{a} несовместимо с {b}", "{a} расходится с {b}"],
    "requires": ["{a} требует {b}", "{a} нуждается в {b}", "{a} невозможно без {b}", "{a} зависит от {b}"],
    "precedes": ["{a} предшествует {b}", "{a} происходит до {b}", "сначала {a}, затем {b}"],
    "part_of": ["{a} является частью {b}", "{a} входит в {b}", "{a} состоит в {b}"],
    "other": ["{a} рядом с {b}", "{a} и {b} упомянуты вместе", "между {a} и {b} есть сходство", "{a} описывает {b}"],
}
A = ["дефицит охлаждения", "лог проверки", "обучение модели", "резервный канал", "повышение нагрузки", "новый модуль", "эксперимент", "сервис", "команда", "документ"]
B = ["перегрев", "утверждение", "данные", "потерю связи", "очередь", "запуск", "гипотезу", "базу данных", "решение", "архитектуру"]


def build(seed=210814, per_template=24):
    rng = random.Random(seed)
    rows=[]
    for label, templates in TEMPLATES.items():
        for template in templates:
            for _ in range(per_template):
                a,b=rng.choice(A),rng.choice(B)
                if a==b: b=rng.choice(B)
                rows.append((template.format(a=a,b=b), label))
    rng.shuffle(rows)
    return rows


def main():
    rows=build()
    cut=int(len(rows)*0.8)
    train,test=rows[:cut],rows[cut:]
    model=CharNGramNB(alpha=0.35).fit([x for x,_ in train],[y for _,y in train])
    correct=0
    per=defaultdict(lambda:[0,0])
    mistakes=[]
    for text,label in test:
        pred,conf=model.predict(text)
        per[label][1]+=1
        if pred==label:
            correct+=1; per[label][0]+=1
        else:
            mistakes.append({"text":text,"label":label,"pred":pred,"confidence":conf})
    out=Path('/mnt/data/nexus_r21_work')
    model.save(out/'nexus_r21/relation_model_v2.json')
    report={
        "format":"nexus-r21-relation-training/1",
        "seed":210814,
        "train_examples":len(train),
        "test_examples":len(test),
        "accuracy":correct/len(test),
        "per_class":{k:{"correct":v[0],"total":v[1],"accuracy":v[0]/v[1]} for k,v in sorted(per.items())},
        "mistakes":mistakes[:30],
        "claim_boundary":"Synthetic multilingual-pattern curriculum; verifies the trained contradicts/requires classifier path, not unrestricted open-world extraction."
    }
    (out/'RELATION_TRAINING_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({"accuracy":report['accuracy'],"train":len(train),"test":len(test)},ensure_ascii=False))

if __name__=='__main__': main()
