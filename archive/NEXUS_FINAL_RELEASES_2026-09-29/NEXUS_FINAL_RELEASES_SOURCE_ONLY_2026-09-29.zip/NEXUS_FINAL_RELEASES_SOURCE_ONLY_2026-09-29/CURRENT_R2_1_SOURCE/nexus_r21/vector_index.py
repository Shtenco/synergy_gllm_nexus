from __future__ import annotations

import hashlib
import json
import math
import re
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable

_TOKEN_RE = re.compile(r"[A-Za-zА-Яа-яЁё0-9_-]+")


@dataclass(frozen=True)
class VectorHit:
    item_id: str
    score: float


class HashVectorIndex:
    """Dependency-free deterministic vector index.

    It combines word features and character n-grams in a signed hashing space.
    This is not a replacement for a trained embedding model, but it provides a
    reproducible vector-retrieval baseline and an adapter boundary for later
    Qwen3-Embedding or other production embeddings.
    """

    FORMAT = "nexus-hash-vector-index/1"

    def __init__(self, dimensions: int = 2048, char_min: int = 3, char_max: int = 5):
        if dimensions < 128:
            raise ValueError("dimensions must be >= 128")
        self.dimensions = int(dimensions)
        self.char_min = int(char_min)
        self.char_max = int(char_max)
        self.vectors: dict[str, dict[int, float]] = {}

    @staticmethod
    def _normalize(text: str) -> str:
        text = text.casefold().replace("ё", "е")
        text = re.sub(r"\s+", " ", text).strip()
        return text

    def _features(self, text: str) -> Iterable[tuple[str, float]]:
        norm = self._normalize(text)
        for token in _TOKEN_RE.findall(norm):
            yield "w:" + token, 2.0
        padded = "^" + norm + "$"
        for n in range(self.char_min, self.char_max + 1):
            for i in range(max(0, len(padded) - n + 1)):
                yield f"c{n}:" + padded[i:i+n], 1.0

    def encode(self, text: str) -> dict[int, float]:
        vector: dict[int, float] = {}
        for feature, weight in self._features(text):
            digest = hashlib.blake2b(feature.encode("utf-8"), digest_size=16).digest()
            index = int.from_bytes(digest[:8], "little") % self.dimensions
            sign = 1.0 if digest[8] & 1 else -1.0
            vector[index] = vector.get(index, 0.0) + sign * weight
        norm = math.sqrt(sum(v * v for v in vector.values()))
        if norm:
            vector = {i: v / norm for i, v in vector.items()}
        return vector

    @staticmethod
    def cosine(a: dict[int, float], b: dict[int, float]) -> float:
        if len(a) > len(b):
            a, b = b, a
        return sum(value * b.get(index, 0.0) for index, value in a.items())

    def upsert(self, item_id: str, text: str) -> None:
        self.vectors[str(item_id)] = self.encode(text)

    def remove(self, item_id: str) -> None:
        self.vectors.pop(str(item_id), None)

    def search(self, query: str, top_k: int = 20, min_score: float = 0.0) -> list[VectorHit]:
        q = self.encode(query)
        rows = [
            VectorHit(item_id, self.cosine(q, vector))
            for item_id, vector in self.vectors.items()
        ]
        rows = [row for row in rows if row.score >= min_score]
        rows.sort(key=lambda row: (row.score, row.item_id), reverse=True)
        return rows[:top_k]

    def save(self, path: str | Path) -> None:
        payload = {
            "format": self.FORMAT,
            "dimensions": self.dimensions,
            "char_min": self.char_min,
            "char_max": self.char_max,
            "vectors": {
                item_id: {str(index): value for index, value in vector.items()}
                for item_id, vector in self.vectors.items()
            },
        }
        Path(path).write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "HashVectorIndex":
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        if payload.get("format") != cls.FORMAT:
            raise ValueError("unsupported vector index format")
        index = cls(payload["dimensions"], payload["char_min"], payload["char_max"])
        index.vectors = {
            item_id: {int(key): float(value) for key, value in vector.items()}
            for item_id, vector in payload["vectors"].items()
        }
        return index
