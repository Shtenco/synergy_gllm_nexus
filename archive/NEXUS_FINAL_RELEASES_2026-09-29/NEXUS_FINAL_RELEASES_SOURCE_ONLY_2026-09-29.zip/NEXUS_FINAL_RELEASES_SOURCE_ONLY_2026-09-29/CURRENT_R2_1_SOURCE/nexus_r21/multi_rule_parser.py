from __future__ import annotations

import re
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Iterable

_SENTENCE_SPLIT = re.compile(r"(?<=[.!?;])\s+|\n+")
_RULE_RE = re.compile(r"^\s*если\s+(.+?)\s*,?\s*то\s+(.+?)\s*[.!?;]*$", re.I)
_QUERY_RE = re.compile(r"^(?:следовательно\s*,?\s*)?(.+?)\s*[?!.]*$", re.I)
_NEG_PREFIX = re.compile(r"^(?:не|нет)\s+", re.I)


def normalize_prop(text: str) -> str:
    text = text.casefold().replace("ё", "е")
    text = re.sub(r"^(?:следовательно|значит|таким образом)\s*,?\s*", "", text)
    text = re.sub(r"[.!?;,:]+$", "", text.strip())
    text = re.sub(r"\s+", " ", text)
    return text


@dataclass(frozen=True)
class Rule:
    antecedent: str
    consequent: str
    source_sentence: str


@dataclass(frozen=True)
class ProofStep:
    proposition: str
    kind: str  # fact | modus_ponens
    rule: Rule | None
    parents: tuple[str, ...]


@dataclass(frozen=True)
class ParsedKnowledge:
    rules: tuple[Rule, ...]
    facts: tuple[str, ...]
    query: str | None


@dataclass(frozen=True)
class ProofResult:
    query: str
    entailed: bool
    contradiction: bool
    path: tuple[ProofStep, ...]
    derived: tuple[str, ...]
    explanation: str


class MultiRuleParser:
    """Parse multiple Russian implication rules and facts from one message.

    The proof engine implements explicit facts and forward modus ponens only.
    It deliberately does not infer an antecedent from a consequent and therefore
    blocks affirming-the-consequent errors.
    """

    def split_sentences(self, text: str) -> list[str]:
        # Rules often use a period, but short symbolic chains may be separated by semicolons.
        normalized = text.replace(";", "; ")
        pieces = _SENTENCE_SPLIT.split(normalized)
        out: list[str] = []
        for piece in pieces:
            for sub in re.split(r"(?<=;)\s+", piece):
                sub = sub.strip()
                if sub:
                    out.append(sub)
        return out

    def parse(self, text: str, *, query: str | None = None) -> ParsedKnowledge:
        rules: list[Rule] = []
        facts: list[str] = []
        inferred_query = normalize_prop(query) if query else None
        sentences = self.split_sentences(text)
        for index, sentence in enumerate(sentences):
            clean = sentence.strip()
            match = _RULE_RE.match(clean)
            if match:
                antecedent = normalize_prop(match.group(1))
                consequent = normalize_prop(match.group(2))
                if antecedent and consequent:
                    rules.append(Rule(antecedent, consequent, clean))
                continue
            # Last question or explicit "Следовательно" is treated as query.
            if clean.endswith("?") or re.match(r"^\s*(?:следовательно|значит)\b", clean, re.I):
                qmatch = _QUERY_RE.match(clean)
                if qmatch:
                    inferred_query = normalize_prop(qmatch.group(1))
                continue
            fact = normalize_prop(clean)
            if fact:
                facts.append(fact)
        return ParsedKnowledge(tuple(rules), tuple(dict.fromkeys(facts)), inferred_query)

    @staticmethod
    def negate(prop: str) -> str:
        prop = normalize_prop(prop)
        if prop.startswith("не "):
            return prop[3:]
        return "не " + prop

    def prove(self, parsed: ParsedKnowledge, query: str | None = None) -> ProofResult:
        target = normalize_prop(query or parsed.query or "")
        if not target:
            raise ValueError("query is missing")
        known: dict[str, ProofStep] = {
            fact: ProofStep(fact, "fact", None, ()) for fact in parsed.facts
        }
        rules_by_ant: dict[str, list[Rule]] = defaultdict(list)
        for rule in parsed.rules:
            rules_by_ant[rule.antecedent].append(rule)
        queue = deque(known)
        while queue:
            current = queue.popleft()
            for rule in rules_by_ant.get(current, ()):
                if rule.consequent in known:
                    continue
                known[rule.consequent] = ProofStep(
                    rule.consequent, "modus_ponens", rule, (current,)
                )
                queue.append(rule.consequent)

        contradiction_target = self.negate(target)
        entailed = target in known
        contradiction = contradiction_target in known
        path: list[ProofStep] = []
        if entailed:
            cursor = target
            visited = set()
            while cursor in known and cursor not in visited:
                visited.add(cursor)
                step = known[cursor]
                path.append(step)
                if not step.parents:
                    break
                cursor = step.parents[0]
            path.reverse()
        if entailed and contradiction:
            explanation = f"Вывод {target!r} получен, но в базе также выведено его отрицание; знания противоречивы."
        elif entailed:
            chain = " → ".join(step.proposition for step in path)
            explanation = f"Доказано прямым modus ponens: {chain}."
        elif contradiction:
            explanation = f"Запрос {target!r} не доказан; доказано противоположное утверждение {contradiction_target!r}."
        else:
            explanation = (
                f"Запрос {target!r} не следует из данных правил и фактов. "
                "Обратный вывод из следствия к основанию не применяется."
            )
        return ProofResult(
            query=target,
            entailed=entailed,
            contradiction=contradiction,
            path=tuple(path),
            derived=tuple(known),
            explanation=explanation,
        )

    def parse_and_prove(self, text: str, *, query: str | None = None) -> ProofResult:
        parsed = self.parse(text, query=query)
        return self.prove(parsed, query=query)
