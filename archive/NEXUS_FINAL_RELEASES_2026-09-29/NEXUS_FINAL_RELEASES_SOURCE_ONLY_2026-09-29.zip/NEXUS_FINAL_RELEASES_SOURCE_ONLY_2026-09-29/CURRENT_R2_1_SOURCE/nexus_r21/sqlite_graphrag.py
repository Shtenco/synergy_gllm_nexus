from __future__ import annotations

import hashlib
import json
import math
import re
import sqlite3
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, Sequence

from .graphrag import ClaimCheck, VerifiedGraphRAG
from .relation_extractor_v2 import RelationExtractorV2
from .spo_memory import normalize_text, search_terms


@dataclass(frozen=True)
class SQLiteEvidence:
    chunk_id: str
    source_id: str
    title: str
    uri: str
    text: str
    lexical_score: float
    vector_score: float
    graph_score: float
    trust_score: float
    final_score: float
    matched_facts: tuple[str, ...]


def simhash64(text: str) -> int:
    weights = [0] * 64
    for token in search_terms(text):
        digest = hashlib.blake2b(token.encode("utf-8"), digest_size=8).digest()
        value = int.from_bytes(digest, "little")
        for bit in range(64):
            weights[bit] += 1 if value & (1 << bit) else -1
    out = 0
    for bit, weight in enumerate(weights):
        if weight >= 0:
            out |= 1 << bit
    return out


def vector_similarity(a: int, b: int) -> float:
    a &= (1 << 64) - 1
    b &= (1 << 64) - 1
    return 1.0 - ((a ^ b).bit_count() / 64.0)


def sqlite_i64(value: int) -> int:
    value &= (1 << 64) - 1
    return value - (1 << 64) if value >= (1 << 63) else value


class SQLiteGraphRAG:
    """Streaming, disk-backed GraphRAG for large corpora.

    Retrieval uses SQLite FTS5 for candidate generation and a deterministic
    64-bit semantic sketch for vector reranking. Claims remain source-bound and
    require either one high-trust source or two independent medium-trust sources.
    """

    FORMAT = "nexus-r21-sqlite-graphrag/1"

    def __init__(self, path: str | Path, extractor: RelationExtractorV2 | None = None):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(self.path)
        self.db.row_factory = sqlite3.Row
        self.extractor = extractor or RelationExtractorV2()
        self._init_schema()

    def _init_schema(self) -> None:
        self.db.executescript(
            """
            PRAGMA journal_mode=WAL;
            PRAGMA synchronous=NORMAL;
            PRAGMA temp_store=MEMORY;
            PRAGMA cache_size=-131072;
            CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS sources(
              source_id TEXT PRIMARY KEY, title TEXT NOT NULL, uri TEXT NOT NULL UNIQUE,
              publisher TEXT NOT NULL, trust_score REAL NOT NULL, license TEXT NOT NULL,
              retrieved_at TEXT NOT NULL, content_sha256 TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS chunks(
              rowid INTEGER PRIMARY KEY AUTOINCREMENT, chunk_id TEXT NOT NULL UNIQUE,
              source_id TEXT NOT NULL, chunk_index INTEGER NOT NULL, text TEXT NOT NULL,
              text_sha256 TEXT NOT NULL UNIQUE, simhash INTEGER NOT NULL,
              FOREIGN KEY(source_id) REFERENCES sources(source_id)
            );
            CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(
              text, content='chunks', content_rowid='rowid', tokenize='unicode61 remove_diacritics 2'
            );
            CREATE TRIGGER IF NOT EXISTS chunks_ai AFTER INSERT ON chunks BEGIN
              INSERT INTO chunks_fts(rowid,text) VALUES(new.rowid,new.text);
            END;
            CREATE TRIGGER IF NOT EXISTS chunks_ad AFTER DELETE ON chunks BEGIN
              INSERT INTO chunks_fts(chunks_fts,rowid,text) VALUES('delete',old.rowid,old.text);
            END;
            CREATE TABLE IF NOT EXISTS claims(
              claim_id TEXT PRIMARY KEY, source_id TEXT NOT NULL, chunk_id TEXT NOT NULL,
              subject TEXT NOT NULL, subject_norm TEXT NOT NULL,
              predicate TEXT NOT NULL, predicate_norm TEXT NOT NULL,
              object TEXT NOT NULL, object_norm TEXT NOT NULL,
              confidence REAL NOT NULL, status TEXT NOT NULL,
              provenance_json TEXT NOT NULL,
              FOREIGN KEY(source_id) REFERENCES sources(source_id)
            );
            CREATE INDEX IF NOT EXISTS claims_spo_idx ON claims(subject_norm,predicate_norm,object_norm,status);
            CREATE INDEX IF NOT EXISTS claims_source_idx ON claims(source_id,status);
            """
        )
        self.db.execute("INSERT OR REPLACE INTO meta VALUES('format',?)", (self.FORMAT,))
        self.db.commit()

    @staticmethod
    def _source_id(uri: str) -> str:
        return "src_" + hashlib.sha256(uri.encode()).hexdigest()[:20]

    @staticmethod
    def _chunk_id(source_id: str, index: int, text: str) -> str:
        return "chk_" + hashlib.sha256(f"{source_id}\0{index}\0{text}".encode()).hexdigest()[:24]

    def ingest_document(self, row: dict, *, batch_commit: bool = True) -> dict:
        required = {"title","uri","publisher","trust_score","license","retrieved_at","text"}
        missing = required - set(row)
        if missing:
            raise ValueError(f"missing fields: {sorted(missing)}")
        text = str(row["text"]).strip()
        uri = str(row["uri"]).strip()
        trust = float(row["trust_score"])
        if not text or not uri or not 0 <= trust <= 1:
            raise ValueError("invalid text, uri or trust_score")
        source_id = self._source_id(uri)
        content_sha = hashlib.sha256(text.encode()).hexdigest()
        self.db.execute(
            "INSERT OR IGNORE INTO sources VALUES(?,?,?,?,?,?,?,?)",
            (source_id,row["title"],uri,row["publisher"],trust,row["license"],row["retrieved_at"],content_sha),
        )
        chunks_added = claims_added = 0
        for index, chunk_text in enumerate(VerifiedGraphRAG.chunk_text(text)):
            chunk_id = self._chunk_id(source_id,index,chunk_text)
            text_sha = hashlib.sha256(chunk_text.encode()).hexdigest()
            cur = self.db.execute(
                "INSERT OR IGNORE INTO chunks(chunk_id,source_id,chunk_index,text,text_sha256,simhash) VALUES(?,?,?,?,?,?)",
                (chunk_id,source_id,index,chunk_text,text_sha,sqlite_i64(simhash64(chunk_text))),
            )
            if cur.rowcount == 0:
                continue
            chunks_added += 1
            for rel in self.extractor.extract(chunk_text):
                claim_id = "clm_" + hashlib.sha256(
                    f"{source_id}\0{chunk_id}\0{normalize_text(rel.subject)}\0{normalize_text(rel.relation)}\0{normalize_text(rel.object)}".encode()
                ).hexdigest()[:28]
                status = "verified" if rel.extractor == "rule" else "candidate"
                self.db.execute(
                    "INSERT OR IGNORE INTO claims VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                    (claim_id,source_id,chunk_id,rel.subject,normalize_text(rel.subject),rel.relation,
                     normalize_text(rel.relation).replace(' ','_'),rel.object,normalize_text(rel.object),
                     min(0.99, rel.confidence * trust),status,
                     json.dumps({"uri":uri,"sentence":rel.sentence,"extractor":rel.extractor},ensure_ascii=False),),
                )
                claims_added += 1
        if batch_commit:
            self.db.commit()
        return {"source_id":source_id,"chunks_added":chunks_added,"claims_added":claims_added,"content_sha256":content_sha}

    def ingest_jsonl(self, path: str | Path, *, min_trust: float = 0.5, batch_size: int = 100) -> dict:
        accepted = rejected = chunks = claims = 0
        started = time.perf_counter()
        with Path(path).open(encoding="utf-8") as fh:
            for line_no, line in enumerate(fh, start=1):
                if not line.strip():
                    continue
                row = json.loads(line)
                if float(row.get("trust_score",0)) < min_trust:
                    rejected += 1
                    continue
                result = self.ingest_document(row,batch_commit=False)
                accepted += 1; chunks += result["chunks_added"]; claims += result["claims_added"]
                if accepted % batch_size == 0:
                    self.db.commit()
        self.db.commit()
        return {"accepted_sources":accepted,"rejected_sources":rejected,"chunks_added":chunks,
                "claims_added":claims,"elapsed_s":time.perf_counter()-started,"counts":self.count()}

    def count(self) -> dict[str,int]:
        return {name:int(self.db.execute(f"SELECT count(*) FROM {name}").fetchone()[0]) for name in ("sources","chunks","claims")}

    @staticmethod
    def _fts_query(query: str) -> str:
        terms = [re.sub(r'[^\w-]','',t) for t in search_terms(query)[:16]]
        return " OR ".join(f'"{t}"' for t in terms if t)

    def retrieve(self, query: str, *, top_k: int = 8, min_trust: float = 0.5) -> list[SQLiteEvidence]:
        fts = self._fts_query(query)
        if not fts:
            return []
        rows = self.db.execute(
            """SELECT c.chunk_id,c.source_id,c.text,c.simhash,s.title,s.uri,s.trust_score,
                      bm25(chunks_fts) AS rank
                 FROM chunks_fts JOIN chunks c ON c.rowid=chunks_fts.rowid
                 JOIN sources s ON s.source_id=c.source_id
                WHERE chunks_fts MATCH ? AND s.trust_score>=?
                ORDER BY rank LIMIT ?""",
            (fts,min_trust,max(64,top_k*12)),
        ).fetchall()
        qhash = simhash64(query)
        evidence=[]
        for row in rows:
            lexical = 1.0/(1.0+max(0.0,float(row["rank"])))
            vector = vector_similarity(qhash,int(row["simhash"]))
            facts = self.db.execute(
                "SELECT subject,predicate,object FROM claims WHERE chunk_id=? AND status='verified' LIMIT 20",
                (row["chunk_id"],),
            ).fetchall()
            matched=tuple(f"{r['subject']} --{r['predicate']}--> {r['object']}" for r in facts)
            final=0.55*lexical+0.30*vector+0.15*float(row["trust_score"])
            evidence.append(SQLiteEvidence(row["chunk_id"],row["source_id"],row["title"],row["uri"],row["text"],lexical,vector,0.0,float(row["trust_score"]),final,matched))
        evidence.sort(key=lambda x:(x.final_score,x.trust_score),reverse=True)
        return evidence[:top_k]

    def verify_claim(self, subject: str, predicate: str, object: str, *, high_trust: float=.90, medium_trust: float=.70, medium_source_quorum: int=2) -> ClaimCheck:
        sn=normalize_text(subject); pn=normalize_text(predicate).replace(' ','_'); on=normalize_text(object)
        rows=self.db.execute(
            """SELECT DISTINCT s.source_id,s.uri,s.trust_score,c.predicate_norm
                 FROM claims c JOIN sources s ON s.source_id=c.source_id
                WHERE c.status='verified' AND c.subject_norm=? AND c.object_norm=?""",
            (sn,on),
        ).fetchall()
        support=[r for r in rows if r["predicate_norm"]==pn]
        contra=[r for r in rows if r["predicate_norm"]=="contradicts" and pn!="contradicts"]
        high_ok=any(float(r["trust_score"])>=high_trust for r in support)
        medium_ok=sum(float(r["trust_score"])>=medium_trust for r in support)>=medium_source_quorum
        ordered=sorted(support,key=lambda r:(-float(r["trust_score"]),r["uri"]))
        reason="supported by high-trust source" if high_ok else "supported by independent medium-trust sources" if medium_ok else "insufficient independent trusted support"
        if contra: reason += "; contradictory evidence exists"
        return ClaimCheck(subject,predicate,object,high_ok or medium_ok,bool(contra),tuple(r["source_id"] for r in ordered),tuple(r["uri"] for r in ordered),max((float(r["trust_score"]) for r in support),default=0.0),reason)

    def verify_claims(self, claims: Sequence[dict]) -> dict:
        checks=[]
        for claim in claims:
            if isinstance(claim,dict) and all(str(claim.get(k,'')).strip() for k in ("subject","predicate","object")):
                checks.append(self.verify_claim(str(claim["subject"]),str(claim["predicate"]),str(claim["object"])))
        verified=bool(checks) and all(c.supported and not c.contradicted for c in checks)
        return {"verified":verified,"checks":[asdict(c) for c in checks],"claim_count":len(checks),
                "supported_count":sum(c.supported for c in checks),"contradicted_count":sum(c.contradicted for c in checks),
                "claim_boundary":"Every claim requires source-bound quorum and no contradictory evidence."}

    def evidence_packet(self, query: str, *, top_k: int=8, claims: Sequence[dict] | None=None) -> dict:
        rows=self.retrieve(query,top_k=top_k)
        verification=self.verify_claims(claims or []) if claims is not None else None
        return {"query":query,"evidence":[asdict(e) for e in rows],"evidence_available":bool(rows),
                "verified":bool(verification and verification["verified"]),"source_count":len({e.source_id for e in rows}),
                "claim_verification":verification,"claim_boundary":"Retrieval is not verification."}

    def write_manifest(self, path: str | Path, *, input_sha256: str | None=None) -> None:
        payload={"format":self.FORMAT,"database":self.path,"counts":self.count(),"input_sha256":input_sha256,
                 "retrieval":{"candidate_generation":"SQLite FTS5","vector_reranker":"64-bit deterministic SimHash"},
                 "verification":{"high_trust_single":.90,"medium_trust":.70,"medium_quorum":2,"retrieval_alone":False}}
        Path(path).write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8")
