from __future__ import annotations

import hashlib
import json
import re
import sqlite3
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, Sequence

_TOKEN_RE = re.compile(r"[A-Za-zА-Яа-яЁё0-9_-]+")


def normalize_text(text: str) -> str:
    return " ".join(_TOKEN_RE.findall(text.casefold().replace("ё", "е")))


def stem_token(token: str) -> str:
    token = token.casefold().replace("ё", "е")
    suffixes = (
        "иями", "ями", "ами", "ого", "его", "ому", "ему", "ыми", "ими",
        "иях", "ах", "ях", "ой", "ей", "ый", "ий", "ая", "яя", "ое", "ее",
        "ым", "им", "ом", "ем", "ую", "юю", "ов", "ев", "ам", "ям",
        "ами", "ями", "ы", "и", "а", "я", "у", "ю", "е",
    )
    for suffix in suffixes:
        if token.endswith(suffix) and len(token) - len(suffix) >= 4:
            return token[:-len(suffix)]
    return token


def search_terms(text: str) -> list[str]:
    stop = {"что", "как", "где", "когда", "кто", "это", "или", "для", "при", "про", "над", "под", "без"}
    out: list[str] = []
    for token in _TOKEN_RE.findall(text.casefold().replace("ё", "е")):
        if len(token) < 3 or token in stop:
            continue
        out.extend((token, stem_token(token)))
    return list(dict.fromkeys(out))


@dataclass(frozen=True)
class Entity:
    id: str
    canonical: str
    entity_type: str
    aliases: tuple[str, ...]
    attributes: dict


@dataclass(frozen=True)
class Fact:
    id: str
    subject: str
    predicate: str
    object: str
    subject_type: str
    object_type: str
    confidence: float
    status: str
    source: str
    provenance: dict
    valid_from: float | None
    valid_to: float | None
    created_at: float


@dataclass(frozen=True)
class MemoryQuery:
    subject: str | None = None
    predicate: str | None = None
    object: str | None = None
    text: str | None = None
    status: str | None = "verified"
    limit: int = 20


class SPOMemory:
    """Persistent universal subject-predicate-object memory with provenance.

    Facts never lose their original surface forms. Canonical entity IDs and aliases
    are used for retrieval, while confidence/status/provenance determine authority.
    """

    SCHEMA_VERSION = 2

    def __init__(self, path: str | Path = ":memory:"):
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(self.path)
        self.db.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self) -> None:
        self.db.executescript(
            """
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS entities(
                id TEXT PRIMARY KEY,
                canonical TEXT NOT NULL,
                normalized TEXT NOT NULL,
                entity_type TEXT NOT NULL,
                aliases_json TEXT NOT NULL,
                attributes_json TEXT NOT NULL,
                created_at REAL NOT NULL
            );
            CREATE UNIQUE INDEX IF NOT EXISTS entities_norm_type_idx
                ON entities(normalized, entity_type);
            CREATE TABLE IF NOT EXISTS aliases(
                alias_norm TEXT NOT NULL,
                entity_id TEXT NOT NULL,
                PRIMARY KEY(alias_norm, entity_id),
                FOREIGN KEY(entity_id) REFERENCES entities(id)
            );
            CREATE INDEX IF NOT EXISTS aliases_norm_idx ON aliases(alias_norm);
            CREATE TABLE IF NOT EXISTS facts(
                id TEXT PRIMARY KEY,
                subject_id TEXT NOT NULL,
                predicate TEXT NOT NULL,
                predicate_norm TEXT NOT NULL,
                object_id TEXT NOT NULL,
                confidence REAL NOT NULL,
                status TEXT NOT NULL,
                source TEXT NOT NULL,
                provenance_json TEXT NOT NULL,
                valid_from REAL,
                valid_to REAL,
                created_at REAL NOT NULL,
                FOREIGN KEY(subject_id) REFERENCES entities(id),
                FOREIGN KEY(object_id) REFERENCES entities(id)
            );
            CREATE INDEX IF NOT EXISTS facts_spo_idx
                ON facts(subject_id, predicate_norm, object_id);
            CREATE INDEX IF NOT EXISTS facts_status_idx ON facts(status);
            CREATE TABLE IF NOT EXISTS conflicts(
                id TEXT PRIMARY KEY,
                fact_a TEXT NOT NULL,
                fact_b TEXT NOT NULL,
                reason TEXT NOT NULL,
                created_at REAL NOT NULL
            );
            """
        )
        self.db.commit()

    @staticmethod
    def _entity_id(canonical: str, entity_type: str) -> str:
        payload = f"{normalize_text(canonical)}\0{entity_type.casefold()}"
        return "ent_" + hashlib.sha256(payload.encode()).hexdigest()[:24]

    @staticmethod
    def _fact_id(subject_id: str, predicate: str, object_id: str, source: str, valid_from: float | None) -> str:
        payload = f"{subject_id}\0{normalize_text(predicate)}\0{object_id}\0{source}\0{valid_from}"
        return "fact_" + hashlib.sha256(payload.encode()).hexdigest()[:28]

    def upsert_entity(
        self,
        canonical: str,
        entity_type: str = "concept",
        aliases: Iterable[str] = (),
        attributes: dict | None = None,
    ) -> str:
        canonical = canonical.strip()
        if not canonical:
            raise ValueError("entity canonical form is empty")
        entity_type = entity_type.strip().casefold() or "concept"
        entity_id = self._entity_id(canonical, entity_type)
        alias_set = {canonical, *[a.strip() for a in aliases if a.strip()]}
        row = self.db.execute("SELECT aliases_json,attributes_json FROM entities WHERE id=?", (entity_id,)).fetchone()
        current_aliases = set(json.loads(row["aliases_json"])) if row else set()
        current_attrs = json.loads(row["attributes_json"]) if row else {}
        alias_set |= current_aliases
        current_attrs.update(attributes or {})
        self.db.execute(
            "INSERT OR REPLACE INTO entities VALUES(?,?,?,?,?,?,?)",
            (
                entity_id, canonical, normalize_text(canonical), entity_type,
                json.dumps(sorted(alias_set), ensure_ascii=False),
                json.dumps(current_attrs, ensure_ascii=False, sort_keys=True),
                time.time(),
            ),
        )
        for alias in alias_set:
            norm = normalize_text(alias)
            self.db.execute("INSERT OR IGNORE INTO aliases VALUES(?,?)", (norm, entity_id))
            for term in search_terms(alias):
                self.db.execute("INSERT OR IGNORE INTO aliases VALUES(?,?)", (term, entity_id))
        self.db.commit()
        return entity_id

    def get_entity(self, entity_id: str) -> Entity:
        row = self.db.execute("SELECT * FROM entities WHERE id=?", (entity_id,)).fetchone()
        if row is None:
            raise KeyError(entity_id)
        return Entity(
            id=row["id"], canonical=row["canonical"], entity_type=row["entity_type"],
            aliases=tuple(json.loads(row["aliases_json"])), attributes=json.loads(row["attributes_json"]),
        )

    def resolve_entities(self, text: str, limit: int = 20) -> list[Entity]:
        norm = normalize_text(text)
        ids: list[str] = []
        exact = self.db.execute("SELECT entity_id FROM aliases WHERE alias_norm=?", (norm,)).fetchall()
        ids.extend(row[0] for row in exact)
        for term in search_terms(text):
            rows = self.db.execute(
                "SELECT entity_id FROM aliases WHERE alias_norm LIKE ? LIMIT ?",
                (f"%{term}%", limit),
            ).fetchall()
            ids.extend(row[0] for row in rows)
        seen = set()
        out = []
        for entity_id in ids:
            if entity_id in seen:
                continue
            seen.add(entity_id)
            out.append(self.get_entity(entity_id))
            if len(out) >= limit:
                break
        return out

    def add_fact(
        self,
        subject: str,
        predicate: str,
        object: str,
        *,
        subject_type: str = "concept",
        object_type: str = "concept",
        confidence: float = 1.0,
        status: str = "verified",
        source: str = "user",
        provenance: dict | None = None,
        valid_from: float | None = None,
        valid_to: float | None = None,
        subject_aliases: Iterable[str] = (),
        object_aliases: Iterable[str] = (),
    ) -> Fact:
        if not (0 <= confidence <= 1):
            raise ValueError("confidence must be in [0,1]")
        if status not in {"candidate", "verified", "conflict", "rejected"}:
            raise ValueError("unknown fact status")
        subject_id = self.upsert_entity(subject, subject_type, subject_aliases)
        object_id = self.upsert_entity(object, object_type, object_aliases)
        predicate_norm = normalize_text(predicate).replace(" ", "_")
        if not predicate_norm:
            raise ValueError("predicate is empty")
        fact_id = self._fact_id(subject_id, predicate_norm, object_id, source, valid_from)
        created = time.time()
        self.db.execute(
            "INSERT OR REPLACE INTO facts VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                fact_id, subject_id, predicate, predicate_norm, object_id, confidence,
                status, source, json.dumps(provenance or {}, ensure_ascii=False, sort_keys=True),
                valid_from, valid_to, created,
            ),
        )
        self.db.commit()
        self._detect_conflicts(fact_id)
        return self.get_fact(fact_id)

    def get_fact(self, fact_id: str) -> Fact:
        row = self.db.execute(
            """SELECT f.*, s.canonical subject, s.entity_type subject_type,
                      o.canonical object, o.entity_type object_type
               FROM facts f JOIN entities s ON s.id=f.subject_id
               JOIN entities o ON o.id=f.object_id WHERE f.id=?""",
            (fact_id,),
        ).fetchone()
        if row is None:
            raise KeyError(fact_id)
        return Fact(
            id=row["id"], subject=row["subject"], predicate=row["predicate"], object=row["object"],
            subject_type=row["subject_type"], object_type=row["object_type"],
            confidence=float(row["confidence"]), status=row["status"], source=row["source"],
            provenance=json.loads(row["provenance_json"]), valid_from=row["valid_from"],
            valid_to=row["valid_to"], created_at=float(row["created_at"]),
        )

    def _detect_conflicts(self, new_fact_id: str) -> None:
        row = self.db.execute("SELECT * FROM facts WHERE id=?", (new_fact_id,)).fetchone()
        if row is None or row["status"] == "rejected":
            return
        # Functional predicates should normally have a single current object.
        functional = {"name", "название", "equals", "equal_to", "located_at", "born_on", "version"}
        if row["predicate_norm"] not in functional:
            return
        others = self.db.execute(
            """SELECT id,object_id FROM facts
               WHERE subject_id=? AND predicate_norm=? AND id<>? AND status IN ('candidate','verified')""",
            (row["subject_id"], row["predicate_norm"], new_fact_id),
        ).fetchall()
        for other in others:
            if other["object_id"] == row["object_id"]:
                continue
            conflict_id = "conf_" + hashlib.sha256(f"{new_fact_id}\0{other['id']}".encode()).hexdigest()[:24]
            self.db.execute(
                "INSERT OR IGNORE INTO conflicts VALUES(?,?,?,?,?)",
                (conflict_id, other["id"], new_fact_id, "functional predicate has different objects", time.time()),
            )
            self.db.execute("UPDATE facts SET status='conflict' WHERE id IN (?,?)", (other["id"], new_fact_id))
        self.db.commit()

    def query(self, query: MemoryQuery | None = None, **kwargs) -> list[Fact]:
        query = query or MemoryQuery(**kwargs)
        conditions: list[str] = []
        params: list[object] = []
        if query.status:
            conditions.append("f.status=?")
            params.append(query.status)
        if query.predicate:
            conditions.append("f.predicate_norm LIKE ?")
            params.append(f"%{normalize_text(query.predicate).replace(' ', '_')}%")
        subject_ids = [e.id for e in self.resolve_entities(query.subject)] if query.subject else []
        object_ids = [e.id for e in self.resolve_entities(query.object)] if query.object else []
        text_ids = [e.id for e in self.resolve_entities(query.text)] if query.text else []
        if subject_ids:
            conditions.append("f.subject_id IN (%s)" % ",".join("?" * len(subject_ids)))
            params.extend(subject_ids)
        if object_ids:
            conditions.append("f.object_id IN (%s)" % ",".join("?" * len(object_ids)))
            params.extend(object_ids)
        if text_ids:
            placeholders = ",".join("?" * len(text_ids))
            conditions.append(f"(f.subject_id IN ({placeholders}) OR f.object_id IN ({placeholders}))")
            params.extend(text_ids)
            params.extend(text_ids)
        sql = """SELECT f.id FROM facts f"""
        if conditions:
            sql += " WHERE " + " AND ".join(conditions)
        sql += " ORDER BY f.confidence DESC, f.created_at DESC LIMIT ?"
        params.append(query.limit)
        ids = [row[0] for row in self.db.execute(sql, params).fetchall()]
        return [self.get_fact(fact_id) for fact_id in ids]

    def answer_attribute(self, subject: str, predicate: str) -> Fact | None:
        facts = self.query(MemoryQuery(subject=subject, predicate=predicate, status="verified", limit=1))
        return facts[0] if facts else None

    def export_jsonl(self, path: str | Path) -> None:
        rows = self.db.execute("SELECT id FROM facts ORDER BY created_at,id").fetchall()
        with Path(path).open("w", encoding="utf-8") as fh:
            for row in rows:
                fh.write(json.dumps(asdict(self.get_fact(row[0])), ensure_ascii=False) + "\n")

    def count(self) -> dict[str, int]:
        return {
            "entities": int(self.db.execute("SELECT count(*) FROM entities").fetchone()[0]),
            "facts": int(self.db.execute("SELECT count(*) FROM facts").fetchone()[0]),
            "conflicts": int(self.db.execute("SELECT count(*) FROM conflicts").fetchone()[0]),
        }
