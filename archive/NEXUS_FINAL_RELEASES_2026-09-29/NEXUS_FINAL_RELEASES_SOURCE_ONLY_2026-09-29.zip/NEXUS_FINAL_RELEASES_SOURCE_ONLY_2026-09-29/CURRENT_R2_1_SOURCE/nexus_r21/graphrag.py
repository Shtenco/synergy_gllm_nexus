from __future__ import annotations

import hashlib
import json
import math
import re
from collections import Counter, defaultdict, deque
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, Sequence

from .relation_extractor_v2 import RelationExtractorV2, RelationCandidate
from .spo_memory import SPOMemory, MemoryQuery, search_terms, normalize_text
from .vector_index import HashVectorIndex


@dataclass(frozen=True)
class SourceRecord:
    source_id: str
    title: str
    uri: str
    publisher: str
    trust_score: float
    license: str
    retrieved_at: str


@dataclass(frozen=True)
class Chunk:
    chunk_id: str
    source_id: str
    text: str
    index: int
    tokens: tuple[str, ...]


@dataclass(frozen=True)
class Evidence:
    chunk_id: str
    source_id: str
    title: str
    uri: str
    text: str
    lexical_score: float
    vector_score: float
    graph_score: float
    trust_score: float
    final_score: float
    matched_facts: tuple[str, ...]




@dataclass(frozen=True)
class ClaimCheck:
    subject: str
    predicate: str
    object: str
    supported: bool
    contradicted: bool
    source_ids: tuple[str, ...]
    source_uris: tuple[str, ...]
    max_trust: float
    reason: str


class VerifiedGraphRAG:
    """Local evidence retriever that combines lexical ranking and graph traversal.

    It never declares generated text verified. It returns source-bound evidence;
    the authority layer decides whether an answer is supported by that evidence.
    """

    def __init__(self, memory: SPOMemory, extractor: RelationExtractorV2 | None = None):
        self.memory = memory
        self.extractor = extractor or RelationExtractorV2()
        self.sources: dict[str, SourceRecord] = {}
        self.chunks: dict[str, Chunk] = {}
        self.postings: dict[str, set[str]] = defaultdict(set)
        self.doc_freq: Counter[str] = Counter()
        self.avg_len = 1.0
        self.vector_index = HashVectorIndex(dimensions=2048)

    @staticmethod
    def _tokens(text: str) -> tuple[str, ...]:
        terms = search_terms(text)
        return tuple(terms)

    @staticmethod
    def _source_id(uri: str) -> str:
        return "src_" + hashlib.sha256(uri.encode()).hexdigest()[:20]

    @staticmethod
    def _chunk_id(source_id: str, index: int, text: str) -> str:
        return "chk_" + hashlib.sha256(f"{source_id}\0{index}\0{text}".encode()).hexdigest()[:24]

    def register_source(
        self,
        *,
        title: str,
        uri: str,
        publisher: str,
        trust_score: float,
        license: str,
        retrieved_at: str,
    ) -> str:
        if not (0 <= trust_score <= 1):
            raise ValueError("trust_score must be in [0,1]")
        source_id = self._source_id(uri)
        self.sources[source_id] = SourceRecord(source_id, title, uri, publisher, trust_score, license, retrieved_at)
        return source_id

    @staticmethod
    def chunk_text(text: str, *, max_chars: int = 900, overlap_sentences: int = 1) -> list[str]:
        sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+|\n+", text) if s.strip()]
        if not sentences:
            return []
        chunks: list[str] = []
        current: list[str] = []
        size = 0
        for sentence in sentences:
            if current and size + len(sentence) + 1 > max_chars:
                chunks.append(" ".join(current))
                current = current[-overlap_sentences:] if overlap_sentences else []
                size = sum(len(s) + 1 for s in current)
            current.append(sentence)
            size += len(sentence) + 1
        if current:
            chunks.append(" ".join(current))
        return chunks

    def ingest_text(self, source_id: str, text: str) -> list[str]:
        if source_id not in self.sources:
            raise KeyError(source_id)
        new_ids=[]
        for index, chunk_text in enumerate(self.chunk_text(text)):
            cid=self._chunk_id(source_id,index,chunk_text)
            tokens=self._tokens(chunk_text)
            chunk=Chunk(cid,source_id,chunk_text,index,tokens)
            self.chunks[cid]=chunk
            self.vector_index.upsert(cid, chunk_text)
            for token in set(tokens):
                self.postings[token].add(cid)
            new_ids.append(cid)
            for rel in self.extractor.extract(chunk_text):
                self.memory.add_fact(
                    rel.subject, rel.relation, rel.object,
                    confidence=min(0.99, rel.confidence * self.sources[source_id].trust_score),
                    status="candidate" if rel.extractor != "rule" else "verified",
                    source=source_id,
                    provenance={"chunk_id":cid,"uri":self.sources[source_id].uri,"extractor":rel.extractor,"sentence":rel.sentence},
                )
        self._rebuild_stats()
        return new_ids

    def _rebuild_stats(self) -> None:
        self.doc_freq=Counter({token:len(ids) for token,ids in self.postings.items()})
        self.avg_len=(sum(len(c.tokens) for c in self.chunks.values())/max(1,len(self.chunks)))

    def _bm25(self, query_tokens: Sequence[str], chunk: Chunk, k1: float=1.5, b: float=0.75) -> float:
        tf=Counter(chunk.tokens)
        n=max(1,len(self.chunks))
        score=0.0
        for token in query_tokens:
            if token not in tf:
                continue
            df=self.doc_freq.get(token,0)
            idf=math.log(1+(n-df+0.5)/(df+0.5))
            freq=tf[token]
            denom=freq+k1*(1-b+b*len(chunk.tokens)/max(1,self.avg_len))
            score += idf*(freq*(k1+1)/denom)
        return score

    def _graph_expansion(self, query: str, max_depth: int=2) -> dict[str,float]:
        start=self.memory.resolve_entities(query,limit=12)
        if not start:
            return {}
        scores={e.id:1.0 for e in start}
        frontier=deque((e.id,0,1.0) for e in start)
        while frontier:
            entity_id,depth,score=frontier.popleft()
            if depth>=max_depth:
                continue
            rows=self.memory.db.execute(
                """SELECT f.object_id,f.confidence FROM facts f
                   WHERE f.subject_id=? AND f.status='verified'
                   UNION ALL
                   SELECT f.subject_id,f.confidence FROM facts f
                   WHERE f.object_id=? AND f.status='verified'""",
                (entity_id,entity_id),
            ).fetchall()
            for nxt,conf in rows:
                propagated=score*float(conf)*0.65
                if propagated<=scores.get(nxt,0):
                    continue
                scores[nxt]=propagated
                frontier.append((nxt,depth+1,propagated))
        return scores

    def retrieve(self, query: str, *, top_k: int=8, min_trust: float=0.5) -> list[Evidence]:
        qtokens=self._tokens(query)
        candidate_ids=set()
        for token in qtokens:
            candidate_ids.update(self.postings.get(token,()))
        vector_hits={hit.item_id:hit.score for hit in self.vector_index.search(query,top_k=max(32,top_k*8),min_score=0.0)}
        candidate_ids.update(vector_hits)
        if not candidate_ids:
            candidate_ids=set(self.chunks)
        graph_entities=self._graph_expansion(query)
        evidence=[]
        for cid in candidate_ids:
            chunk=self.chunks[cid]
            source=self.sources[chunk.source_id]
            if source.trust_score<min_trust:
                continue
            lexical=self._bm25(qtokens,chunk)
            vector_score=max(0.0,vector_hits.get(cid,0.0))
            facts=self.memory.query(MemoryQuery(text=chunk.text,status="verified",limit=20))
            matched=[]
            graph_score=0.0
            for fact in facts:
                matched.append(f"{fact.subject} --{fact.predicate}--> {fact.object}")
                for ent in self.memory.resolve_entities(fact.subject,limit=3)+self.memory.resolve_entities(fact.object,limit=3):
                    graph_score=max(graph_score,graph_entities.get(ent.id,0.0))
            final=(0.48*lexical)+(0.20*vector_score)+(0.17*graph_score)+(0.15*source.trust_score)
            evidence.append(Evidence(cid,source.source_id,source.title,source.uri,chunk.text,lexical,vector_score,graph_score,source.trust_score,final,tuple(dict.fromkeys(matched))))
        evidence.sort(key=lambda e:(e.final_score,e.trust_score),reverse=True)
        return evidence[:top_k]


    def save(self, directory: str | Path) -> None:
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        (directory / "sources.json").write_text(
            json.dumps(
                {source_id: asdict(source) for source_id, source in sorted(self.sources.items())},
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        with (directory / "chunks.jsonl").open("w", encoding="utf-8") as fh:
            for chunk_id in sorted(self.chunks):
                fh.write(json.dumps(asdict(self.chunks[chunk_id]), ensure_ascii=False) + "\n")
        self.vector_index.save(directory / "vector_index.json")
        manifest = {
            "format": "nexus-r21-graphrag-index/1",
            "source_count": len(self.sources),
            "chunk_count": len(self.chunks),
            "vector_dimensions": self.vector_index.dimensions,
            "files": {
                "sources": "sources.json",
                "chunks": "chunks.jsonl",
                "vectors": "vector_index.json",
            },
        }
        (directory / "manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    @classmethod
    def load(
        cls,
        directory: str | Path,
        memory: SPOMemory,
        extractor: RelationExtractorV2 | None = None,
    ) -> "VerifiedGraphRAG":
        directory = Path(directory)
        rag = cls(memory, extractor)
        source_data = json.loads((directory / "sources.json").read_text(encoding="utf-8"))
        rag.sources = {
            source_id: SourceRecord(**payload)
            for source_id, payload in source_data.items()
        }
        with (directory / "chunks.jsonl").open(encoding="utf-8") as fh:
            for line in fh:
                if not line.strip():
                    continue
                payload = json.loads(line)
                payload["tokens"] = tuple(payload["tokens"])
                chunk = Chunk(**payload)
                rag.chunks[chunk.chunk_id] = chunk
                for token in set(chunk.tokens):
                    rag.postings[token].add(chunk.chunk_id)
        rag.vector_index = HashVectorIndex.load(directory / "vector_index.json")
        rag._rebuild_stats()
        return rag

    @staticmethod
    def _predicate_norm(predicate: str) -> str:
        return normalize_text(predicate).replace(" ", "_")

    def verify_claim(
        self,
        subject: str,
        predicate: str,
        object: str,
        *,
        high_trust: float = 0.90,
        medium_trust: float = 0.70,
        medium_source_quorum: int = 2,
    ) -> ClaimCheck:
        """Verify one SPO claim against source-bound facts.

        A claim is supported only by either:
        - at least one high-trust source; or
        - at least ``medium_source_quorum`` independent medium-trust sources.

        Candidate facts, session memory and generated text do not count as external
        verification. Exact opposite ``contradicts`` edges are reported separately.
        """
        pred_norm = self._predicate_norm(predicate)
        subject_entities = self.memory.resolve_entities(subject, limit=20)
        object_entities = self.memory.resolve_entities(object, limit=20)
        subject_ids = {e.id for e in subject_entities}
        object_ids = {e.id for e in object_entities}
        if not subject_ids or not object_ids:
            return ClaimCheck(
                subject, predicate, object, False, False, (), (), 0.0,
                "subject or object is absent from the verified graph",
            )

        placeholders_s = ",".join("?" * len(subject_ids))
        placeholders_o = ",".join("?" * len(object_ids))
        rows = self.memory.db.execute(
            f"""SELECT f.id,f.source,f.predicate_norm,f.subject_id,f.object_id
                FROM facts f
                WHERE f.status='verified'
                  AND f.subject_id IN ({placeholders_s})
                  AND f.object_id IN ({placeholders_o})""",
            (*subject_ids, *object_ids),
        ).fetchall()

        support_sources: dict[str, SourceRecord] = {}
        contradicted_sources: dict[str, SourceRecord] = {}
        for row in rows:
            source = self.sources.get(row["source"])
            if source is None:
                continue
            if row["predicate_norm"] == pred_norm:
                support_sources[source.source_id] = source
            if row["predicate_norm"] == "contradicts" and pred_norm != "contradicts":
                contradicted_sources[source.source_id] = source

        max_trust = max((s.trust_score for s in support_sources.values()), default=0.0)
        high_ok = any(s.trust_score >= high_trust for s in support_sources.values())
        medium_ok = sum(s.trust_score >= medium_trust for s in support_sources.values()) >= medium_source_quorum
        supported = high_ok or medium_ok
        contradicted = bool(contradicted_sources)
        reason = (
            "supported by high-trust source" if high_ok else
            "supported by independent medium-trust sources" if medium_ok else
            "insufficient independent trusted support"
        )
        if contradicted:
            reason += "; contradictory evidence exists"

        ordered = sorted(support_sources.values(), key=lambda s: (-s.trust_score, s.uri))
        return ClaimCheck(
            subject=subject,
            predicate=predicate,
            object=object,
            supported=supported,
            contradicted=contradicted,
            source_ids=tuple(s.source_id for s in ordered),
            source_uris=tuple(s.uri for s in ordered),
            max_trust=max_trust,
            reason=reason,
        )

    def verify_claims(self, claims: Sequence[dict]) -> dict:
        checks: list[ClaimCheck] = []
        for claim in claims:
            try:
                subject = str(claim["subject"]).strip()
                predicate = str(claim["predicate"]).strip()
                object_ = str(claim["object"]).strip()
            except (KeyError, TypeError):
                continue
            if not subject or not predicate or not object_:
                continue
            checks.append(self.verify_claim(subject, predicate, object_))
        verified = bool(checks) and all(c.supported and not c.contradicted for c in checks)
        return {
            "verified": verified,
            "checks": [asdict(c) for c in checks],
            "claim_count": len(checks),
            "supported_count": sum(c.supported for c in checks),
            "contradicted_count": sum(c.contradicted for c in checks),
            "claim_boundary": (
                "Verified only when every structured SPO claim has independent "
                "source-bound support and no contradictory evidence."
            ),
        }

    def evidence_packet(self, query: str, *, top_k: int=8, claims: Sequence[dict] | None = None) -> dict:
        rows=self.retrieve(query,top_k=top_k)
        verification = self.verify_claims(claims or []) if claims is not None else None
        return {
            "query":query,
            "evidence":[asdict(e) for e in rows],
            "evidence_available":bool(rows),
            "verified":bool(verification and verification["verified"]),
            "source_count":len({e.source_id for e in rows}),
            "claim_verification":verification,
            "claim_boundary":"Retrieval is not verification. Generated claims require claim-level source quorum."
        }
