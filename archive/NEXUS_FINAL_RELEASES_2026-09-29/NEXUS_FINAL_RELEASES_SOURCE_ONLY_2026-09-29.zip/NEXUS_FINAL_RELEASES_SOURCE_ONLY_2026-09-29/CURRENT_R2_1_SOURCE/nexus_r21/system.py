from __future__ import annotations

import json
import re
import subprocess
import time
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Protocol

from .exact_router_v2 import route_exact
from .graphrag import VerifiedGraphRAG
from .multi_rule_parser import MultiRuleParser
from .relation_extractor_v2 import CharNGramNB, RelationExtractorV2
from .spo_memory import SPOMemory
from .sqlite_graphrag import SQLiteGraphRAG


class Cortex(Protocol):
    def generate(self, prompt: str, *, system: str, max_tokens: int = 384, temperature: float = 0.1) -> dict[str, Any]: ...


@dataclass(frozen=True)
class AuthorityDecision:
    engine: str
    verified: bool
    answer: str
    evidence: dict[str, Any]
    cortex_used: bool


class Qwen3LlamaCpp:
    """Subprocess backend for the official Qwen3-14B GGUF through llama.cpp."""

    def __init__(self, binary: str | Path, model: str | Path, *, threads: int = 6, context: int = 8192, timeout_s: int = 900):
        self.binary = Path(binary)
        self.model = Path(model)
        self.threads = int(threads)
        self.context = int(context)
        self.timeout_s = int(timeout_s)

    def available(self) -> bool:
        return self.binary.is_file() and self.model.is_file() and self.model.stat().st_size > 8_000_000_000

    def generate(self, prompt: str, *, system: str, max_tokens: int = 384, temperature: float = 0.1) -> dict[str, Any]:
        if not self.available():
            raise RuntimeError("Qwen3-14B runtime or GGUF is missing")
        # llama.cpp applies the Qwen3 Jinja template from GGUF. /no_think keeps
        # benchmark outputs concise while authority reasoning stays external.
        user_prompt = prompt.rstrip() + "\n/no_think"
        cmd = [
            str(self.binary), "-m", str(self.model),
            "--system-prompt", system,
            "-p", user_prompt,
            "-n", str(max_tokens), "-c", str(self.context), "-t", str(self.threads),
            "--temp", str(temperature), "--single-turn", "--jinja",
            "--no-display-prompt", "--no-warmup",
        ]
        started = time.perf_counter()
        cp = subprocess.run(cmd, capture_output=True, text=True, timeout=self.timeout_s)
        elapsed = time.perf_counter() - started
        text = re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", cp.stdout).strip()
        if cp.returncode != 0 or not text:
            raise RuntimeError(f"llama.cpp failed ({cp.returncode}): {cp.stderr[-1500:]}")
        return {"text": text, "latency_s": elapsed, "returncode": cp.returncode, "backend": "Qwen3-14B-Q4_K_M"}


class Qwen3OpenAIBackend:
    """Persistent Qwen3 backend through a local OpenAI-compatible llama-server."""

    def __init__(
        self,
        base_url: str = "http://127.0.0.1:8080/v1/chat/completions",
        *,
        model: str = "Qwen3-14B-Q4_K_M",
        timeout_s: int = 1800,
        api_key: str = "none",
    ):
        self.base_url = base_url
        self.model = model
        self.timeout_s = int(timeout_s)
        self.api_key = api_key

    def available(self) -> bool:
        request = urllib.request.Request(
            self.base_url.rsplit("/chat/completions", 1)[0] + "/models",
            headers={"Authorization": f"Bearer {self.api_key}"},
        )
        try:
            with urllib.request.urlopen(request, timeout=10) as response:
                return 200 <= response.status < 300
        except Exception:
            return False

    def generate(self, prompt: str, *, system: str, max_tokens: int = 384, temperature: float = 0.1) -> dict[str, Any]:
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": prompt.rstrip() + "\n/no_think"},
            ],
            "max_tokens": int(max_tokens),
            "temperature": float(temperature),
            "stream": False,
        }
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        request = urllib.request.Request(
            self.base_url,
            data=data,
            method="POST",
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
            },
        )
        started = time.perf_counter()
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_s) as response:
                body = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"cortex HTTP {exc.code}: {detail[-2000:]}") from exc
        elapsed = time.perf_counter() - started
        try:
            text = body["choices"][0]["message"]["content"].strip()
        except Exception as exc:
            raise RuntimeError(f"invalid cortex response: {body}") from exc
        if not text:
            raise RuntimeError("cortex returned empty content")
        return {
            "text": text,
            "latency_s": elapsed,
            "returncode": 0,
            "backend": self.model,
            "usage": body.get("usage"),
        }


class NexusR21System:
    VERSION = "NEXUS R2.1 Qwen3-14B Verified Intelligence Alpha"

    def __init__(
        self,
        cortex: Cortex,
        *,
        state_dir: str | Path,
        relation_model: str | Path | None = None,
        graphrag_index: str | Path | None = None,
        knowledge_db: str | Path | None = None,
        corpus_db: str | Path | None = None,
    ):
        self.cortex = cortex
        state_dir = Path(state_dir)
        state_dir.mkdir(parents=True, exist_ok=True)
        self.memory = SPOMemory(state_dir / "spo_memory.sqlite")
        classifier = CharNGramNB.load(relation_model) if relation_model else None
        self.extractor = RelationExtractorV2(classifier)
        if corpus_db:
            self.knowledge_memory = None
            self.rag = SQLiteGraphRAG(corpus_db, self.extractor)
        elif graphrag_index:
            index_path = Path(graphrag_index)
            kb_path = Path(knowledge_db) if knowledge_db else index_path.parent / "spo_memory.sqlite"
            self.knowledge_memory = SPOMemory(kb_path)
            self.rag = VerifiedGraphRAG.load(index_path, self.knowledge_memory, self.extractor)
        else:
            # Development fallback. Production should use a separately built,
            # source-bound knowledge DB so user/session facts never become evidence.
            self.knowledge_memory = SPOMemory(":memory:")
            self.rag = VerifiedGraphRAG(self.knowledge_memory, self.extractor)
        self.logic = MultiRuleParser()

    @staticmethod
    def _uncertainty_gate(question: str) -> str | None:
        q = question.casefold().replace("ё", "е")
        impossible = [
            (r"точн\w*\s+температур\w*.*(?:вымышлен|неизвестн|без.*наблюден)", "Точную температуру нельзя установить без наблюдений или исходных данных."),
            (r"парол\w*.*(?:несуществ|неизвестн|нет.*доступ)", "Пароль нельзя достоверно определить без доступа к системе или подтверждённой записи."),
            (r"точн\w*\s+причин\w*.*(?:система не работает|без.*данн)", "Точную причину сбоя нельзя установить без диагностических данных, логов и условий воспроизведения."),
            (r"достоверн\w*\s+назови.*(?:ничего.*не известно|неопублик)", "Недостаточно проверяемой информации для достоверного ответа."),
        ]
        for pattern, answer in impossible:
            if re.search(pattern, q):
                return answer
        return None

    @staticmethod
    def _memory_write_patterns(text: str) -> list[tuple[str, str, str, str, str]]:
        rows=[]
        patterns = [
            (r"(?:запомни\s*[:,-]?\s*)?проект\s+называется\s+([^.!?]+)", "проект", "name", "proper_name", "project_name"),
            (r"(?:запомни\s*[:,-]?\s*)?кодовое\s+слово\s*[:—-]?\s*([^.!?]+)", "кодовое слово", "value", "proper_name", "codeword"),
            (r"(?:запомни\s*[:,-]?\s*)?([A-Za-zА-Яа-яЁё0-9 _-]+?)\s+равн(?:о|а)\s+([^.!?]+)", None, "equals", "value", "equality"),
        ]
        for pattern, fixed_subject, predicate, object_type, kind in patterns:
            for match in re.finditer(pattern, text, re.I):
                if fixed_subject is None:
                    subject=match.group(1).strip(); obj=match.group(2).strip()
                else:
                    subject=fixed_subject; obj=match.group(1).strip()
                if subject and obj:
                    rows.append((subject,predicate,obj,object_type,kind))
        return rows

    @staticmethod
    def _memory_query(text: str) -> tuple[str, str] | None:
        q=text.casefold().replace("ё","е")
        if re.search(r"как\w*\s+называется\s+проект",q):
            return "проект","name"
        if re.search(r"какое\s+кодовое\s+слово|назвал.*кодовое\s+слово",q):
            return "кодовое слово","value"
        match=re.search(r"чему\s+равн[оа]\s+(.+?)[?!.]*$",q)
        if match:
            return match.group(1).strip(),"equals"
        return None

    def _store_relations(self, text: str, source: str = "user_message") -> list[dict[str, Any]]:
        stored=[]
        for rel in self.extractor.extract(text):
            fact=self.memory.add_fact(
                rel.subject,rel.relation,rel.object,
                confidence=rel.confidence,
                status="verified" if rel.extractor=="rule" else "candidate",
                source=source,
                provenance={"sentence":rel.sentence,"extractor":rel.extractor},
            )
            stored.append(asdict(fact))
        return stored


    @staticmethod
    def _parse_cortex_payload(text: str) -> tuple[str, list[dict[str, str]], bool]:
        """Parse the cortex proposal without granting it authority.

        The cortex is asked for strict JSON. Any malformed payload is retained as
        visible prose but receives zero structured claims and therefore cannot be
        marked verified.
        """
        raw = text.strip()
        candidates = [raw]
        fenced = re.search(r"```(?:json)?\s*(\{.*\})\s*```", raw, flags=re.I | re.S)
        if fenced:
            candidates.insert(0, fenced.group(1))
        braced = re.search(r"(\{.*\})", raw, flags=re.S)
        if braced:
            candidates.append(braced.group(1))
        for candidate in candidates:
            try:
                payload = json.loads(candidate)
            except Exception:
                continue
            if not isinstance(payload, dict):
                continue
            answer = str(payload.get("answer", "")).strip()
            claims_raw = payload.get("claims", [])
            claims: list[dict[str, str]] = []
            if isinstance(claims_raw, list):
                for item in claims_raw:
                    if not isinstance(item, dict):
                        continue
                    if not all(key in item for key in ("subject", "predicate", "object")):
                        continue
                    claim = {
                        "subject": str(item["subject"]).strip(),
                        "predicate": str(item["predicate"]).strip(),
                        "object": str(item["object"]).strip(),
                    }
                    if all(claim.values()):
                        claims.append(claim)
            return answer or raw, claims, True
        return raw, [], False

    def answer(self, question: str, *, context: str | None = None) -> dict[str, Any]:
        question=question.strip()
        if not question:
            raise ValueError("question is empty")

        exact=route_exact(question)
        if exact is not None:
            return asdict(AuthorityDecision(
                engine="exact_router_v2",verified=True,
                answer=f"Результат: {exact.value}." + (f" Точное значение: {exact.exact_fraction}." if exact.exact_fraction else ""),
                evidence=asdict(exact),cortex_used=False,
            )) | {"model":self.VERSION}

        refusal=self._uncertainty_gate(question)
        if refusal:
            return asdict(AuthorityDecision("epistemic_gate",True,refusal,{"reason":"insufficient_observable_data"},False)) | {"model":self.VERSION}

        memory_query=self._memory_query(question)
        if memory_query:
            fact=self.memory.answer_attribute(*memory_query)
            if fact:
                return asdict(AuthorityDecision(
                    "spo_memory",True,f"{fact.subject.capitalize()}: {fact.object}.",asdict(fact),False
                )) | {"model":self.VERSION}

        writes=[]
        for subject,predicate,obj,object_type,kind in self._memory_write_patterns(question):
            fact=self.memory.add_fact(
                subject,predicate,obj,object_type=object_type,source="session",
                provenance={"kind":kind,"text":question},status="verified",
            )
            writes.append(asdict(fact))
        if writes:
            return asdict(AuthorityDecision("spo_memory_write",True,"Факт сохранён в проверяемой SPO-памяти.",{"facts":writes},False)) | {"model":self.VERSION}

        parsed=self.logic.parse(question)
        if parsed.rules and parsed.query:
            proof=self.logic.prove(parsed)
            return asdict(AuthorityDecision(
                "formal_multi_rule",proof.entailed and not proof.contradiction,
                proof.explanation,{"query":proof.query,"entailed":proof.entailed,"contradiction":proof.contradiction,"path":[asdict(s) for s in proof.path],"derived":proof.derived},False
            )) | {"model":self.VERSION}

        stored=self._store_relations(question)
        retrieval=self.rag.evidence_packet(question,top_k=8)
        evidence_lines=[]
        for item in retrieval["evidence"]:
            evidence_lines.append(f"SOURCE: {item['title']} | {item['uri']}\nPASSAGE: {item['text']}")
        source_block="\n\n".join(evidence_lines) if evidence_lines else "Нет проверенных внешних источников в локальном GraphRAG."
        system=(
            "Ты — языковая кора NEXUS R2.1, а не authority-орган. "
            "Верни только JSON-объект: "
            "{\"answer\":\"краткий русский ответ\","
            "\"claims\":[{\"subject\":\"...\",\"predicate\":\"...\",\"object\":\"...\"}]}. "
            "В claims перечисляй каждое внешнее фактическое утверждение как SPO. "
            "Не объявляй факт доказанным без предоставленных источников. "
            "Если данных нет, answer должен прямо сказать об отсутствии данных, а claims быть пустым. "
            "Не изменяй exact/formal/memory решения authority-органов."
        )
        context_block = f"DIALOGUE CONTEXT:\n{context}\n\n" if context else ""
        prompt=(
            f"{context_block}ВОПРОС:\n{question}\n\nGRAPH-RAG EVIDENCE:\n{source_block}\n\n"
            "Сформируй proposal в строгом JSON. Не добавляй Markdown."
        )
        draft=self.cortex.generate(prompt,system=system,max_tokens=512,temperature=.1)
        answer_text,claims,json_valid=self._parse_cortex_payload(draft["text"])
        verification=self.rag.verify_claims(claims)
        packet=dict(retrieval)
        packet["claim_verification"]=verification
        packet["verified"]=verification["verified"]
        verified=bool(verification["verified"])
        engine="qwen3_14b_verified_graphrag" if verified else "qwen3_14b_unverified_proposal"
        return asdict(AuthorityDecision(
            engine,verified,answer_text,
            {
                "graphrag":packet,
                "structured_claims":claims,
                "cortex_json_valid":json_valid,
                "stored_relations":stored,
                "cortex":draft,
            },True
        )) | {"model":self.VERSION}
