from __future__ import annotations

import json
import math
import re
from collections import Counter, defaultdict
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, Sequence

RELATIONS = (
    "causes", "enables", "inhibits", "supports", "contradicts", "requires", "precedes", "part_of", "other"
)


@dataclass(frozen=True)
class RelationCandidate:
    subject: str
    relation: str
    object: str
    confidence: float
    sentence: str
    extractor: str


def _normalize(text: str) -> str:
    text = text.casefold().replace("ё", "е")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def _ngrams(text: str, n_min: int = 2, n_max: int = 5) -> Counter[str]:
    text = "^" + _normalize(text) + "$"
    feats: Counter[str] = Counter()
    for n in range(n_min, n_max + 1):
        for i in range(max(0, len(text) - n + 1)):
            feats[text[i:i+n]] += 1
    for token in re.findall(r"[a-zа-я0-9_-]+", text):
        feats["w=" + token] += 2
    return feats


class CharNGramNB:
    """Small trainable multinomial NB relation classifier serialized as JSON."""

    def __init__(self, alpha: float = 0.5):
        self.alpha = float(alpha)
        self.class_docs: Counter[str] = Counter()
        self.class_counts: dict[str, Counter[str]] = defaultdict(Counter)
        self.class_totals: Counter[str] = Counter()
        self.vocab: set[str] = set()
        self.trained = False

    def fit(self, texts: Sequence[str], labels: Sequence[str]) -> "CharNGramNB":
        if len(texts) != len(labels) or not texts:
            raise ValueError("texts and labels must have the same non-zero length")
        for text, label in zip(texts, labels):
            if label not in RELATIONS:
                raise ValueError(f"unknown label {label}")
            feats = _ngrams(text)
            self.class_docs[label] += 1
            self.class_counts[label].update(feats)
            self.class_totals[label] += sum(feats.values())
            self.vocab.update(feats)
        self.trained = True
        return self

    def predict_proba(self, text: str) -> dict[str, float]:
        if not self.trained:
            raise RuntimeError("classifier is not trained")
        feats = _ngrams(text)
        total_docs = sum(self.class_docs.values())
        labels = sorted(self.class_docs)
        vocab_size = max(1, len(self.vocab))
        logps: dict[str, float] = {}
        for label in labels:
            prior = (self.class_docs[label] + self.alpha) / (total_docs + self.alpha * len(labels))
            logp = math.log(prior)
            denom = self.class_totals[label] + self.alpha * vocab_size
            counts = self.class_counts[label]
            for feat, count in feats.items():
                logp += count * math.log((counts.get(feat, 0) + self.alpha) / denom)
            logps[label] = logp
        pivot = max(logps.values())
        exp = {label: math.exp(v - pivot) for label, v in logps.items()}
        z = sum(exp.values())
        return {label: value / z for label, value in exp.items()}

    def predict(self, text: str) -> tuple[str, float]:
        probs = self.predict_proba(text)
        label = max(probs, key=probs.get)
        return label, probs[label]

    def to_dict(self) -> dict:
        return {
            "format": "nexus-r21-char-ngram-nb/1",
            "alpha": self.alpha,
            "class_docs": dict(self.class_docs),
            "class_counts": {k: dict(v) for k, v in self.class_counts.items()},
            "class_totals": dict(self.class_totals),
            "vocab": sorted(self.vocab),
            "relations": list(RELATIONS),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "CharNGramNB":
        model = cls(data.get("alpha", 0.5))
        model.class_docs = Counter(data["class_docs"])
        model.class_counts = defaultdict(Counter, {k: Counter(v) for k, v in data["class_counts"].items()})
        model.class_totals = Counter(data["class_totals"])
        model.vocab = set(data["vocab"])
        model.trained = True
        return model

    def save(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(self.to_dict(), ensure_ascii=False, separators=(",", ":")), encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "CharNGramNB":
        return cls.from_dict(json.loads(Path(path).read_text(encoding="utf-8")))


class RelationExtractorV2:
    PATTERNS: tuple[tuple[str, str], ...] = (
        (r"(.+?)\s+(?:вызывает|порождает|приводит\s+к|становится\s+причиной)\s+(.+)", "causes"),
        (r"(.+?)\s+(?:позволяет|обеспечивает|дает\s+возможность|усиливает)\s+(.+)", "enables"),
        (r"(.+?)\s+(?:снижает|подавляет|блокирует|предотвращает|уменьшает)\s+(.+)", "inhibits"),
        (r"(.+?)\s+(?:подтверждает|поддерживает|согласуется\s+с|свидетельствует\s+в\s+пользу)\s+(.+)", "supports"),
        (r"(.+?)\s+(?:противоречит|опровергает|несовместим[аоы]?\s+с|расходится\s+с)\s+(.+)", "contradicts"),
        (r"(.+?)\s+(?:требует|нуждается\s+в|невозможн[ао]?\s+без|зависит\s+от|необходим[аоы]?\s+для)\s+(.+)", "requires"),
        (r"(.+?)\s+(?:предшествует|происходит\s+до|сначала.+?затем)\s+(.+)", "precedes"),
        (r"(.+?)\s+(?:является\s+частью|входит\s+в|состоит\s+в)\s+(.+)", "part_of"),
    )

    def __init__(self, classifier: CharNGramNB | None = None, min_classifier_confidence: float = 0.62):
        self.classifier = classifier
        self.min_classifier_confidence = float(min_classifier_confidence)

    @staticmethod
    def split_sentences(text: str) -> list[str]:
        return [s.strip() for s in re.split(r"(?<=[.!?;])\s+|\n+", text) if s.strip()]

    def extract_sentence(self, sentence: str) -> list[RelationCandidate]:
        clean = sentence.strip(" \t\r\n.!?;")
        out: list[RelationCandidate] = []
        # Russian requirement construction with reversed surface order:
        # "Для X необходимы Y" -> X requires Y.
        reversed_required = re.fullmatch(r"для\s+(.+?)\s+необходим[аоы]?\s+(.+)", clean, flags=re.IGNORECASE)
        if reversed_required:
            return [RelationCandidate(reversed_required.group(1).strip(), "requires", reversed_required.group(2).strip(), 0.98, sentence, "rule")]
        for pattern, relation in self.PATTERNS:
            match = re.fullmatch(pattern, clean, flags=re.IGNORECASE)
            if not match:
                continue
            subject, obj = match.group(1).strip(" ,"), match.group(2).strip(" ,")
            if subject and obj:
                out.append(RelationCandidate(subject, relation, obj, 0.98, sentence, "rule"))
                return out
        if self.classifier is None:
            return out
        relation, confidence = self.classifier.predict(clean)
        if relation == "other" or confidence < self.min_classifier_confidence:
            return out
        # Learned fallback uses a conservative two-clause split around punctuation/conjunction.
        parts = [p.strip(" ,") for p in re.split(r"\s+(?:а|но|и|при\s+этом)\s+|[,;:]", clean, maxsplit=1) if p.strip(" ,")]
        if len(parts) == 2:
            out.append(RelationCandidate(parts[0], relation, parts[1], confidence, sentence, "char_ngram_nb"))
        return out

    def extract(self, text: str) -> list[RelationCandidate]:
        out: list[RelationCandidate] = []
        for sentence in self.split_sentences(text):
            out.extend(self.extract_sentence(sentence))
        return out
