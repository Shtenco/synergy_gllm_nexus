from __future__ import annotations

import ast
import math
import operator
import re
from dataclasses import dataclass
from decimal import Decimal, getcontext
from fractions import Fraction
from typing import Iterable

getcontext().prec = 50

_ALLOWED_BINOPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}
_ALLOWED_UNARY = {ast.UAdd: operator.pos, ast.USub: operator.neg}

# Text fragments that are safe to remove before arithmetic candidate extraction.
_PREFIXES = (
    r"сколько\s+будет",
    r"посчитай",
    r"вычисли",
    r"рассчитай",
    r"найди\s+значение",
    r"каков\s+результат",
    r"чему\s+равно",
    r"на\s+самом\s+деле",
    r"ответь",
)

# Adversarial natural-language instructions are deliberately ignored by the exact router.
_ADVERSARIAL = (
    r"игнорируй[^,;.!?]*",
    r"забудь[^,;.!?]*",
    r"не\s+считай[^,;.!?]*",
    r"назови\s+\d+(?:[.,]\d+)?[^,;.!?]*",
    r"ответ\s+должен\s+быть[^,;.!?]*",
)


@dataclass(frozen=True)
class ExactResult:
    original_text: str
    expression: str
    normalized_expression: str
    value: int | float | str
    exact_fraction: str | None
    verified: bool
    engine: str = "exact_router_v2"


class ExactRoutingError(ValueError):
    pass


def _normalize_symbols(text: str) -> str:
    table = str.maketrans({
        "×": "*", "·": "*", "х": "*", "Х": "*",
        "÷": "/", "−": "-", "–": "-", "—": "-",
        "^": "**", "，": ",", "（": "(", "）": ")",
    })
    text = text.translate(table)
    # Decimal comma only when between digits.
    text = re.sub(r"(?<=\d),(?=\d)", ".", text)
    # Russian words for operators in otherwise arithmetic phrases.
    replacements = {
        r"\bумнож(?:ить|ь)\s+на\b": "*",
        r"\bпомнож(?:ить|ь)\s+на\b": "*",
        r"\bраздел(?:ить|и)\s+на\b": "/",
        r"\bплюс\b": "+",
        r"\bминус\b": "-",
    }
    for pattern, repl in replacements.items():
        text = re.sub(pattern, repl, text, flags=re.IGNORECASE)
    return text


def _strip_instruction_noise(text: str) -> str:
    out = text.casefold()
    for pattern in _ADVERSARIAL:
        out = re.sub(pattern, " ", out, flags=re.IGNORECASE)
    for pattern in _PREFIXES:
        out = re.sub(pattern, " ", out, flags=re.IGNORECASE)
    return out


def _balanced(expr: str) -> bool:
    depth = 0
    for ch in expr:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth < 0:
                return False
    return depth == 0


def _candidate_score(expr: str) -> tuple[int, int, int]:
    numbers = len(re.findall(r"\d+(?:\.\d+)?", expr))
    operators = len(re.findall(r"\*\*|[+\-*/%]", expr))
    parens = expr.count("(") + expr.count(")")
    return numbers + operators * 2 + parens, len(expr), operators


def extract_expression(text: str) -> str | None:
    """Extract the strongest arithmetic expression from arbitrary surrounding text.

    The router intentionally prefers a well-formed candidate with at least two
    numbers or one exponentiation over any natural-language instruction.
    """
    normalized = _normalize_symbols(_strip_instruction_noise(text))
    # Replace any remaining alphabetic runs with separators, preserving e/E only
    # inside scientific notation through a second validation pass.
    raw_chunks = re.findall(r"[0-9eE.+\-*/%()\s]{3,}", normalized)
    candidates: list[str] = []
    for chunk in raw_chunks:
        chunk = re.sub(r"\s+", " ", chunk).strip(" .,:;!?=")
        # Split on long whitespace if the chunk accidentally contains two unrelated numbers.
        variants = [chunk]
        for candidate in variants:
            if not candidate or not re.search(r"\d", candidate):
                continue
            if not re.search(r"\*\*|[+\-*/%]", candidate):
                continue
            number_count = len(re.findall(r"\d+(?:\.\d+)?", candidate))
            # A lone signed identifier suffix such as "Зета-404" is not arithmetic.
            if number_count < 2 and "**" not in candidate:
                continue
            if not _balanced(candidate):
                continue
            # Remove spaces around operators, retain no free whitespace.
            candidate = re.sub(r"\s+", "", candidate)
            # Reject malformed operator runs except ** and leading signs.
            if re.search(r"(?<!\*)\*{3,}|/{2,}|\+{2,}|%{2,}", candidate):
                continue
            candidates.append(candidate)
    if not candidates:
        return None
    candidates.sort(key=_candidate_score, reverse=True)
    return candidates[0]


def _to_fraction(value: int | float | Fraction | Decimal) -> Fraction:
    if isinstance(value, Fraction):
        return value
    if isinstance(value, int):
        return Fraction(value, 1)
    if isinstance(value, Decimal):
        return Fraction(value)
    return Fraction(str(value))


def safe_eval(expression: str, *, max_abs: int | float = 10**30, max_power: int = 1000) -> Fraction:
    tree = ast.parse(expression, mode="eval")

    def visit(node: ast.AST) -> Fraction:
        if isinstance(node, ast.Expression):
            return visit(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return _to_fraction(node.value)
        if isinstance(node, ast.UnaryOp) and type(node.op) in _ALLOWED_UNARY:
            value = visit(node.operand)
            return value if isinstance(node.op, ast.UAdd) else -value
        if isinstance(node, ast.BinOp) and type(node.op) in _ALLOWED_BINOPS:
            left, right = visit(node.left), visit(node.right)
            if isinstance(node.op, ast.Pow):
                if right.denominator != 1:
                    raise ExactRoutingError("fractional powers are not exact in this engine")
                exponent = right.numerator
                if abs(exponent) > max_power:
                    raise ExactRoutingError("power is outside the safe range")
                if exponent < 0:
                    if left == 0:
                        raise ZeroDivisionError("zero cannot be raised to a negative power")
                    value = Fraction(1, 1) / (left ** abs(exponent))
                else:
                    value = left ** exponent
            elif isinstance(node.op, ast.Add):
                value = left + right
            elif isinstance(node.op, ast.Sub):
                value = left - right
            elif isinstance(node.op, ast.Mult):
                value = left * right
            elif isinstance(node.op, ast.Div):
                if right == 0:
                    raise ZeroDivisionError("division by zero")
                value = left / right
            elif isinstance(node.op, ast.FloorDiv):
                if right == 0:
                    raise ZeroDivisionError("division by zero")
                value = Fraction(left // right, 1)
            elif isinstance(node.op, ast.Mod):
                if right == 0:
                    raise ZeroDivisionError("modulo by zero")
                value = left % right
            else:  # pragma: no cover
                raise ExactRoutingError("unsupported operation")
            if abs(value) > max_abs:
                raise ExactRoutingError("result is outside the safe range")
            return value
        raise ExactRoutingError(f"unsupported arithmetic node: {type(node).__name__}")

    result = visit(tree)
    if abs(result) > max_abs:
        raise ExactRoutingError("result is outside the safe range")
    return result


def route_exact(text: str) -> ExactResult | None:
    expression = extract_expression(text)
    if expression is None:
        return None
    value = safe_eval(expression)
    if value.denominator == 1:
        display: int | float | str = value.numerator
        fraction = None
    else:
        # Preserve exactness and provide a concise decimal representation.
        fraction = f"{value.numerator}/{value.denominator}"
        decimal = Decimal(value.numerator) / Decimal(value.denominator)
        display = format(decimal.normalize(), "f")
    return ExactResult(
        original_text=text,
        expression=expression,
        normalized_expression=expression,
        value=display,
        exact_fraction=fraction,
        verified=True,
    )
