# SOURCE / PROVENANCE

R7.10 source is fully preserved byte-for-byte in `FREEZE/source/`, unlike the R7.9 canonical-source recovery boundary. The freeze manifest records SHA-256 for compiler, solver, verifier, option matcher, runtime, evidence fusion and trusted facts.

Chronology is auditable:
1. R7.10 architecture freeze committed to GitHub main (`fc8a32bc...`) while Blind-27 did not exist.
2. Blind-27 generated after freeze.
3. Formal and routing pre-inference snapshots created before teacher inference. The formal snapshot already exposed one wrong verified proof (`R27_08`); it was not patched.
4. Benchmark packed/committed, runner/workflow committed, then PR #29 changed only trigger file.
5. Five real teacher jobs completed successfully; every artifact contains the exact frozen benchmark SHA.

This release retains raw teacher JSON, raw GitHub artifacts, benchmark, pre-inference snapshots, source, EIG, policy, native weights, results and prior R7.9 lineage archive.
