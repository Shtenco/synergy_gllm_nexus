# NEXUS R7.10 — Proof-First Generalization — REAL Blind-27

## Confirmatory result
Architecture freeze commit: `fc8a32bc949947a42ab5038de0a3e55fa9921e64` — before Blind-27 existed.
Blind-27 SHA-256: `9232b50c27af89dfdf71beb53d58c438c3cd7158ea852938bd0c35112a7d6c58`. 160 items, 8 domains × 20. Five real Ollama Q4_K_M teacher jobs all SUCCESS, GitHub Actions run `32419938053`, PR #29.

| System | Correct | Strict |
|---|---:|---:|
| Gemma3 1B | 70/160 | 43.75% |
| Granite3.3 2B | 88/160 | 55.00% |
| Ministral-3 3B | 119/160 | 74.375% |
| Phi-4-mini 3.8B | 124/160 | 77.50% |
| Qwen3 1.7B | 127/160 | 79.375% |
| Majority5 | 126/160 | 78.75% |
| Logprob5 | 128/160 | 80.00% |
| R7.7 Meta top1 | 122/160 | 76.25% |
| **NEXUS R7.10** | **150/160** | **93.75%** |
| five-teacher oracle diagnostic | 152/160 | 95.00% |

R7.10 mean logical foreign calls/item = **1.0125** (162 calls / 160 items). Stages: 87 Formal Verified, 57 Pair Agree, 16 Weighted Third.
Frozen formal snapshot: 87 VERIFIED; 86 correct. The known confirmatory proof error `R27_08` was preserved and counted.

R7.10 vs best single Qwen3: +14.375 percentage points; paired discordance 27 R7.10-only correct vs 4 Qwen-only correct; exact two-sided p = 3.3953e-05.
R7.10 vs majority5: +15.0 pp; exact paired p = 3.0324e-06.

## Target verdict
The requested ≥98% strict target was **not reached**. Achieved 93.75%. Mean-call target was essentially reached: 1.0125 calls/item. Do not rewrite this result by post-hoc patching Blind-27.

## Domain strict accuracy
- knowledge 100%
- science 100%
- math 95%
- logic 95%
- russian 95%
- code 90%
- mixed_reasoning 90%
- cyber_causal 85%

## Residual errors
`M27_02, L27_20, C27_08, C27_09, C27_19, P27_08, P27_17, R27_08, X27_11, X27_15`.
`M27_02` and `P27_08` were not solved by any of five teachers. `R27_08` was a sovereign formal false positive even though Phi/Qwen had the correct answer. These are design evidence for the next version, not grounds to alter R7.10.

## Native preservation
R7-L Blind-20: **320/320 = 100%**. Core and binder SHA-256 unchanged. Catastrophic forgetting observed: 0.
