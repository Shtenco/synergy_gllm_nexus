import math, itertools

def pair_key(a,b):return '|'.join(sorted([a,b]))
def pair_stats(graph,a,b,domain=None):
    key=pair_key(a,b)
    base=graph['global'].get(key,{'independence':.5,'joint_error_rate':.25})
    if domain in graph.get('by_domain',{}) and key in graph['by_domain'][domain]:
        d=graph['by_domain'][domain][key]
        return {'independence':0.65*d.get('independence',.5)+0.35*base.get('independence',.5),'joint_error_rate':base.get('joint_error_rate',.25)}
    return base

def hist_acc(graph,t,domain):
    return graph.get('by_domain',{}).get(domain,{}).get(t,{}).get('accuracy',graph['global'][t]['accuracy'])
def candidate_score(graph,t,route_score,domain,peers=()):
    indep=.5 if not peers else sum(pair_stats(graph,t,p,domain)['independence'] for p in peers)/len(peers)
    return .72*route_score+.18*hist_acc(graph,t,domain)+.10*indep

def choose_nodes(graph,route):
    rank=route['ranked_teachers']; dom=route['domain']; scores=route['teacher_scores']; n0=rank[0]
    n1=max(rank[1:],key=lambda t:candidate_score(graph,t,scores[t],dom,(n0,)))
    return n0,n1

def choose_third(graph,route,n0,n1):
    dom=route['domain'];scores=route['teacher_scores'];cand=[t for t in route['ranked_teachers'] if t not in [n0,n1]]
    return max(cand,key=lambda t:candidate_score(graph,t,scores[t],dom,(n0,n1)))

def weight(graph,route,t,peers=()):
    return candidate_score(graph,t,route['teacher_scores'][t],route['domain'],peers)

def resolve(graph,route,preds):
    n0,n1=choose_nodes(graph,route); used=[n0,n1]
    p0,p1=preds.get(n0),preds.get(n1); valid=lambda x:isinstance(x,str) and x in 'ABCD'
    risk=pair_stats(graph,n0,n1,route['domain']).get('joint_error_rate',.25)
    risky=route['domain'] in ['science','knowledge','mixed_reasoning'] and risk>.18
    if valid(p0) and valid(p1) and p0==p1 and not risky:return p0,used,'PAIR_AGREE'
    n2=choose_third(graph,route,n0,n1);used.append(n2);p2=preds.get(n2)
    votes={}
    for t,p in [(n0,p0),(n1,p1),(n2,p2)]:
        if valid(p):votes[p]=votes.get(p,0)+weight(graph,route,t,tuple(x for x in used if x!=t))
    if not votes:return None,used,'ABSTAIN'
    return max(votes,key=votes.get),used,'WEIGHTED_THIRD'
