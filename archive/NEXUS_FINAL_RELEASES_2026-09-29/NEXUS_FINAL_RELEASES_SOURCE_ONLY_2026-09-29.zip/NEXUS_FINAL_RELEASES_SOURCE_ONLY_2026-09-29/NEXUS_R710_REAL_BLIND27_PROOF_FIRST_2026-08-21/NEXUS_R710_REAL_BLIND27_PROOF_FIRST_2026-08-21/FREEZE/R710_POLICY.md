# NEXUS R7.10 — Proof-First Generalization Policy

1. Run Semantic Compiler v2 -> Solver v2 -> independently implemented Verifier v2.
2. VERIFIED proof with option mapping is sovereign and uses zero foreign calls.
3. UNKNOWN enters foreign evidence path.
4. Rank teachers by frozen R7.7 question-conditioned Meta-Teacher scores.
5. Select Node-0 = rank-1. Select Node-1 from remaining teachers by competence × independence: 0.72*route_score + 0.18*domain_history_accuracy + 0.10*pair_independence.
6. Query Node-0 and Node-1. If same valid answer, accept unless pair joint-error risk > 0.18 AND the domain is science/knowledge/mixed_reasoning; in that risk case query a third independent teacher.
7. If Node-0 and Node-1 disagree, query one third teacher selected by the same competence×independence score relative to both nodes. Resolve with reliability-weighted evidence.
8. A foreign majority never overrides VERIFIED proof.
9. Maximum foreign calls = 3. Target mean foreign calls <= 1.0 through proof-first coverage.
10. All thresholds, source hashes and EIG are frozen before Blind-27 exists.

Claim boundary: Blind-27 is an authored architecture-stress test; >=98% there is not an open-domain AGI score.
